/*****************************************************************************
 @Project		:
 @File 			: main.c
 @Details  	: Main entry
 @Author		: lcgan
 @Hardware	: STM32
 
 ----------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 ----------------------------------------------------------------------------
   1.0  XXXXXX     12-Feb-2023  	Initial Release
																	
*****************************************************************************/
#include <Common.h>
#include "Hal.h"
#include "BSP.h"
#include "Timer.h"
#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "Serial.h"
//header file for remote control
#include "Remote.h"
//header file for motor control
#include "UbiquityMotor.h"
//header file for Lcd functions
#include "LcdFunctions.h"

/* NOTE: Please follows code style provided. All tabs is 4 space */

/*****************************************************************************
 Define
************************"******************************************************/
#define SYS_TICK_MS 500 /* Software Timer with 500 ms */
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10

//Motor control
#define MOTOR_TICK_MS           10


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Const Local Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
//systic declarations
static volatile int     	g_nSysTick = SYS_TICK_MS;
static volatile BOOL    	g_bSysTickReady = FALSE;
static volatile BOOL    	g_bToggle = FALSE;

//LCD declarations
static SPIM_HANDLE			g_SpimHandle;
volatile GUI_DATA			g_aBuf[LCD_BUF_SIZE];
volatile GUI_MEMDEV			g_MemDev;
volatile BOOL 				g_bLcdFree  = TRUE;

static volatile int     	g_nLCDTick = LCD_UPDATE_MS;
static volatile BOOL    	g_nLCDTickReady = FALSE;

//Global variables for time and count
volatile uint32_t         	g_nCount = 0;
volatile uint32_t			g_nTimeSec = 0;


//Timer declarations
static TIMER_HANDLE     	g_Timer1Handle; /* This is timer 1 handle */
static TIMER_HOOK       	g_TImer1Hook;    /* This is hook 1 to timer 1 */


//Remote control handle
static UART_HANDLE          g_UartRemoteHandle;
static char                 g_aUartRemoteTxBuf[64];
static char                 g_aUartRemoteRxBuf[64];
static volatile BOOL        g_abUartRemoteReady = FALSE;
static int                  g_nCmd = 0;

//Declare motor control handle
static UART_HANDLE          g_UartMCBHandle;
static char                 g_aUartMCBTxBuf[64];
static char                 g_aUartMCBRxBuf[64];
static volatile BOOL        g_abUartMCBReady = FALSE;

static volatile int         g_nMotorTick = MOTOR_TICK_MS;
static volatile BOOL        g_bMotorTickReady = FALSE;

volatile BOOL motor_status = FALSE;
volatile BOOL remote_status = FALSE;
//variable to store the direction of the motor (string data type)
volatile char motor_direction[10] = " ";
/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void );
static void motor_UartInit( void );
static void remote_UartInit( void );
static void main_HostCmdExe( char *pCmd );

/*****************************************************************************
 Callback functions
******************************************************************************/
static void main_cbUartRemoteOnRx( void );


/*****************************************************************************
 Implementation 
******************************************************************************/
int main( void )
{
	char *cmd;
	int dist = 0;
	
    BSPInit( );

	/* Generate interrupt each 1 ms as system tick */
	SysTick_Config( SystemCoreClock / 1000 );

	TRACE("SystemCoreClock %dHz\r\n", SystemCoreClock);

	main_SpimInit();

	LCD_Init(&g_SpimHandle);//from LcdFunctions.c
	
	remote_UartInit();
	motor_UartInit();
	MotorsInit( &g_UartMCBHandle );
	MotorsSetSpeeds( 25, 25 );  //Speed at 25 ticks/ 100ms
	TimerInit( &g_Timer1Handle, 1U, 10000 );
	
	
	/* Start timer 1 now */
    TimerStart( &g_Timer1Handle );
	/* Runtime for loop */
	for(;;)
    {
		if( FALSE != g_bSysTickReady )
		{
			g_bSysTickReady = FALSE;

			/* Every 500ms per tick */    
			LED_LD2_SET(g_bToggle);

			g_bToggle = !g_bToggle;
		}

        if( FALSE != g_nLCDTickReady )
		{
			if( 0 != g_bLcdFree )
			{
				g_nLCDTickReady = FALSE;
				g_bLcdFree = FALSE;
				/* Draw every block.Consume less time  */
				GUI_Draw_Exe(); 
			}
		}
		
		if( FALSE != g_abUartRemoteReady )
		{
			g_abUartRemoteReady = FALSE;

			cmd = RemoteParse( &g_UartRemoteHandle );
            if( 0 != cmd )
			{
				main_HostCmdExe( cmd );
			}
		}
		if( FALSE != g_bMotorTickReady )
        {
            g_bMotorTickReady = FALSE;
            MotorOnTimer(); // shall maintain at 50ms as required by ubiquity MCB
        }
		
		if( 0 != g_abUartMCBReady )
        {
            g_abUartMCBReady = FALSE;
            SerialRxEmpty( &g_UartMCBHandle );
            // Ignore incoming Uart bytes from MCB. Not in use.
        }
    }
}

/*****************************************************************************
 Callback functions
******************************************************************************/


static void main_cbUartRemoteOnRx( void )
{
    g_abUartRemoteReady = TRUE;
}
static void main_cbMCBOnRx( void )
{
   g_abUartMCBReady  = TRUE;
}


/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void )
{
	SpimInit(
        &g_SpimHandle,
        2,
        15000000U, 
        SPI_CLK_INACT_LOW,
        SPI_CLK_RISING_EDGE,
        SPI_DATA_SIZE_8 );
}

static void motor_UartInit( void )
{
    int res = SerialInit( &g_UartMCBHandle, 1, 38400 );
    ASSERT( res == UART_STS_OK );
	(res == UART_STS_OK)?(motor_status = TRUE):(motor_status = FALSE);

    SerialConfig(
    	&g_UartMCBHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartMCBHandle, 
    	g_aUartMCBTxBuf,
    	sizeof(g_aUartMCBTxBuf),
    	g_aUartMCBRxBuf,
    	sizeof(g_aUartMCBRxBuf) );

   SerialAddCallback( &g_UartMCBHandle, 0, main_cbMCBOnRx );
}

static void remote_UartInit( void )
{
	int res;
   // Remote controller from esp32
    res = SerialInit( &g_UartRemoteHandle, 5, 921600 );
    ASSERT( res == UART_STS_OK );
	(res == UART_STS_OK)?(remote_status = TRUE):(remote_status = FALSE);

    SerialConfig(
    	&g_UartRemoteHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartRemoteHandle, 
    	g_aUartRemoteTxBuf,
    	sizeof(g_aUartRemoteTxBuf),
    	g_aUartRemoteRxBuf,
    	sizeof(g_aUartRemoteTxBuf) );

   SerialAddCallback( &g_UartRemoteHandle, 0, main_cbUartRemoteOnRx );
}

static void main_HostCmdExe(char *pCmd)
{
    HOST_REQ_PKT *req = (HOST_REQ_PKT *)pCmd;

    switch (req->Cmd.Cmd)
    {
        case CMD_HOST_STOP:
            MotorsStop();
            strncpy((char *)motor_direction, "STOP", sizeof(motor_direction));
            motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
            TRACE("cmd: STOP\r\n");
            break;

        case CMD_HOST_MOVE_FWD:
            MotorsMoveFront();
            strncpy((char *)motor_direction, "FWD", sizeof(motor_direction));
            motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
            TRACE("cmd: FWD\r\n");
            break;

        case CMD_HOST_MOVE_BWD:
            MotorsMoveBack();
            strncpy((char *)motor_direction, "BWD", sizeof(motor_direction));
            motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
            TRACE("cmd: BWD\r\n");
            break;

        case CMD_HOST_ROTATE_LEFT:
            MotorsRotateLeft();
            strncpy((char *)motor_direction, "LEFT", sizeof(motor_direction));
            motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
            TRACE("cmd: ROTATE LEFT\r\n");
            break;

        case CMD_HOST_ROTATE_RIGHT:
            MotorsRotateRight();
            strncpy((char *)motor_direction, "RIGHT", sizeof(motor_direction));
            motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
            TRACE("cmd: ROTATE RIGHT\r\n");
            break;

        default:
            TRACE("cmd: Invalid\r\n");
            break;
    }
}



/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler( void )
{
	/* NOTE:
	It is more efficient to compare to 0 for Cortex M
	*/

	g_nCount++;
	if (g_nCount == 1000)
	{
		//g_bSecTick = TRUE;
		g_nCount=0;
		
		/* Keep track of time based on 1 sec interval */ 
		g_nTimeSec++;
		if(g_nTimeSec > 24*60*60)
		{
			g_nTimeSec = 0;
		}
	}

	if( 0 != g_nSysTick ) // g_nSysTick counts down from SYS_TICK_MS
	{
		g_nSysTick--;
		if( 0 == g_nSysTick )
		{
			g_nSysTick = SYS_TICK_MS;
			g_bSysTickReady = TRUE;
		}
	}

	if( 0 != g_nLCDTick )
	{
		g_nLCDTick--;
		if( 0 == g_nLCDTick )
		{
			g_nLCDTick = LCD_UPDATE_MS;
			g_nLCDTickReady = TRUE;		}
	}
	
	if( 0 != g_nMotorTick )
    {
        g_nMotorTick--;

        if( 0 == g_nMotorTick )
        {
            g_nMotorTick = MOTOR_TICK_MS;
            g_bMotorTickReady = TRUE;
		}
	}
}