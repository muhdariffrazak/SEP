#include "LcdFunctions.h"
#include <stdio.h>
#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "Common.h"
#include "Hal.h"
#include "stdint.h"

//import uint8_t, uint16_t, uint32_t from Common.h

#define SYS_TICK_MS 			500 	/* Software Timer with 500 ms */
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10

//static SPIM_HANDLE			g_SpimHandle; //used for LcdInit(spimHandle, LCD_LANDSCAPE);
static GUI_DATA					g_aBuf[LCD_BUF_SIZE];
static GUI_MEMDEV				g_MemDev;


//imporrt g_lcdFree from main.c
extern volatile BOOL g_bLcdFree;
extern SPIM_HANDLE g_SpimHandle;

//import g_nTimeSec, g_nCount from main.c
extern volatile uint32_t g_nTimeSec;
extern volatile uint32_t g_nCount;

extern volatile BOOL motor_status;
extern volatile BOOL remote_status;

//import motor_direction variable from main.c
extern char motor_direction;

const char *MessageToPrint()
{
    return "Hello World!";
}

void LCD_Init(SPIM_HANDLE *spimHandle)
{
	int screenx;
	int screeny;
	
	/* g_SpimHandle shall be initialized before use */
	
	/* Choosing a landscape orientation */
	LcdInit(spimHandle, LCD_LANDSCAPE);
	
	/* Get physical LCD size in pixels */
	LCD_GetSize( &screenx, &screeny );
	
	/* Initialize GUI */
	GUI_Init(
		&g_MemDev,
		screenx,
		screeny,
		g_aBuf,
		sizeof(g_aBuf) );
	
	/* Switch to transfer word for faster performance */
	SpimSetDataSize( spimHandle, SPI_DATA_SIZE_16 );
	GUI_16BitPerPixel( TRUE );
	
	/* Clear LCD screen to Blue */
	GUI_Clear( ClrBlue );

    /* set font color background */
    GUI_SetFontBackColor( ClrBlue );
    
    /* Set font */
    GUI_SetFont( &g_sFontCalibri10 );
	
	LCD_AddCallback( main_cbLcdTransferDone );
	
	GUI_AddCbFrameEnd( main_cbGuiFrameEnd );
	
	/* Backlight ON */
	LCD_BL_ON();
}


void GUI_AppDraw( BOOL bFrameStart )
{
	static char buf0[20],buf1[20],buf2[15],buf3[15];

	if( TRUE == bFrameStart ) // framestart = TRUE indicate the display dynamic area can be updated.
	{
    /* choose one to display - count or time elapsed */
		//g_nCount++;
		//sprintf( buf0, "%08X", g_nCount);
		sprintf( buf0, "%02u:%02u:%02u", (g_nTimeSec/3600)%24, (g_nTimeSec/60)%60, g_nTimeSec%60 );
		
		sprintf (buf1, "%d MHz", SystemCoreClock/1000000);
		sprintf( buf2, "%08X", SCB->CPUID);
	}
		
	/* Set background to blue. Refer to gui.h for color code */

	GUI_Clear( ClrWhite ); 
	GUI_SetColor( ClrBlack );
	GUI_SetFont( &g_sFontCalibri10 );
	//print status of uart for motor and remote control in same line using GUI_PrintString and string formatting
	char status_string[50]; // Buffer to store the formatted string
	// Format the string based on the values of motor_status and remote_status
	sprintf(status_string, "UART: Motor: %s, Remote: %s",
			(motor_status == 1) ? "1" : "0",
			(remote_status == 1) ? "1" : "0");
	// Print the formatted string using GUI_PrintString
	(motor_status==1 || remote_status==1 )? GUI_PrintString(status_string, ClrGreen, 5, 10) : GUI_PrintString(status_string,ClrRed, 5, 10);
	// Format the string based on the value of motor_direction
	sprintf(buf3, "MotorDir: %c", motor_direction);
	// Print the formatted string using GUI_PrintString
	GUI_PrintString(buf3, ClrBlack, 5, 20);
	/* Display g_nCount string */
	GUI_PrintString( "STM32G474RE", ClrBlack, 5, 1);
	//GUI_PrintString( "KEIL V5.36.0.0", ClrWhite, 5, 21 );
	//GUI_PrintString( "STLINK-V3E", ClrWhite, 5, 41 );
	//Print out direction of motor

	GUI_PrintString( buf0, ClrGreenYellow, 5, 61 );
	GUI_PrintString( buf1, ClrYellowGreen , 5, 81 );
	GUI_PrintString( buf2, ClrYellowGreen , 5, 101 );
}

static void main_cbLcdTransferDone( void )
{
	g_bLcdFree = TRUE;
}

static void main_cbGuiFrameEnd( void )
{
	g_bLcdFree = TRUE;
}