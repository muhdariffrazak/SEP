//Define header file
#ifndef LcdFunctions_H
#define LcdFunctions_H

#include "spim.h"
#include "stdint.h"
#include "Common.h"
#include "stdint.h"
#include "LCD.h"
#include "gui.h"
#include "spim.h"
#include "I2c.h"
#include "DistSensor.h"

#define TOF_TOTAL 2


extern SPIM_HANDLE g_SpiHandle;
extern VL53L0X_Dev_t 		g_hDistSensor[TOF_TOTAL];
extern int					g_nDistData[TOF_TOTAL];


//Fucntion declaration
void LCD_Init(SPIM_HANDLE *spimHandle);
static void main_cbLcdTransferDone( void );
static void main_cbGuiFrameEnd( void );
void GUI_AppDraw(BOOL bFrameStart);

#endif