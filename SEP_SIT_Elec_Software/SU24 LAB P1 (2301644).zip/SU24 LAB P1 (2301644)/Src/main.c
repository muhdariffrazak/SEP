/***************************************************************************************
 @Project		: MET2001 Lab P1
 @File 			: main.c
 @Details  	: Blink_LED@Diff rates
 @Author		: muhammadariff.b
 @Hardware	: STM32
 
 ---------------------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 ---------------------------------------------------------------------------------------
   1.0  muhammadariff.b    20 May 2024  	Initial Release - STM32G474RE
																					Debug interface - STLink
																					Support TFT LCD ST7735
																					Virtual COM Port @LPUART (PA2-TX, PA3-RX)`
																					 - 921,600,8,no parity,1 Stop
	 2.0 	muhammadariff.b 		 16 May 2024		Add Event Recorder codes
																						Add option for ITM redirection to Debug printf Viewer
												
*****************************************************************************************/
#include <Common.h>
#include "Hal.h"
#include "BSP.h"
#include "Timer.h"

#include "LPUART.h"
#include "EventRecorder.h"
//#include "RTE_Components.h"

#include <stdio.h>

/*****************************************************************************
 Define
******************************************************************************/
// System tick interval in milliseconds
#define SYS_TICK_MS 1 /* System tick every 1 ms */

// Blink periods for different frequencies
#define BLINK_1HZ_PERIOD_MS 500    /* 1 Hz blink rate (500 ms toggle) */
#define BLINK_5HZ_PERIOD_MS 100    /* 5 Hz blink rate (100 ms toggle) */
#define BLINK_10HZ_PERIOD_MS 50    /* 10 Hz blink rate (50 ms toggle) */

// Duration for each blink rate
#define DURATION_MS 10000          /* Duration for each blink rate (10 seconds) */
//#define DURATION_MS 5000          /* Duration for each blink rate (5 seconds) */

/*****************************************************************************
 Type definition
******************************************************************************/

/*****************************************************************************
 Global Variables
******************************************************************************/

/*****************************************************************************
 Const Local Variables
******************************************************************************/

/*****************************************************************************
 Local Variables
******************************************************************************/
static volatile int g_nSysTick = SYS_TICK_MS;      // System tick counter
static volatile BOOL g_bSysTickReady = FALSE;      // SysTick flag
static volatile BOOL g_bToggle = FALSE;            // LED toggle flag

static LPUART_HANDLE g_LPUartHandle;               // LPUART handle

static uint32_t g_nCount = 0;                      // SysTick counter

// Variables for blink sequence
static uint32_t blinkPeriod = BLINK_1HZ_PERIOD_MS; // Current blink period
static uint32_t elapsedBlinkTime = 0;              // Time elapsed since last blink
static uint32_t elapsedTotalTime = 0;              // Total elapsed time
static uint8_t blinkState = 0;                     // Current blink state (0: 1Hz, 1: 5Hz, 2: 10Hz)

/*****************************************************************************
 Local functions
******************************************************************************/

/*****************************************************************************
 Callback functions
******************************************************************************/

/*****************************************************************************
 Implementation 
******************************************************************************/
int main(void)
{
    // Initialize and start Event Recorder
    EventRecorderInitialize(EventRecordAll, 1); 
    BSPInit();  // Initialize Board Support Package

    // Generate interrupt each 1 ms as system tick
    SysTick_Config(SystemCoreClock / 1000); 

    // Initialize LPUART1
    g_LPUartHandle.baud = 921600;
    g_LPUartHandle.databits = DATABITS8;
    g_LPUartHandle.stop = STOP1;
    g_LPUartHandle.parity = PARITY_NONE;
    LPUART1_Init(&g_LPUartHandle);

    printf("MET2001 SU24 ...\r\n");

    EventRecord2(0x0500, 0, 0);

    // Main loop
    for (;;)
    {
        if (FALSE != g_bSysTickReady)
        {
            g_bSysTickReady = FALSE;

            elapsedTotalTime += SYS_TICK_MS;  // Increment total elapsed time
            elapsedBlinkTime += SYS_TICK_MS;  // Increment elapsed blink time

            // Check if it's time to toggle the LED
            if (elapsedBlinkTime >= blinkPeriod)
            {
                elapsedBlinkTime = 0;        // Reset blink time
                g_bToggle = !g_bToggle;      // Toggle LED state
                LED_LD2_SET(g_bToggle);      // Set LED state
                printf("main: bToggle=%i\n\r", g_bToggle);
                EventRecord2(0x0501, g_nCount, 1);
            }

            // Check if it's time to change the blink frequency
            if (elapsedTotalTime >= DURATION_MS)
            {
                elapsedTotalTime = 0;       // Reset total elapsed time
                blinkState = (blinkState + 1) % 3;  // Move to the next state

                // Update blink period based on the current state
                switch (blinkState)
                {
                    case 0:
                        blinkPeriod = BLINK_1HZ_PERIOD_MS;
                        break;
                    case 1:
                        blinkPeriod = BLINK_5HZ_PERIOD_MS;
                        break;
                    case 2:
                        blinkPeriod = BLINK_10HZ_PERIOD_MS;
                        break;
                }

                printf("Switching to blink period %u ms\n\r", blinkPeriod);
            }
        }
    }
}

/*****************************************************************************
 Callback functions
******************************************************************************/

/*****************************************************************************
 Local functions
******************************************************************************/

/*****************************************************************************
 Interrupt functions
******************************************************************************/
// SysTick interrupt handler
void SysTick_Handler(void)
{
    g_nCount++;  // Increment the SysTick counter
    
    // Print a message every second
    if (g_nCount == 1000)
    {
        printf("SysTick: g_nCount=1000\r\n");
        g_nCount = 0;  // Reset the counter
    }

    // Manage the SysTick timing
    g_nSysTick--;
    if (g_nSysTick == 0)
    {
        g_nSysTick = SYS_TICK_MS;
        g_bSysTickReady = TRUE;  // Set the SysTick ready flag
    }
}
