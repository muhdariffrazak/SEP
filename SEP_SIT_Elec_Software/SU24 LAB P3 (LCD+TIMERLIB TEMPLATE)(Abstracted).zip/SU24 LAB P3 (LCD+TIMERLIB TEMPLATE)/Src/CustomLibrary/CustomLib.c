#include "CustomLib.h"
#include <stdio.h>
#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "Common.h"
#include "Hal.h"
#include "stdint.h"

//import uint8_t, uint16_t, uint32_t from Common.h

#define SYS_TICK_MS 			500 	/* Software Timer with 500 ms */
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10

//static SPIM_HANDLE			g_SpimHandle; //used for LcdInit(spimHandle, LCD_LANDSCAPE);
static GUI_DATA					g_aBuf[LCD_BUF_SIZE];
static GUI_MEMDEV				g_MemDev;


//imporrt g_lcdFree from main.c
extern volatile BOOL g_bLcdFree;
extern SPIM_HANDLE g_SpimHandle;

//import g_nTimeSec, g_nCount from main.c
extern volatile uint32_t g_nTimeSec;
extern volatile uint32_t g_nCount;


const char *MessageToPrint()
{
    return "Hello World!";
}

void LCD_Init(SPIM_HANDLE *spimHandle) {
    int screenx, screeny;
    LcdInit(spimHandle, LCD_LANDSCAPE); //uses g_SpimHandle (defined in CustomLib.c)
    LCD_GetSize(&screenx, &screeny);
    GUI_Init(&g_MemDev, screenx, screeny, g_aBuf, sizeof(g_aBuf));//uses g_MemDev, g_aBuf ()
    SpimSetDataSize(spimHandle, SPI_DATA_SIZE_16);
    GUI_16BitPerPixel(TRUE);
    GUI_Clear(ClrBlue);
    GUI_SetFontBackColor(ClrBlue);
    GUI_SetFont(&g_sFontCalibri10);
    LCD_AddCallback(main_cbLcdTransferDone);
    GUI_AddCbFrameEnd(main_cbGuiFrameEnd);
    LCD_BL_ON();
}

void GUI_AppDraw( BOOL bFrameStart )
{
	/* This function invokes from GUI library */
	static char buf0[25],buf1[25],buf2[25];

	if( TRUE == bFrameStart ) // framestart = TRUE indicate the display dynamic area can be updated.
	{
    /* choose one to display - count or time elapsed */	
		sprintf( buf0, "%02u:%02u:%02u", (g_nTimeSec/3600)%24, (g_nTimeSec/60)%60, g_nTimeSec%60 );
		sprintf (buf1, "CPU Clock: %d MHz", SystemCoreClock/1000000);
		sprintf( buf2, "g_nCount: %08X", g_nCount);
	}
		
	/* Set background to blue. Refer to gui.h for color code */
	GUI_Clear( ClrBlue ); 
	
	GUI_SetColor( ClrYellow );
	GUI_DrawRect(0,110,159,127); // (col,row.col,row)
	GUI_DrawLine (0,66,159,66);
	GUI_DrawLine (0,69,159,69);
	
	GUI_SetFont( &g_sFontCalibri24 );
	//print const char *message = MessageToPrint() using GUI_PrintString
	GUI_PrintString( "MET2001 SU24", ClrMagenta, 5, 1);
	GUI_PrintString( "KEIL V5.36.0.0", ClrWhite, 5, 21 );
	GUI_PrintString( "STM32G474RE", ClrLightBlue, 5, 41 );
	GUI_SetFont( &FONT_Arialbold16 );
	GUI_PrintString( buf0, ClrGreenYellow, 45, 112 ); // time
	GUI_PrintString( buf1, ClrYellowGreen,5,90 ); // CPU clock
	GUI_SetFont( &FONT_Arialbold12 );
	GUI_PrintString( buf2, ClrYellowGreen,5,75 ); // g_nCount
}

//Callback function for LCD transfer done

static void main_cbLcdTransferDone( void )
{
	g_bLcdFree = TRUE;
}

static void main_cbGuiFrameEnd( void )
{
	g_bLcdFree = TRUE;
}