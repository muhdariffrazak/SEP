//Define header file
#ifndef CUSTOMLIB_H
#define CUSTOMLIB_H

#include "spim.h"
#include "stdint.h"
#include "Common.h"
#include "stdint.h"

//Fucntion declaration
const char *MessageToPrint();
void LCD_Init(SPIM_HANDLE *spimHandle);
static void main_cbLcdTransferDone( void );
static void main_cbGuiFrameEnd( void );
void GUI_AppDraw(BOOL bFrameStart);

#endif