/*****************************************************************************
 @Project	: 
 @File 		: BSP.c
 @Details  	:
 @Author	: 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     XXXX-XX-XX  		Initial Release
   
******************************************************************************/
#include <Common.h>
#include "BSP.h"
#include "Hal.h"

/*****************************************************************************
 Define
******************************************************************************/


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
void IRQInit( void )
{
    NVIC_ClearPendingIRQ( EXTI15_10_IRQn ); // clear any pending interrupts in the pipeline
    NVIC_EnableIRQ( EXTI15_10_IRQn );
}


/*****************************************************************************
 Implementation
******************************************************************************/
void EXTI0_IRQHandler( void )
{
    uint32_t irqStatus = EXTI->PR1;
}

void EXTI1_IRQHandler( void )
{
    uint32_t irqStatus = EXTI->PR1;
}

void EXTI2_IRQHandler( void )
{
    uint32_t irqStatus = EXTI->PR1;

    if( 0 != (irqStatus & EXTI_PR1_PIF2) )
    {
        EXTI->PR1 = EXTI_PR1_PIF2;
    }
}

void EXTI3_IRQHandler( void )
{
    uint32_t irqStatus = EXTI->PR1;
}

void EXTI4_IRQHandler( void )
{
    uint32_t irqStatus = EXTI->PR1;
}

void EXTI9_5_IRQHandler( void )
{
    uint32_t irqStatus = EXTI->PR1;

    if( 0 != (irqStatus & EXTI_PR1_PIF5) )
    {
        EXTI->PR1 = EXTI_PR1_PIF5;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF6) )
    {
        EXTI->PR1 = EXTI_PR1_PIF6;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF7) )
    {
        EXTI->PR1 = EXTI_PR1_PIF7;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF8) )
    {
        EXTI->PR1 = EXTI_PR1_PIF8;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF9) )
    {
        EXTI->PR1 = EXTI_PR1_PIF9;
    }
}

void EXTI15_10_IRQHandler( void )
{
    uint32_t irqStatus = EXTI->PR1;

    if( 0 != (irqStatus & EXTI_PR1_PIF10) )
    {
        EXTI->PR1 = EXTI_PR1_PIF10;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF11) )
    {
        EXTI->PR1 = EXTI_PR1_PIF11;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF12) )
    {
        //EXTI12_US1_ECHO_IRQHandler( irqStatus );
        EXTI->PR1 = EXTI_PR1_PIF12;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF13) ) // check if intr is triggered
    {
        EXTI->PR1 = EXTI_PR1_PIF13; // clear intr status
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF14) )
    {
        EXTI->PR1 = EXTI_PR1_PIF14;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF15) )
    {
        EXTI->PR1 = EXTI_PR1_PIF15;
    }
}


/*****************************************************************************
 Callback functions
******************************************************************************/


/*****************************************************************************
 Local functions
******************************************************************************/


/*****************************************************************************
 Interrupt functions
******************************************************************************/






















