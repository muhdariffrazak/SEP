/***************************************************************************************
 @Project		: MET2001 Lab P3 Template
 @File 			: main.c
 @Details  	: Main entry
 @Author		: fongfh
 @Hardware	: STM32
 
 ---------------------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 ---------------------------------------------------------------------------------------
   1.0  fongfh     12-Feb-2023  	Initial Release - STM32G474RE
																	Debug interface - STLink
																	Support TFT LCD ST7735
																	Virtual COM Port @LPUART (PA2-TX, PA3-RX)`
																	 - 921,600,8,no parity,1 Stop
	2.0 	fongfh		 17 May 2023		Add Event Recorder codes
																	Add option for ITM redirection to Debug printf Viewer
																	
*****************************************************************************************/
#include <Common.h>
#include "Hal.h"
#include "BSP.h"
#include "Timer.h"

#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "IRQ.h"

#include "LPUART.h"
#include "EventRecorder.h"

#include <stdio.h>
#include "CustomLib.h"

/*****************************************************************************
 Define
************************"******************************************************/
#define SYS_TICK_MS 			500 	/* Software Timer with 500 ms */
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10

/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Const Local Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
/* SysTick declarations  */
static volatile int     g_nSysTick = SYS_TICK_MS;
static volatile BOOL    g_bSysTickReady = FALSE;
static volatile BOOL    g_bToggle = FALSE;

// /* TFT LCD declarations   */
static SPIM_HANDLE			g_SpimHandle;
volatile BOOL 					g_bLcdFree  = TRUE;
static volatile int     g_nLCDTick = LCD_UPDATE_MS;
static volatile BOOL    g_nLCDTickReady = FALSE;

/* Timer 1 declarations 		*/
static TIMER_HANDLE g_Timer1Handle;   		/* TIM1 handle   */
static TIMER_HOOK   g_Timer1Hook1;    		/* TIM1 hook     */
static volatile BOOL g_bcallback1 = FALSE; 
static void main_cbTimer1A( void );  /* prototype declaration for call-back function */

/* LPUART declarations  */
static LPUART_HANDLE		g_LPUartHandle;

/* General prgoram declarations  */
volatile uint32_t         g_nCount = 0;
volatile uint32_t			g_nTimeSec = 0;
//uint32_t	i,a,b;

/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void );

/*****************************************************************************
 Callback functions
******************************************************************************/

static void main_cbTimer1 ( void ); /* function prototypes */

/*****************************************************************************
 Implementation 
******************************************************************************/
int main( void )
{
	EventRecorderInitialize (EventRecordAll,1); // initialize & start Event Recorder
	BSPInit( );

	/* Generate interrupt each 1 ms as system tick */
	SysTick_Config( SystemCoreClock / 1000 );
	
	/* init TIM1 to 10Hz; pass handle to called fn */
   TimerInit (&g_Timer1Handle,1,10); 	// timer initialization, 10 Hz
   TimerAddHook( 
     &g_Timer1Handle, 	/* TIM1 handle   */
     &g_Timer1Hook1,  	/* TIM1 hook 1   */
     main_cbTimer1   	/* pointer to call-back function  */
   );   
	TimerStart( &g_Timer1Handle ); // start the timer
	
	// Initialize LPUART1
	g_LPUartHandle.baud = 921600;
	g_LPUartHandle.databits = DATABITS8;
	g_LPUartHandle.stop = STOP1;
	g_LPUartHandle.parity = PARITY_NONE;
	LPUART1_Init (&g_LPUartHandle);

	main_SpimInit(); // SPI bus initialization
	LCD_Init(&g_SpimHandle); // LCD initialization from CustomLib.c
	IRQInit();			// initialize ISRs; function in IRQ.c 

	//printf ("MET2001 SU24 ...\r\n");
	
	/* Runtime for loop */
	for(;;)
	{
		if( FALSE != g_bSysTickReady )
		{
				g_bSysTickReady = FALSE;

				//printf("main: bToggle=%i\n\r", g_bToggle);
				//EventRecord2 (0x0500,0,0);
				//LED_LD2_SET(g_bToggle);
				//g_bToggle = !g_bToggle;
		}
		
		if( FALSE != g_bcallback1 ) // set by timer callback fn
		{
				g_bcallback1 = FALSE;

				LED_LD2_SET(g_bToggle);
				g_bToggle = !g_bToggle;
		}
		
		if( FALSE != g_nLCDTickReady )
		{
			if( 0 != g_bLcdFree )
			{
				g_nLCDTickReady = FALSE;
				g_bLcdFree = FALSE;
				GUI_Draw_Exe(); // update LCD screen
			}
		}	
	}
}

/*****************************************************************************
 Callback functions
******************************************************************************/

/* Call-back function:                            */
/*   executes at freq defined by TimerInit() */
static void main_cbTimer1( void )
{ 
   g_bcallback1 = TRUE;
   /* add program codes, if needed */ 
}


/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void )
{
	SpimInit(
        &g_SpimHandle,
        2,
        15000000U, 
        SPI_CLK_INACT_LOW,
        SPI_CLK_RISING_EDGE,
        SPI_DATA_SIZE_8 );
}



/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler( void )
{
	g_nCount++;
	if (g_nCount == 1000)
	{
		//g_bSecTick = TRUE;
		g_nCount=0;
		
		/* Keep track of time based on 1 sec interval */ 
		g_nTimeSec++;
		if(g_nTimeSec > 24*60*60)
		{
			g_nTimeSec = 0;
		}
	}

	if( 0 != g_nSysTick ) // g_nSysTick counts down from SYS_TICK_MS
	{
			g_nSysTick--;
			if( 0 == g_nSysTick )
			{
				g_nSysTick = SYS_TICK_MS;
				g_bSysTickReady = TRUE;
			}
	}
	
	if( 0 != g_nLCDTick )
	{
		g_nLCDTick--;
		if( 0 == g_nLCDTick )
		{
			g_nLCDTick = LCD_UPDATE_MS;
			g_nLCDTickReady = TRUE;
		}
	}
}