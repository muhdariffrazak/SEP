/*****************************************************************************
 @Project		:
 @File 			: main.c
 @Details  		: Main entry
 @Author		: muhammadariff.b
 @Hardware		: STM32
 
 ----------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 ----------------------------------------------------------------------------
   1.0  XXXXXX     12-Feb-2023  	Initial Release
																	
*****************************************************************************/
#include "Common.h"
#include "Hal.h"
#include "IRQ.h"
#include "BSP.h"
#include "Timer.h"
#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "I2c.h"
#include "DistSensor.h"
#include "Serial.h"
//#include "Remote.h"//header file for motor control
#include "UbiquityMotor.h"//header file for ultrasonic sensor
#include "LcdFunctions.h"//header file for ultrasonic sensor
#include "UltraSound.h"//header file for ultrasonic sensor
#include "stdint.h"
//#include "RemoteFunctions.h"

/* NOTE: Please follows code style provided. All tabs is 4 space */

/*****************************************************************************
 Define
************************"******************************************************/
#define SYS_TICK_MS 500 /* Software Timer with 500 ms */
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10

#define TOF_TOTAL               2
#define TOF_IRQ_TIMEOUT_MS		200

// Motor control
#define MOTOR_TICK_MS           10

// Speaker
#define AudioTime 500

// Ultrasonic sensor
//#define TOTAL_USONIC            2U
#define TOTAL_USONIC            4U
#define USONIC_TICK_MS          100U  // measure ultrasound distances every USONIC_TICK_MS ms
#define USONIC_ECHO_TIMEOUT     200U // timeout if no ECHO back

#define LeftUSupperLimit 30
#define LeftUSlowerLimit 12

#define RightUSupperLimit 30
#define RightUSlowerLimit 12

#define FrontUSupperLimit 45
#define FrontUSlowerLimit 25

#define BackUSupperLimit 40
#define BackUSlowerLimit 25

#define TofLeftUpperLimit 62
#define TofLeftLowerLimit 35

#define TofRightUpperLimit 60
#define TofRightLowerLimit 35


/*****************************************************************************
 Type definition
******************************************************************************/
typedef union _tagUS_Status
{
    uint32_t Status;    
    struct
    {
      uint32_t bUSonic0 :1;
      uint32_t bUSonic1 :1;
      uint32_t bUSonic2 :1;
      uint32_t bUSonic3 :1;
	  uint32_t bError0 	:1;
      uint32_t bError1 	:1;
      uint32_t bError2 	:1;
      uint32_t bError3 	:1;
      uint32_t Reserved :24;
    }b;
}US_STATUS, *PUS_STATUS;

/*****************************************************************************
 Global Variables
******************************************************************************/
void main_Delayms( int nMs );
static volatile int     	g_nSysTick = SYS_TICK_MS;
static volatile BOOL    	g_bSysTickReady = FALSE;
static volatile BOOL    	g_bToggle = FALSE;
static volatile BOOL    	g_bToggle1 = FALSE;
static int 					g_nDelayms = 0;
static SPIM_HANDLE			g_SpimHandle;
static GUI_DATA				g_aBuf[LCD_BUF_SIZE];
static GUI_MEMDEV			g_MemDev;
volatile BOOL 				g_bLcdFree  = TRUE;

static volatile int     	g_nLCDTick = LCD_UPDATE_MS;
static volatile BOOL    	g_nLCDTickReady = FALSE;

volatile uint32_t         	g_nCount = 0;
volatile uint32_t			g_nTimeSec = 0;//this is to keep track of the time in seconds

static TIMER_HANDLE     	g_Timer1Handle; /* This is timer 1 handle */
static TIMER_HOOK       	g_TImer1Hook;    /* This is hook 1 to timer 1 */

static I2C_HANDLE			g_I2cHandle;
static I2C_HOOK             g_I2cHook;

VL53L0X_Dev_t 		g_hDistSensor[TOF_TOTAL];//distance sensor to be used i
static volatile BOOL        g_bDistSensorX = FALSE;//distance sensor flag
int					g_nDistData[TOF_TOTAL] = {0};//distance data stored in an array
static volatile int			g_nTofTrigCount = 0;
static volatile BOOL        g_bTofTriggered = FALSE;
static int                  g_nToFSensorCount = 0;
static volatile int			g_ToFIRQTimeoutCnt = 0;

// Remote control handle

// Declare motor control handle
static UART_HANDLE           g_UartMCBHandle;
static char                  g_aUartMCBTxBuf[64];
static char                  g_aUartMCBRxBuf[64];
static volatile BOOL         g_abUartMCBReady = FALSE;

static volatile int          g_nMotorTick = MOTOR_TICK_MS;
static volatile BOOL         g_bMotorTickReady = FALSE;

static UART_HANDLE          g_UartSpeakerHandle;
static char                 g_aUartSpeakerTxBuf[64];
static char                 g_aUartSpeakerRxBuf[64];
static volatile BOOL        g_abUartSpeakerReady = FALSE;

volatile BOOL motor_status = FALSE;
volatile BOOL remote_status = FALSE;
volatile char motor_direction[10] = " ";  // Motor direction



/*****************************************************************************
 Const Local Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/

// Ultrasonic sensor
static USONIC_HANDLE         g_USHandles[TOTAL_USONIC];
static volatile US_STATUS    g_USonicStatus;
static volatile int          g_nUSonicTick = USONIC_TICK_MS;
static volatile BOOL         g_bUSonicTickReady = FALSE;
volatile BOOL USonicError = FALSE;  // Error flag for ultrasonic sensor 0
volatile BOOL USonicError1 = FALSE;  // Error flag for ultrasonic sensor 1
volatile int USonicDist = 0;  // Distance for ultrasonic sensor 0
volatile int USonicDist1 = 0;  // Distance for ultrasonic sensor 1
//adding 2 more ultrasonic sensors
volatile BOOL USonicError2 = FALSE;  // Error flag for ultrasonic sensor 0
volatile BOOL USonicError3 = FALSE;  // Error flag for ultrasonic sensor 1
volatile int USonicDist2 = 0;  // Distance for ultrasonic sensor 0
volatile int USonicDist3 = 0;  // Distance for ultrasonic sensor 1

//Speaker


/*****************************************************************************
Control flags(Global Variables)
******************************************************************************/
volatile int mode = 0;  // Mode flag for manual and autonomous mode
volatile BOOL AutoDir = TRUE;  // Direction flag for autonomous mode
volatile int Obstacle = 0;  // Obstacle counter for autonomous mode
volatile BOOL MoveFront = FALSE;  // Obstacle detected flag for autonomous mode
volatile BOOL TurnLeft = FALSE;  // Obstacle detected flag for autonomous mode
volatile BOOL TurnRight = FALSE;  // Obstacle detected flag for autonomous mode 100:10 ratio
volatile BOOL STOP = FALSE;  // Obstacle detected flag for autonomous mode
volatile BOOL RotateRight= FALSE;  // Obstacle detected flag for autonomous mode
volatile BOOL RotateLeft= FALSE;  // Obstacle detected flag for autonomous mode
volatile int TofRight;  // Obstacle detected flag for autonomous mode
volatile int TofLeft;  // Obstacle detected flag for autonomous mode
BOOL TurnToggle=FALSE;
BOOL TurnToggle1 = FALSE;

uint32_t currentTime = 0;  // current time
uint32_t SpeakerStartTime = 0; // previous time

/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void );
static void main_I2cInit( void );
static void main_vl53Init( void );
static void motor_UartInit( void );
static void main_UltraSoundInit( void );
static void compareSensors(void);
static void main_Speaker(int nFileIndex);
void PlaySpeakerSound();

/*****************************************************************************
 Callback functions
******************************************************************************/
static void main_cbI2cDone( void );
static void main_cbUS0OnTrigger( BOOL bON );
static void main_cbUS1OnTrigger( BOOL bON );
static void main_cbUS2OnTrigger( BOOL bON );
static void main_cbUS3OnTrigger( BOOL bON );
static void main_cbUS0OnReady( int Error );
static void main_cbUS1OnReady( int Error );
static void main_cbUS2OnReady( int Error );
static void main_cbUS3OnReady( int Error );
void WallHug_control(void);
static void main_cbUartSpeakerOnRx( void );
/*****************************************************************************
 Interrupt functions
******************************************************************************/
void EXTI13_BTN_IRQHandler( uint32_t irqStatus);//Interrupt handler for the button
/*****************************************************************************
 Implementation 
******************************************************************************/
int main( void )
{
	char *cmd;
	int dist = 0;
	BOOL res;
	
    BSPInit( );
	/* Generate interrupt each 1 ms as system tick */
	SysTick_Config( SystemCoreClock / 1000 );
	TRACE("SystemCoreClock %dHz\r\n", SystemCoreClock);
	main_SpimInit();
	main_I2cInit();
	main_vl53Init();
	LCD_Init(&g_SpimHandle);
	motor_UartInit();
	MotorsInit(&g_UartMCBHandle);
	MotorsSetSpeeds(25, 25);
	
	TimerInit( &g_Timer1Handle, 1U, 10000 );
	main_UltraSoundInit();
	/* Start timer 1 now */
    TimerStart( &g_Timer1Handle );
	
	/* NVIC Interrupt enable */
    IRQInit();
	USonicTrigger(&g_USHandles[0]);
	//clear serial buffer
	SerialRxEmpty(&g_UartMCBHandle);
	SerialTxEmpty(&g_UartMCBHandle);

	 
	/* Runtime for loop */
	for(;;)
    {	
		PlaySpeakerSound();
		WallHug_control();
		g_bStop=FALSE;
        if( FALSE != g_nLCDTickReady )
		{
			if( 0 != g_bLcdFree )
			{
				g_nLCDTickReady = FALSE;
				g_bLcdFree = FALSE;
				/* Draw every block.Consume less time  */
				GUI_Draw_Exe(); 
			}
		}
		
		if( FALSE != g_bDistSensorX )
        {
            g_bDistSensorX = FALSE;
			
			if(0 == g_ToFIRQTimeoutCnt )
			{
				TRACE("TOF%d:IRQ Timeout. Reading might not be trusted\r\n", g_nToFSensorCount);
			}

			res = DistSensorRead( 
					&g_hDistSensor[g_nToFSensorCount], 
					&g_nDistData[g_nToFSensorCount] );
			
			if( TRUE == res )
			{
				TRACE("TOF%d: %d mm\r\n", g_nToFSensorCount, g_nDistData[g_nToFSensorCount]);//access the distance data from the distance sensor
				//access tof1 sensor data 
				if (g_nToFSensorCount == 0 ){
					// store tof data in variable
					TofLeft = g_nDistData[g_nToFSensorCount]/10;
					compareSensors();
				}
				//access tof2 sensor data
				if (g_nToFSensorCount == 1) {
					// store tof data in variable
					TofRight = g_nDistData[g_nToFSensorCount]/10;
					compareSensors();

				}
			}
			else
			{
				TRACE("TOF%d:Error\r\n", g_nToFSensorCount);
			}
			
			//Round robin kick the sensors
			g_nToFSensorCount++;
			
			if(g_nToFSensorCount>=TOF_TOTAL)
			{
				g_nToFSensorCount = 0;
			}
	
			res = DistSensorStart( &g_hDistSensor[g_nToFSensorCount] );
			if( FALSE == res )
			{
				TRACE("TOF%d:Error\r\n", g_nToFSensorCount);
			}
			g_ToFIRQTimeoutCnt = TOF_IRQ_TIMEOUT_MS;
        }

		// Handle motor tick
		if (FALSE != g_bMotorTickReady)
        {
            g_bMotorTickReady = FALSE;
            MotorOnTimer(); // shall maintain at 50ms as required by ubiquity MCB
        }
		
		// Handle UART motor control board
		if (0 != g_abUartMCBReady)
        {
            g_abUartMCBReady = FALSE;
            SerialRxEmpty(&g_UartMCBHandle); // Ignore incoming Uart bytes from MCB. Not in use.
        }

		// Handle ultrasonic sensor tick
		if (FALSE != g_bUSonicTickReady)
		{
			g_bUSonicTickReady = FALSE;

//-----BACK Ultrasonic sensor-----------------------------------------------------
			if (FALSE != g_USonicStatus.b.bUSonic0)
			{
				g_USonicStatus.b.bUSonic0 = FALSE;
				
				if (FALSE != g_USonicStatus.b.bError0)
				{
					g_USonicStatus.b.bError0 = FALSE;
					TRACE("US0: Err: Sensor fault ");
					// Set error flag
					USonicError = TRUE;
				}
				else
				{
					USonicError = FALSE;
					dist = USonicRead(&g_USHandles[0]);
					TRACE("US0: %d cm ", dist / 100);
					USonicDist = dist / 100;
					}
				}

				USonicTrigger(&g_USHandles[1]);//
		}

//----- Left Ultrasonic sensor-----------------------------------------------------
		if (FALSE != g_USonicStatus.b.bUSonic1)
		{
			g_USonicStatus.b.bUSonic1 = FALSE;
			
			if (FALSE != g_USonicStatus.b.bError1)
			{
				g_USonicStatus.b.bError1 = FALSE;
				TRACE("US1: Err: Sensor fault\r\n ");
				// Set error flag
				USonicError1 = TRUE;
				
			}
			else
			{
				USonicError1 = FALSE;
				dist = USonicRead(&g_USHandles[1]);
				TRACE("US1: %d cm\r\n", dist / 100);
				USonicDist1 = dist / 100;
			}
			
			USonicTrigger(&g_USHandles[2]);
		}
//-----Front Ultrasonic sensor-----------------------------------------------------
		if (FALSE != g_USonicStatus.b.bUSonic2)
		{
			g_USonicStatus.b.bUSonic2 = FALSE;
			
			if (FALSE != g_USonicStatus.b.bError2)
			{
				g_USonicStatus.b.bError2 = FALSE;
				TRACE("US2: Err: Sensor fault\r\n ");
				// Set error flag
				USonicError2 = TRUE;
				
			}
			else
			{
				USonicError2 = FALSE;
				dist = USonicRead(&g_USHandles[2]);
				TRACE("US2: %d cm\r\n", dist / 100);
				USonicDist2 = dist / 100;
			}
			
			USonicTrigger(&g_USHandles[3]);
		}
//-----Right Ultrasonic sensor-----------------------------------------------------
		if (FALSE != g_USonicStatus.b.bUSonic3)
		{
			g_USonicStatus.b.bUSonic3 = FALSE;
			
			if (FALSE != g_USonicStatus.b.bError3)
			{
				g_USonicStatus.b.bError3 = FALSE;
				TRACE("US3: Err: Sensor fault\r\n ");
				// Set error flag
				USonicError3 = TRUE;
				
			}
			else
			{
				USonicError3 = FALSE;
				dist = USonicRead(&g_USHandles[3]);
				TRACE("US3: %d cm\r\n", dist / 100);
				USonicDist3 = dist / 100;
				
			}
			
			USonicTrigger(&g_USHandles[0]);
		}
	}
}


/*****************************************************************************
 Callback functions
******************************************************************************/


static void main_cbMCBOnRx( void )
{
   g_abUartMCBReady  = TRUE;
}
static void main_cbUS0OnTrigger( BOOL bON )
{
  US0_TRIG_SET( bON );
}

static void main_cbUS1OnTrigger( BOOL bON )
{
  US1_TRIG_SET( bON );
}
static void main_cbUS2OnTrigger( BOOL bON )
{
  US2_TRIG_SET( bON );
}
static void main_cbUS3OnTrigger( BOOL bON )
{
  US3_TRIG_SET( bON );
}
static void main_cbUS0OnReady( int Error )
{
	if( USONIC_SUCCESS != Error )
	{
		g_USonicStatus.b.bError0 = TRUE;
	}
	else
	{
		g_USonicStatus.b.bError0 = FALSE;
	}
	g_USonicStatus.b.bUSonic0 = TRUE;
	compareSensors();
}

static void main_cbUS1OnReady( int Error )
{
	if( USONIC_SUCCESS != Error )
	{
		g_USonicStatus.b.bError1 = TRUE;
	}
	else
	{
		g_USonicStatus.b.bError1 = FALSE;
	}
	
	g_USonicStatus.b.bUSonic1 = TRUE;//this is a flag to indicate that the ultrasonic sensor 1 is ready
	compareSensors();
}

static void main_cbUS2OnReady( int Error )
{
	if( USONIC_SUCCESS != Error )
	{
		g_USonicStatus.b.bError2 = TRUE;
	}
	else
	{
		g_USonicStatus.b.bError2 = FALSE;
	}
	
	g_USonicStatus.b.bUSonic2 = TRUE;//this is a flag to indicate that the ultrasonic sensor 2 is ready
	compareSensors();
}

static void main_cbUS3OnReady( int Error )
{
	if( USONIC_SUCCESS != Error )
	{
		g_USonicStatus.b.bError3 = TRUE;
	}
	else
	{
		g_USonicStatus.b.bError3 = FALSE;
	}
	
	g_USonicStatus.b.bUSonic3 = TRUE;//this is a flag to indicate that the ultrasonic sensor 3 is ready
	compareSensors();
}

void WallHug_control(void)

{
    if (mode > 0) // Autonomous mode
	{
		if( FALSE != g_bSysTickReady )
		{
			g_bSysTickReady = FALSE;

			/* Every 500ms per tick */  


			g_bToggle = !g_bToggle;
			g_bToggle1 = !g_bToggle1;
		}
		//clear serial buffer to clear the buffer
		SerialRxEmpty(&g_UartMCBHandle);

		// Initialize g_bStop to FALSE at the beginning

		if (TurnLeft) {
			LED_1_OFF();
			g_bStop = FALSE;
			LED_2_SET(g_bToggle1);
			MotorsSetSpeeds(25, 25);
			MotorsArcLeft();
		}

		if (TurnRight) {
			LED_2_OFF();
			g_bStop = FALSE;
			LED_1_SET(g_bToggle);
			MotorsSetSpeeds(25, 25);
			MotorsArcRight();
			// Ensure other movements are not performed
		}

		if (MoveFront) {
			LED_2_SET(g_bToggle);
			LED_1_SET(g_bToggle);
			g_bStop = FALSE;
			MotorsSetSpeeds(25,25);
			MotorsMoveFront();
		}

		if (STOP) {
			LED_1_OFF();
			LED_2_OFF();
			g_bStop = TRUE;
			MotorsStop();
		}

		if (RotateRight) {
			LED_2_OFF();
			g_bStop = FALSE;
			LED_1_SET(g_bToggle);
			MotorsSetSpeeds(25, 25);
			MotorsRotateRight();
			// Ensure other movements are not performed
		}
		if (RotateLeft) {
			LED_1_OFF();
			g_bStop = FALSE;
			LED_2_SET(g_bToggle1);;
			MotorsSetSpeeds(25, 25);
			MotorsRotateLeft();
			// Ensure other movements are not performed
		}

		// Reset direction flags
		TurnLeft = TurnRight = MoveFront = STOP = RotateRight = RotateLeft = false;

		motor_direction[sizeof(motor_direction) - 1] = '\0'; // Ensure null-termination
	}
}

static void main_cbI2cDone( void )//call
{
	DistI2cInterruptHandler( &g_hDistSensor[g_nToFSensorCount] );
}

static void main_cbUartSpeakerOnRx( void )
{
    g_abUartSpeakerReady = TRUE;
}



/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void )
{
	SpimInit(
        &g_SpimHandle,
        2,
        15000000U, 
        SPI_CLK_INACT_LOW,
        SPI_CLK_RISING_EDGE,
        SPI_DATA_SIZE_8 );
}


static void main_I2cInit( void )
{
	int res;
	NVIC_SetPriority( I2C1_EV_IRQn, 0x09 );
	res = I2cInit( &g_I2cHandle, 1U, 400000U ); /* I2C1 */
	ASSERT( I2C_STS_OK == res );

    I2cAddHook(
       &g_I2cHandle,
       &g_I2cHook,
       main_cbI2cDone );
}
static void main_vl53Init( void )
{
	/* Distance Sensor 1 */
    TOF1_XSHUT_OFF();
    TOF2_XSHUT_OFF();
    main_Delayms( 1000 );

    /* Enable Sensor 1 XSHUT to change its address before configuration */
    TOF1_XSHUT_ON();
    g_nToFSensorCount = 0; /* We define 0 for senseor 1, 1 for sensor 2 */
    main_Delayms( 1000 );

    DistSensorInit( &g_hDistSensor[0], &g_I2cHandle, 0x52 );
    DistSensorSetDevAddress( &g_hDistSensor[0], 0x02 );
    DistSensorConfigure( &g_hDistSensor[0], TOF_MODE_LONG_RANGE );
    main_Delayms( 1000 );
	
#if (TOF_TOTAL>1)
    /* Enable Sensor 2 XSHUT to change its address before configuration */
    TOF2_XSHUT_ON();
    g_nToFSensorCount = 1;
    main_Delayms( 1000 );

    DistSensorInit( &g_hDistSensor[1], &g_I2cHandle, 0x52 );
    DistSensorSetDevAddress( &g_hDistSensor[1], 0x06 );
    DistSensorConfigure( &g_hDistSensor[1], TOF_MODE_LONG_RANGE );
    main_Delayms( 1000 );
#endif
    g_nToFSensorCount = 0;
    DistSensorStart( &g_hDistSensor[0] );
	g_ToFIRQTimeoutCnt = TOF_IRQ_TIMEOUT_MS;
}

void main_Delayms( int nMs )
{
	g_nDelayms = nMs;
	
	while( 0 != g_nDelayms ){}
}

static void motor_UartInit( void )
{
    int res = SerialInit( &g_UartMCBHandle, 1, 38400 );
    ASSERT( res == UART_STS_OK );
	(res == UART_STS_OK)?(motor_status = TRUE):(motor_status = FALSE);

    SerialConfig(
    	&g_UartMCBHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartMCBHandle, 
    	g_aUartMCBTxBuf,
    	sizeof(g_aUartMCBTxBuf),
    	g_aUartMCBRxBuf,
    	sizeof(g_aUartMCBRxBuf) );

   SerialAddCallback( &g_UartMCBHandle, 0, main_cbMCBOnRx );

    res = SerialInit( &g_UartSpeakerHandle, 5, 9600 );
    ASSERT( res == UART_STS_OK );

    SerialConfig(
      &g_UartSpeakerHandle, 
      UART_BITS_8, 
      UART_NONE,
      UART_ONE );

   SerialBuffer(
      &g_UartSpeakerHandle, 
      g_aUartSpeakerTxBuf,
      sizeof(g_aUartSpeakerTxBuf),
      g_aUartSpeakerRxBuf,
      sizeof(g_aUartSpeakerTxBuf) );

   SerialAddCallback( &g_UartSpeakerHandle, 0, main_cbUartSpeakerOnRx );
}

static void main_UltraSoundInit( void )
{
  /* Ultrasonic initialization */
  USonicInit( &g_Timer1Handle, 10000 );
  
  /* Add a callback to get notify when ultrasonic sensor is ready to be read */
  UsonicAddDevice( &g_USHandles[0], 0U, main_cbUS0OnTrigger, main_cbUS0OnReady );
  UsonicAddDevice( &g_USHandles[1], 1U, main_cbUS1OnTrigger, main_cbUS1OnReady );
  UsonicAddDevice( &g_USHandles[2], 2U, main_cbUS2OnTrigger, main_cbUS2OnReady );
  UsonicAddDevice( &g_USHandles[3], 3U, main_cbUS3OnTrigger, main_cbUS3OnReady );
}
 


/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler( void )
{
	g_nCount++;
	currentTime++;
	if (g_nCount == 1000)
	{
		//g_bSecTick = TRUE;
		g_nCount=0;
		
		/* Keep track of time based on 1 sec interval */ 
		g_nTimeSec++;
		if(g_nTimeSec > 24*60*60)
		{
			g_nTimeSec = 0;
		}
	}
	
	if(0 != g_nDelayms)
	{
		g_nDelayms--;
	}

	if( 0 != g_nSysTick ) // g_nSysTick counts down from SYS_TICK_MS
	{
		g_nSysTick--;
		if( 0 == g_nSysTick )
		{
			g_nSysTick = SYS_TICK_MS;
			g_bSysTickReady = TRUE;
		}
	}

	if( 0 != g_nLCDTick )
	{
		g_nLCDTick--;
		if( 0 == g_nLCDTick )
		{
			g_nLCDTick = LCD_UPDATE_MS;
			g_nLCDTickReady = TRUE;
		}
	}
	
	if( 0 != g_ToFIRQTimeoutCnt )
	{
		g_ToFIRQTimeoutCnt--;
		if( 0 == g_ToFIRQTimeoutCnt )
		{
			g_bDistSensorX = TRUE;
		}
	}
	if( 0 != g_nMotorTick )
    {
        g_nMotorTick--;

        if( 0 == g_nMotorTick )
        {
            g_nMotorTick = MOTOR_TICK_MS;
            g_bMotorTickReady = TRUE;
		}
	}
		if( 0 != g_nUSonicTick )
    {
        g_nUSonicTick--;

        if( 0 == g_nUSonicTick )
        {
            g_nUSonicTick = USONIC_TICK_MS;
            g_bUSonicTickReady = TRUE;
        }
    }
}

void EXTI10_DIST1_RDY_IRQHandler( uint32_t Status )
{
    UNUSE( Status );

    g_bDistSensorX = TRUE;
}

void EXTI11_DIST2_RDY_IRQHandler( uint32_t Status )
{
    UNUSE( Status );

    g_bDistSensorX = TRUE;
}
void EXTI2_US0_ECHO_IRQHandler( uint32_t Status )
{
	UsonicISR( &g_USHandles[0], IN_US0_ECHO() );// Ultrasonic sensor 0 echo interrupt,syntax is 
}

void EXTI5_US1_ECHO_IRQHandler( uint32_t Status )
{
	UsonicISR( &g_USHandles[1], IN_US1_ECHO() );// Ultrasonic sensor 1 echo interrupt, takes in the ultrasonic sensor handle and the echo status
}
void EXTI6_US2_ECHO_IRQHandler( uint32_t Status )
{
	UsonicISR( &g_USHandles[2], IN_US2_ECHO() );// Ultrasonic sensor 2 echo interrupt, takes in the ultrasonic sensor handle and the echo status
}
void EXTI7_US3_ECHO_IRQHandler( uint32_t Status )
{
	UsonicISR( &g_USHandles[3], IN_US3_ECHO() );// Ultrasonic sensor 3 echo interrupt, takes in the ultrasonic sensor handle and the echo status
}
void EXTI13_BTN_IRQHandler(uint32_t irqStatus)
{
    if ((EXTI->PR1 & EXTI_PR1_PIF13) != 0)  // Check if EXTI line 13 caused the interrupt
    {
	    // Handle button press here
        if (BTN_READ())
        {
			mode += 1;
			TRACE("Button pressed\n\r");
			g_bStop = FALSE;// Disengage the stop flag when switching to manual mode, stopp
			MotorsStop();
			SerialRxEmpty(&g_UartMCBHandle);	
        }
    }
}

void compareSensors(void)
{
	if (mode == 1)
    {
        //US2=Front sensor
        //US1=Left sensor
        //US0=Back sensor
        //US3=Right sensor
        //clear serial buffer

		if( FALSE != g_bSysTickReady )
		{
			g_bSysTickReady = FALSE;

			/* Every 500ms per tick */    
			LED_2_SET(g_bToggle);
			LED_1_SET(g_bToggle);


			g_bToggle = !g_bToggle;
			g_bToggle1 = !g_bToggle1;
		}

        // Initialize all movement flags to default values
        MoveFront = false;
		TurnLeft = false;
		TurnRight = false;
		STOP = false;
		RotateLeft= false;
		RotateRight= false;

		g_bStop = FALSE;


        if (USonicDist2 < FrontUSlowerLimit) {
            // Stop if there’s an obstacle in front
            MoveFront = false;
            TurnLeft = false;
            TurnRight = false;
            STOP = true;
			RotateLeft= FALSE;
			RotateRight= FALSE;

			g_bStop = TRUE;
        } 

		else{

			if (TofLeft > TofLeftUpperLimit ) {
				// Turn left if TofLeft is too high
				TurnLeft = true;

				MoveFront = false;
				TurnRight = false;
				STOP = false;
				RotateLeft= FALSE;
				RotateRight= FALSE;

			}
			if ( USonicDist1 < LeftUSlowerLimit) {
				// Turn left if TofLeft is too high
				RotateLeft = false;

				MoveFront = true;
				TurnRight = false;
				STOP = false;
				TurnLeft = false;
				RotateRight= false;
			}

			else if(TofLeft > TofLeftLowerLimit && TofLeft < TofLeftUpperLimit) {
				// Move forward if TofLeft is within limits
				MoveFront = true;

				TurnLeft = false;
				TurnRight = false;
				STOP = false;
				RotateLeft= FALSE;
				RotateRight= FALSE;
			}

			else if (TofLeft < TofLeftLowerLimit) {
				// Turn right if TofLeft is too low
				TurnRight = true;

				MoveFront = false;
				TurnLeft = false;
				STOP = false;
				RotateLeft= FALSE;
				RotateRight= FALSE;
			}
		}
        // If none of the conditions match, the default state is already set
    }

	if (mode == 2)
    {
        //US2=Front sensor
        //US1=Left sensor
        //US0=Back sensor
        //US3=Right sensor
        //clear serial buffer

        // Initialize all movement flags to default values
        MoveFront = false;
		TurnLeft = false;
		TurnRight = false;
		STOP = false;
		RotateLeft= false;
		RotateRight= false;

		g_bStop = FALSE;


        if (USonicDist2 < FrontUSlowerLimit) {
            // Stop if there’s an obstacle in front
            MoveFront = false;
            TurnLeft = false;
            TurnRight = false;
            STOP = true;
			RotateLeft= FALSE;
			RotateRight= FALSE;

			g_bStop = TRUE;
        } 

		else{

			if (TofRight > TofRightUpperLimit ) {
				// Turn left if TofLeft is too high
				TurnRight = true;

				MoveFront = false;
				TurnLeft = false;
				STOP = false;
				RotateLeft= FALSE;
				RotateRight= FALSE;

			}
			if ( USonicDist3 < RightUSlowerLimit) {
				// Turn left if TofLeft is too high
				MoveFront = true;

				TurnRight = false;
				TurnLeft = false;
				STOP = false;
				RotateLeft= FALSE;
				RotateRight= FALSE;
			}

			else if(TofRight > TofRightLowerLimit && TofRight < TofRightUpperLimit) {
				// Move forward if TofLeft is within limits
				MoveFront = true;

				TurnLeft = false;
				TurnRight = false;
				STOP = false;
				RotateLeft= FALSE;
				RotateRight= FALSE;
			}

			else if (TofRight < TofRightLowerLimit) {
				// Turn right if TofLeft is too low
				TurnLeft = true;

				MoveFront = false;
				TurnRight = false;
				STOP = false;
				RotateLeft= FALSE;
				RotateRight= FALSE;
			}
		}
        // If none of the conditions match, the default state is already set
    }
}

static void main_Speaker(int nFileIndex )
{
  static uint8_t cmd[6] = {0xAA, 0x07, 0x02, 0x00, 0x02, 0xB5};
  
  memcpy(&cmd[3], &nFileIndex, 2);
  cmd[3] = (uint8_t)(nFileIndex>>8U);
  cmd[4] = (uint8_t)(nFileIndex);
  cmd[5] = cmd[0]+ cmd[1] + cmd[2]+cmd[3]+cmd[4];
  
  SerialWriteEx( &g_UartSpeakerHandle, cmd, sizeof(cmd) );
  
}

void PlaySpeakerSound(){

	//STOP 1,2
	//TurnRight 3
	//TurnLeft 4
	//Move Back 5
	//Move Front 6

	//As it starts from zero, all -1
	if (currentTime - SpeakerStartTime > AudioTime) {//play the sound after 2 second
		if (TurnLeft) {
			main_Speaker(3);
			SpeakerStartTime = currentTime;
		}
		if (TurnRight) {
			main_Speaker(2);
			SpeakerStartTime = currentTime;
		}

		if (MoveFront) {
			main_Speaker(5);
			SpeakerStartTime = currentTime;
		}

		if (STOP) {
			main_Speaker(1);
			SpeakerStartTime = currentTime;
		}

		if (RotateRight) {
			main_Speaker(2);
			SpeakerStartTime = currentTime;
		}
		if (RotateLeft) {
			main_Speaker(3);
			SpeakerStartTime = currentTime;
		}
	}
}