/*****************************************************************************
 @Project	: 
 @File 		: UbiquityMotor.h
 @Details  	:              
 @Author	: LianChai (lianchai.gan@digipen.edu)
 @Hardware	: Platform dependent on Ubiquity Robot MCB
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     XXXX-XX-XX  		Initial Release
   
******************************************************************************/


#ifndef __MOTORS_DOT_H__
#define __MOTORS_DOT_H__

/*****************************************************************************
 Define
******************************************************************************/
#define   CMD_MCB_STX                    0x7E 
#define   CMD_MCB_R                      0x3a 
#define   CMD_MCB_W                      0x3b 
#define   CMD_MCB_RES                    0x3c 
#define   CMD_MCB_ERROR                  0x3d 
#define   CMD_MCB_DEPRECATED0            0x00 
#define   CMD_MCB_BRAKE_STOP             0x01 
#define   CMD_MCB_DEPRECATED2            0x02 
#define   CMD_MCB_LEFT_PWM               0x03 
#define   CMD_MCB_RIGHT_PWM              0x04 
#define   CMD_MCB_DEPRECATED5            0x05 
#define   CMD_MCB_DEPRECATED6            0x06 
#define   CMD_MCB_LEFT_MOTOR_SPEED_SET   0x07 
#define   CMD_MCB_RIGHT_MOTOR_SPEED_SET  0x08 
#define   CMD_MCB_DEPRECATED9            0x09 
#define   CMD_MCB_DEPRECATED10           0x0a 
#define   CMD_MCB_LEFT_MOTOR_TICKS       0x0b 
#define   CMD_MCB_RIGHT_MOTOR_TICKS      0x0c 
#define   CMD_MCB_DEADMAN_TIMER          0x0d 
#define   CMD_MCB_LEFT_CUR_SENSE         0x0e 
#define   CMD_MCB_RIGHT_CUR_SENSE        0x0f 
#define   CMD_MCB_ERROR_COUNT            0x10 
#define   CMD_MCB_ERROR_5V_MAIN          0x11 
#define   CMD_MCB_ERROR_5V_AUX           0x12 
#define   CMD_MCB_ERROR_12V_MAIN         0x13 
#define   CMD_MCB_ERROR_12V_AUX          0x14 
#define   CMD_MCB_OL_5V_MAIN             0x15 
#define   CMD_MCB_OL_5V_AUX              0x16 
#define   CMD_MCB_OL_12V_MAIN            0x17 
#define   CMD_MCB_OL_12V_AUX             0x18 
#define   CMD_MCB_ERROR_LEFT_MOTOR       0x19 
#define   CMD_MCB_ERROR_RIGHT_MOTOR      0x1a 
#define   CMD_MCB_PID_P                  0x1b 
#define   CMD_MCB_PID_I                  0x1c 
#define   CMD_MCB_PID_D                  0x1d 
#define   CMD_MCB_PID_C                  0x1e 
#define   CMD_MCB_DEBUG_LED1             0x1f 
#define   CMD_MCB_DEBUG_LED2             0x20 
#define   CMD_MCB_HW_VER                 0x21 
#define   CMD_MCB_FW_VER                 0x22 
#define   CMD_MCB_BATT_LEVEL_MV          0x23 
#define   CMD_MCB_CS_5V_MAIN             0x24 
#define   CMD_MCB_CS_12V_MAIN            0x25 
#define   CMD_MCB_CS_5V_AUX              0x26 
#define   CMD_MCB_CS_12V_AUX             0x27 
#define   CMD_MCB_LEFT_MOTOR_SPEED_RO    0x28 
#define   CMD_MCB_RIGHT_MOTOR_SPEED_RO   0x29 
#define   CMD_MCB_BOTH_MOTOR_SPEED_SET   0x2a 
#define   CMD_MCB_MOVING_BUF_Size        0x2b 
#define   CMD_MCB_INTEGRAL_LIMIT_HIT_RO  0x2c 
#define   CMD_MCB_BOTH_MOTOR_ERROR_RO    0x2D 
#define   CMD_MCB_BOTH_ODOM_RO           0x30 
#define   CMD_MCB_ROBOT_ID_RO            0x31 

#include"stdbool.h"

/*****************************************************************************
 Type definition
******************************************************************************/
#pragma pack(push,1)

typedef union _tagUbiMCBPkt
{
    uint8_t aData[8];

    struct
    {
        uint8_t STX;
        uint8_t CmdType;
        uint8_t Cmd;
        uint8_t payload[4];
        uint8_t Cs;
    }cmd;

       struct
    {
        uint8_t STX;
        uint8_t CmdType;
        uint8_t Cmd;
		uint8_t SpeedL_MSB;
        uint8_t SpeedL_LSB;
        uint8_t SpeedR_MSB;
        uint8_t SpeedR_LSB;
        uint8_t Cs;
    }BothSpeed;

}UBIMCB_PKT, *PUBIMCB_PKT;

#pragma pack(pop)

typedef enum _tagMove_State
{
    MOVE_NONE = 0,
	MOVE_FWD,
	MOVE_BWD,
	MOVE_LEFT,
	MOVE_RIGHT,
	MOVE_FRONT_LEFT,
	MOVE_FRONT_RIGHT,
	MOVE_BACK_LEFT,
	MOVE_BACK_RIGHT,
	MOVE_ROTATE_LEFT,
	MOVE_ROTATE_RIGHT,
	MOVE_ADJUST_WAIT,
	MOVE_ADJUST_DONE,
	MOVE_STOP
}MOVE_STATE_NUM;

extern volatile BOOL g_bStop;
/*****************************************************************************
 Macro
******************************************************************************/


/******************************************************************************
 Global functions
******************************************************************************/


/******************************************************************************
 @Description 	: 

 @param			: 
 
 @revision		: 1.0.0
 
******************************************************************************/
void MotorsInit( void *pUartHandle );
void MotorsSetSpeeds( int nSpeedLeft, int nSpeedRight );
void MotorsSpeedIncrement( void );
void MotorsSpeedDecrement( void );
void MotorsMoveFront( void );
void MotorsMoveBack( void );
void MotorsRotateLeft( void );
void MotorsRotateRight( void );
void MotorsArcLeft( void );
void MotorsArcRight( void );
void MotorsStop( void );
void MotorOnTimer( void );
/******************************************************************************
 @Description 	: 

 @param			: 
 
 @revision		: 1.0.0
 
******************************************************************************/


#endif /* __MOTORS_DOT_H__ */