/*****************************************************************************
 @Project		:
 @File 			: main.c
 @Details  	: Main entry
 @Author		: lcgan
 @Hardware	: STM32
 
 ----------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 ----------------------------------------------------------------------------
   1.0  XXXXXX     12-Feb-2023  	Initial Release
																	
*****************************************************************************/
#include <Common.h>
#include "Hal.h"
#include "BSP.h"
#include "Timer.h"
#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "Serial.h"
#include "Remote.h"
#include "UbiquityMotor.h"

/* NOTE: Please follows code style provided. All tabs is 4 space */

/*****************************************************************************
 Define
************************"******************************************************/
#define SYS_TICK_MS 500 /* Software Timer with 500 ms */
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10

#define MOTOR_TICK_MS           30

/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Const Local Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
static volatile int     	g_nSysTick = SYS_TICK_MS;
static volatile BOOL    	g_bSysTickReady = FALSE;
static volatile BOOL    	g_bToggle = FALSE;

static SPIM_HANDLE			g_SpimHandle;
static GUI_DATA				g_aBuf[LCD_BUF_SIZE];
static GUI_MEMDEV			g_MemDev;
volatile BOOL 				g_bLcdFree  = TRUE;

static volatile int     	g_nLCDTick = LCD_UPDATE_MS;
static volatile BOOL    	g_nLCDTickReady = FALSE;
static uint32_t         	g_nCount = 0;

static uint32_t				g_nTimeSec = 0;

static TIMER_HANDLE     	g_Timer1Handle; /* This is timer 1 handle */
static TIMER_HOOK       	g_TImer1Hook;    /* This is hook 1 to timer 1 */

static UART_HANDLE          g_UartMCBHandle;
static char                 g_aUartMCBTxBuf[64];
static char                 g_aUartMCBRxBuf[64];
static volatile BOOL        g_abUartMCBReady = FALSE;

static UART_HANDLE          g_UartRemoteHandle;
static char                 g_aUartRemoteTxBuf[64];
static char                 g_aUartRemoteRxBuf[64];
static volatile BOOL        g_abUartRemoteReady = FALSE;
static int                  g_nCmd = 0;

static UART_HANDLE          g_UartSpeakerHandle;
static char                 g_aUartSpeakerTxBuf[64];
static char                 g_aUartSpeakerRxBuf[64];
static volatile BOOL        g_abUartSpeakerReady = FALSE;

static volatile int         g_nMotorTick = MOTOR_TICK_MS;
static volatile BOOL        g_bMotorTickReady = FALSE;


/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void );
static void main_LcdInit( void );
static void main_UartInit( void );
static void main_HostCmdExe( char *pCmd );
static void main_Speaker(int nFileIndex );
/*****************************************************************************
 Callback functions
******************************************************************************/
static void main_cbGuiFrameEnd( void );
static void main_cbLcdTransferDone( void );
static void main_cbUartRemoteOnRx( void );
static void main_cbUartSpeakerOnRx( void );

/*****************************************************************************
 Implementation 
******************************************************************************/
int main( void )
{
	char *cmd;
	int dist = 0;
	
    BSPInit( );

	/* Generate interrupt each 1 ms as system tick */
	SysTick_Config( SystemCoreClock / 1000 );

	TRACE("SystemCoreClock %dHz\r\n", SystemCoreClock);

	main_SpimInit();

	main_LcdInit();
	
	main_UartInit();

    MotorsInit( &g_UartMCBHandle );

    MotorsSetSpeeds( 35, 35 );  //Speed at 25 ticks/ 100ms

	TimerInit( &g_Timer1Handle, 1U, 10000 );
	
	/* Start timer 1 now */
    TimerStart( &g_Timer1Handle );
	
	//MotorsMoveFront();

	/* Runtime for loop */
	for(;;)
    {
		if( FALSE != g_bSysTickReady )
		{
			g_bSysTickReady = FALSE;

			/* Every 500ms per tick */    
			LED_LD2_SET(g_bToggle);

			g_bToggle = !g_bToggle;
		}
		
		if( FALSE != g_abUartRemoteReady )
		{
			g_abUartRemoteReady = FALSE;

			cmd = RemoteParse( &g_UartRemoteHandle );
            if( 0 != cmd )
			{
				main_HostCmdExe( cmd );
			}
		}

        if( FALSE != g_nLCDTickReady )
		{
			if( 0 != g_bLcdFree )
			{
				g_nLCDTickReady = FALSE;
				g_bLcdFree = FALSE;
				/* Draw every block.Consume less time  */
				GUI_Draw_Exe(); 
			}
		}
		
		if( FALSE != g_bMotorTickReady )
        {
            g_bMotorTickReady = FALSE;
            MotorOnTimer(); // shall maintain at 50ms as required by ubiquity MCB
        }
		
		if( 0 != g_abUartMCBReady )
        {
            g_abUartMCBReady = FALSE;
            SerialRxEmpty( &g_UartMCBHandle );
            // Ignore incoming Uart bytes from MCB. Not in use.
        }
    }
}

/*****************************************************************************
 Callback functions
******************************************************************************/
void GUI_AppDraw( BOOL bFrameStart )
{
	static char buf0[20],buf1[20],buf2[15];

	if( TRUE == bFrameStart ) // framestart = TRUE indicate the display dynamic area can be updated.
	{
    /* choose one to display - count or time elapsed */
		//g_nCount++;
		//sprintf( buf0, "%08X", g_nCount);
		sprintf( buf0, "%02u:%02u:%02u", (g_nTimeSec/3600)%24, (g_nTimeSec/60)%60, g_nTimeSec%60 );
		
		sprintf (buf1, "%d MHz", SystemCoreClock/1000000);
		sprintf( buf2, "%08X", SCB->CPUID);
	}
		
	/* Set background to blue. Refer to gui.h for color code */
	GUI_Clear( ClrBlue ); 
	GUI_SetFont( &g_sFontCalibri24 );

	/* Display g_nCount string */
	GUI_PrintString( "STM32G474RE", ClrWhite, 5, 1);
	GUI_PrintString( "KEIL V5.36.0.0", ClrWhite, 5, 21 );
	GUI_PrintString( "STLINK-V3E", ClrWhite, 5, 41 );
	GUI_PrintString( buf0, ClrGreenYellow, 5, 61 );
	GUI_PrintString( buf1, ClrYellowGreen , 5, 81 );
	GUI_PrintString( buf2, ClrYellowGreen , 5, 101 );
}

static void main_cbLcdTransferDone( void )
{
	g_bLcdFree = TRUE;
}

static void main_cbGuiFrameEnd( void )
{
	g_bLcdFree = TRUE;
}

static void main_cbMCBOnRx( void )
{
   g_abUartMCBReady  = TRUE;
}

static void main_cbUartRemoteOnRx( void )
{
    g_abUartRemoteReady = TRUE;
}


static void main_cbUartSpeakerOnRx( void )
{
    g_abUartSpeakerReady = TRUE;
}


/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void )
{
	SpimInit(
        &g_SpimHandle,
        2,
        15000000U, 
        SPI_CLK_INACT_LOW,
        SPI_CLK_RISING_EDGE,
        SPI_DATA_SIZE_8 );
}

static void main_LcdInit( void )
{
	int screenx;
	int screeny;
	
	/* g_SpimHandle shall be initialized before use */
	
	/* Choosing a landscape orientation */
	LcdInit( &g_SpimHandle, LCD_LANDSCAPE );
	
	/* Get physical LCD size in pixels */
	LCD_GetSize( &screenx, &screeny );
	
	/* Initialize GUI */
	GUI_Init(
		&g_MemDev,
		screenx,
		screeny,
		g_aBuf,
		sizeof(g_aBuf) );
	
	/* Switch to transfer word for faster performance */
	SpimSetDataSize( &g_SpimHandle, SPI_DATA_SIZE_16 );
	GUI_16BitPerPixel( TRUE );
	
	/* Clear LCD screen to Blue */
	GUI_Clear( ClrBlue );

    /* set font color background */
    GUI_SetFontBackColor( ClrBlue );
    
    /* Set font */
    GUI_SetFont( &g_sFontCalibri10 );
	
	LCD_AddCallback( main_cbLcdTransferDone );
	
	GUI_AddCbFrameEnd( main_cbGuiFrameEnd );
	
	/* Backlight ON */
	LCD_BL_ON();
}

static void main_UartInit( void )
{
    int res = SerialInit( &g_UartMCBHandle, 1, 38400 );
    ASSERT( res == UART_STS_OK );

    SerialConfig(
    	&g_UartMCBHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartMCBHandle, 
    	g_aUartMCBTxBuf,
    	sizeof(g_aUartMCBTxBuf),
    	g_aUartMCBRxBuf,
    	sizeof(g_aUartMCBRxBuf) );

   SerialAddCallback( &g_UartMCBHandle, 0, main_cbMCBOnRx );

  // Remote controller from esp32
    res = SerialInit( &g_UartRemoteHandle, 5, 921600 );
    ASSERT( res == UART_STS_OK );

    SerialConfig(
    	&g_UartRemoteHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartRemoteHandle, 
    	g_aUartRemoteTxBuf,
    	sizeof(g_aUartRemoteTxBuf),
    	g_aUartRemoteRxBuf,
    	sizeof(g_aUartRemoteTxBuf) );

   SerialAddCallback( &g_UartRemoteHandle, 0, main_cbUartRemoteOnRx );

		
  // Speaker
    res = SerialInit( &g_UartSpeakerHandle, 3, 9600 );
    ASSERT( res == UART_STS_OK );

    SerialConfig(
    	&g_UartSpeakerHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartSpeakerHandle, 
    	g_aUartSpeakerTxBuf,
    	sizeof(g_aUartSpeakerTxBuf),
    	g_aUartSpeakerRxBuf,
    	sizeof(g_aUartSpeakerTxBuf) );

   SerialAddCallback( &g_UartSpeakerHandle, 0, main_cbUartSpeakerOnRx );
		
}


static void main_HostCmdExe( char *pCmd )
{
	HOST_REQ_PKT *req = (HOST_REQ_PKT *)pCmd;
  
	
    switch( req->Cmd.Cmd )
    {
        case CMD_HOST_STOP:
			TRACE( "cmd: STOP\r\n" );
			MotorsStop();
			main_Speaker(2);
			
        break;

        case CMD_HOST_MOVE_FWD:
            TRACE( "cmd: FWD\r\n" );
			MotorsMoveFront();
		main_Speaker(4);
        break;

        case CMD_HOST_MOVE_BWD:
            TRACE( "cmd: BWD\r\n" );
			MotorsMoveBack();
		main_Speaker(3);
        break;

        case CMD_HOST_MOVE_LEFT:
            TRACE( "cmd: LEFT\r\n" );
		
        break;

        case CMD_HOST_MOVE_RIGHT:
			TRACE( "cmd: RIGHT\r\n" );
		
        break;
		
		case CMD_HOST_ROTATE_LEFT:
			TRACE( "cmd: ROTATE LEFT\r\n" );
			MotorsRotateLeft();
		main_Speaker(6);
        break;

        case CMD_HOST_ROTATE_RIGHT:
			TRACE( "cmd: ROTATE RIGHT\r\n" );
			MotorsRotateRight();
		main_Speaker(5);
        break;
		
        default:
            TRACE( "cmd: Invalid\r\n" );
			MotorsStop();
        break;
	}
}

static void main_Speaker(int nFileIndex )
{
	static uint8_t cmd[6] = {0xAA, 0x07, 0x02, 0x00, 0x02, 0xB5};
	
	memcpy(&cmd[3], &nFileIndex, 2);
	cmd[3] = (uint8_t)(nFileIndex>>8U);
	cmd[4] = (uint8_t)(nFileIndex);
	cmd[5] = cmd[0]+ cmd[1] + cmd[2]+cmd[3]+cmd[4];
	
	SerialWriteEx( &g_UartSpeakerHandle, cmd, sizeof(cmd) );
	
}
/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler( void )
{
	/* NOTE:
	It is more efficient to compare to 0 for Cortex M
	*/

	g_nCount++;
	if (g_nCount == 1000)
	{
		//g_bSecTick = TRUE;
		g_nCount=0;
		
		/* Keep track of time based on 1 sec interval */ 
		g_nTimeSec++;
		if(g_nTimeSec > 24*60*60)
		{
			g_nTimeSec = 0;
		}
	}

	if( 0 != g_nSysTick ) // g_nSysTick counts down from SYS_TICK_MS
	{
		g_nSysTick--;
		if( 0 == g_nSysTick )
		{
			g_nSysTick = SYS_TICK_MS;
			g_bSysTickReady = TRUE;
		}
	}

	if( 0 != g_nLCDTick )
	{
		g_nLCDTick--;
		if( 0 == g_nLCDTick )
		{
			g_nLCDTick = LCD_UPDATE_MS;
			g_nLCDTickReady = TRUE;
		}
	}
	
	if( 0 != g_nMotorTick )
    {
        g_nMotorTick--;

        if( 0 == g_nMotorTick )
        {
            g_nMotorTick = MOTOR_TICK_MS;
            g_bMotorTickReady = TRUE;
        }
    }
}