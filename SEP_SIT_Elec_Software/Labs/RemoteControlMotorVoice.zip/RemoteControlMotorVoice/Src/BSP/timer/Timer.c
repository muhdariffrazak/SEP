/*****************************************************************************
 @Project	: 
 @File 		: Timer.c
 @Details  	: STM32G474 Timer driver               
 @Author	: lcgan
 @Hardware	: STM32
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  lcgan     XXXX-XX-X X  		Initial Release
******************************************************************************/
#include <Common.h>
#include "Hal.h"
#include "Timer.h"


/*****************************************************************************
 Define
******************************************************************************/
#define TOTAL_TIMER				14U


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
static volatile PTIMER_HANDLE g_aTimerIrqHandle[TOTAL_TIMER] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };


/*****************************************************************************
 Local Functions
******************************************************************************/
static void timer_IRQHandler( PTIMER_HANDLE pHandle );


/*****************************************************************************
 Implementation
******************************************************************************/
int TimerInit( PTIMER_HANDLE pHandle, uint8_t nTimer, uint32_t nFreq )
{
	TIM_TypeDef *timer;
	IRQn_Type 	irq;
    uint32_t 	hclock = SystemCoreClock;
	uint32_t 	clock = SystemCoreClock;
	uint32_t 	count = 0U;
    uint32_t    ahbpres = 0;
	uint32_t 	prescale = 0U;
	int			apb = 0;
	
	ASSERT( 0 != pHandle );
	ASSERT( 0 != nTimer );
	ASSERT( 0 != nFreq );

	/* Timer selection base on user specified */
	switch( nTimer )
	{
		case 1U:
			timer = TIM1;
			irq = TIM1_UP_TIM16_IRQn;
            apb = 2;
		break;
		
		case 2U:
			timer = TIM2;
			irq = TIM2_IRQn;
            apb = 1;
		break;
		
		case 3U:
			timer = TIM3;
			irq = TIM3_IRQn;
            apb = 1;
		break;
		
		case 4U:
			timer = TIM4;
			irq = TIM4_IRQn;
            apb = 1;
		break;
		
		case 5U:
			timer = TIM5;
			irq = TIM5_IRQn;
            apb = 1;
		break;
		
		case 6U:
			timer = TIM6;
			irq = TIM6_DAC_IRQn;
            apb = 1;
		break;
		
		case 7U:
			timer = TIM7;
			irq = TIM7_DAC_IRQn;
            apb = 1;
		break;
		
		case 8U:
			timer = TIM8;
			irq = TIM8_UP_IRQn;
            apb = 2;
		break;

		case 15U:
			timer = TIM15;
			irq = TIM1_BRK_TIM15_IRQn;
            apb = 2;
		break;

 		case 16U:
			timer = TIM16;
			irq = TIM1_UP_TIM16_IRQn;
            apb = 2;
		break;

  		case 17U:
			timer = TIM17;
			irq = TIM1_TRG_COM_TIM17_IRQn;
            apb = 2;
		break;
	
   		case 20U:
			timer = TIM20;
			irq = TIM20_UP_IRQn;
            apb = 2;
		break;

		default:
			return TIMER_ERR_INVALID;		/* User specified an invalid timer, return error */
	}
	
	if( (0 != (timer->CR1&TIM_CR1_CEN)) || (0 != (timer->CR1&TIM_CR1_ARPE)) )
	{
		/* Timer has been used for others. overlap is not possible */
		return TIMER_ERR_USED;
	}

	/* Keep the timer pointer into handle for next use */
	pHandle->pTimer = timer;
	pHandle->Irq = irq;
	
	/* Keep the handle pointer into a local variable so that it can be accessed in ISR */
	g_aTimerIrqHandle[nTimer-1] = pHandle;
	

	timer->CR1 &= ~(TIM_CR1_DIR 
					| TIM_CR1_OPM	/* one pulse mode */
					| TIM_CR1_CKD 
					| TIM_CR1_CMS); /* Center align mode */
	
   /* Retrieve current HCLK output = SYSCLOCK / HPRESC */

    switch( RCC->CFGR & RCC_CFGR_HPRE )
    {
        case RCC_CFGR_HPRE_DIV1:
            hclock = SystemCoreClock;
        break;
    
        case RCC_CFGR_HPRE_DIV2:
            hclock = SystemCoreClock>>1U;
        break;
    
        case RCC_CFGR_HPRE_DIV4:
            hclock = SystemCoreClock>>2U;
        break;
    
        case RCC_CFGR_HPRE_DIV8:
            hclock = SystemCoreClock>>3U;
        break;
    
        case RCC_CFGR_HPRE_DIV16:
            hclock = SystemCoreClock>>4U;
        break;

        case RCC_CFGR_HPRE_DIV64:
            hclock = SystemCoreClock>>5U;
        break;

        case RCC_CFGR_HPRE_DIV128:
            hclock = SystemCoreClock>>6U;
        break;

        case RCC_CFGR_HPRE_DIV256:
            hclock = SystemCoreClock>>7U;
        break;

        case RCC_CFGR_HPRE_DIV512:
            hclock = SystemCoreClock>>8U;
        break;

        default:
        break;
    }

	/* Different timer has different APB bus */
	if( 1 == apb )
	{
		/* Re-calculate current bus clock. User may change it in Hal.c */
		switch( RCC->CFGR & RCC_CFGR_PPRE1 )
		{
			case RCC_CFGR_PPRE1_DIV1:
				clock = hclock;
			break;
		
			case RCC_CFGR_PPRE1_DIV2:
				clock = hclock>>1U;
			break;
		
			case RCC_CFGR_PPRE1_DIV4:
				clock = hclock>>2U;
			break;
		
			case RCC_CFGR_PPRE1_DIV8:
				clock = hclock>>3U;
			break;
		
			case RCC_CFGR_PPRE1_DIV16:
				clock = hclock>>4U;
			break;

			default:
			break;
		}
	}
	
	if( 2 == apb )
	{
		/* Re-calculate current bus clock. User may change it in Hal.c */
		switch( RCC->CFGR & RCC_CFGR_PPRE2 )
		{
			case RCC_CFGR_PPRE2_DIV1:
				clock = hclock;
			break;
		
			case RCC_CFGR_PPRE2_DIV2:
				clock = hclock>>1U;
			break;
		
			case RCC_CFGR_PPRE2_DIV4:
				clock = hclock>>2U;
			break;
		
			case RCC_CFGR_PPRE2_DIV8:
				clock = hclock>>3U;
			break;
		
			case RCC_CFGR_PPRE1_DIV16:
				clock = hclock>>4U;
			break;

			default:
			break;
		}
	}


	/* Calculate auto reload counter and its prescaler */
	count = clock / nFreq;
	while( count >= 0xffffU )
	{
		/* Prescaler is needed since the count over 16 bits */
		count = clock / nFreq;
		
		/* try to increase presacaler */
		prescale++;

		/* divide again */
		count /= (prescale + 1);
	}

	if( 0 != prescale )
	{
		/* prescaler is applicable */
		timer->PSC = prescale;
	}
	
	/* the rest of the count store into auto reload counter register */
	timer->ARR = count;
	
	return TIMER_OK;
}


void TimerStart( PTIMER_HANDLE pHandle )
{
	TIM_TypeDef *timer = pHandle->pTimer;

	ASSERT( 0 != pHandle );

	/* enable update generation interrupt */
	timer->EGR |= TIM_EGR_UG;
	
	/* Timer counting enable with auto reload */
	timer->CR1 |= TIM_CR1_CEN | TIM_CR1_ARPE;
	
	/* Enable Timer interrupt */
	timer->DIER |= TIM_DIER_UIE;
	
	/* Enable NVIC controller for this timer irq */
	NVIC_EnableIRQ( pHandle->Irq );
}


void TimerStop( PTIMER_HANDLE pHandle )
{
	TIM_TypeDef *timer = pHandle->pTimer;

	ASSERT( 0 != pHandle );

	/* Disable update generation interrupt */
	timer->EGR &= ~TIM_EGR_UG;
	
	/* Timer counting Disable with auto reload */
	timer->CR1 &= ~(TIM_CR1_CEN | TIM_CR1_ARPE);
	
	/* Disable Timer interrupt */
	timer->DIER &= ~TIM_DIER_UIE;
	
	/* Disable NVIC controller for this timer irq */
	NVIC_DisableIRQ( pHandle->Irq );
}


void 
TimerAddHook(
	PTIMER_HANDLE 		pHandle,
	PTIMER_HOOK 		pHook,
	TIMER_CB_UPDATE 	*pfUpdate
	)
{
	ASSERT( 0 != pHandle );
	ASSERT( 0 != pHook );
	ASSERT( 0 != pfUpdate );
	
	/* Insert into link list */
	pHook->pfUpdate = pfUpdate;
	pHook->pNext = pHandle->pHeadHook;
	pHandle->pHeadHook = pHook;
}


static void timer_IRQHandler( PTIMER_HANDLE pHandle )
{
	TIM_TypeDef *timer = pHandle->pTimer;
	PTIMER_HOOK cur;
	int			status;

	ASSERT( 0 != pHandle );
	
	/* Read a copy of timer status */
	status = timer->SR;

	if( 0 != (status & TIM_SR_UIF) )
	{
		timer->SR &= ~TIM_SR_UIF;

		/* Timer interrupted due to timer update flag set */
		
		/* Make sure link list first object is not null */
		if( 0 != pHandle->pHeadHook )
		{
			/* Iterates a link list */
			for( cur=pHandle->pHeadHook; 0 != cur; cur=cur->pNext )
			{
				ASSERT( 0 != cur->pfUpdate );
				cur->pfUpdate();
			}
		}
	}
}


/*****************************************************************************
 Interrupt handling
******************************************************************************/
void TIM1_UP_TIM16_IRQHandler( void )
{
    /* Timer 1 and 10 shared the same IRQ */
	if( 0 != g_aTimerIrqHandle[0] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[0] );
	}

	if( 0 != g_aTimerIrqHandle[9] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[9] );
	}
}

void TIM2_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[1] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[1] );
	}
}


void TIM3_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[2] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[2] );
	}
}


void TIM4_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[3] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[3] );
	}
}


void TIM5_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[4] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[4] );
	}
}


void TIM6_DAC_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[5] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[5] );
	}
}


void TIM7_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[6] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[6] );
	}
}


void TIM8_UP_TIM13_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[7] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[7] );
	}

	if( 0 != g_aTimerIrqHandle[12] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[12] );
	}
}


void TIM1_BRK_TIM9_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[8] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[8] );
	}
}


void TIM1_TRG_COM_TIM11_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[10] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[10] );
	}
}


void TIM8_BRK_TIM12_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[11] )
	{
		timer_IRQHandler( g_aTimerIrqHandle[11] );
	}
}


void TIM8_TRG_COM_TIM14_IRQHandler( void )
{
	if( 0 != g_aTimerIrqHandle[13]  )
	{
		timer_IRQHandler( g_aTimerIrqHandle[13] );
	}
}

























