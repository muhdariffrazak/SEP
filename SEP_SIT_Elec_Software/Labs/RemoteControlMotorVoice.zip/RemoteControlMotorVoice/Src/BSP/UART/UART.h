/* UART.h  */

#include "stdint.h"

enum UART_parity {PARITY_NONE, PARITY_ODD, PARITY_EVEN};
enum databits {DATABITS7, DATABITS8, DATABITS9};
enum stopbits {STOP1, STOP2};

/******************************************************************************
 Global functions
******************************************************************************/
void LPUART1_Init(uint32_t baud, uint32_t databits, uint32_t parity, uint32_t stop);
void write_ASCII_LPUART1 (char);
