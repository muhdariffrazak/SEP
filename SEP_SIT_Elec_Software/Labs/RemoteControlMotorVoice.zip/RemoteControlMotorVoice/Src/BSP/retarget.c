#include <Common.h>
#include "Hal.h"
#include "UART.h"

/*****************************************************************************
 Define
******************************************************************************/

#if defined (__ARMCC_VERSION)
	#if __ARMCC_VERSION < 6000000  
		struct __FILE
		{
			int handle; 
		};
	#endif
#endif

FILE __stdout; //STDOUT
volatile int32_t ITM_RxBuffer;

int fputc(int ch, FILE * stream)
{
#ifdef _USE_DEBUG_ITM
	ITM_SendChar( ch );
#endif
	
#ifdef _USE_DEBUG_LPUART
	write_ASCII_LPUART1(ch); //Transmit Character
#endif
	return ch; //return the character written to denote a successful write
}
