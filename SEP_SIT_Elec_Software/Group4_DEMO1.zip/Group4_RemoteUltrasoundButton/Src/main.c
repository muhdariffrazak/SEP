/*****************************************************************************
 @Project		:
 @File 			: main.c
 @Details  	: Main entry
 @Author		: lcgan
 @Hardware	: STM32
 
 ----------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 ----------------------------------------------------------------------------
   1.0  XXXXXX     12-Feb-2023  	Initial Release
																	
*****************************************************************************/
#include <Common.h>
#include "Hal.h"
#include "BSP.h"
#include "Timer.h"
#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "Serial.h"
//header file for remote control
#include "Remote.h"
//header file for motor control
#include "UbiquityMotor.h"
//header file for Lcd functions
#include "LcdFunctions.h"
//header file for ultrasonic sensor
#include "UltraSound.h"
//header file for IRQ
#include "IRQ.h"

/* NOTE: Please follows code style provided. All tabs is 4 space */

/*****************************************************************************
 Define
************************"******************************************************/
#define SYS_TICK_MS 500 /* Software Timer with 500 ms */
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10

//Motor control
#define MOTOR_TICK_MS           10

//Ultrasonic sensor
#define TOTAL_USONIC          	2U
#define USONIC_TICK_MS        	100U  // measure ultrsound distances every USONIC_TICK_MS ms
#define USONIC_ECHO_TIMEOUT   	200U // timeout if no ECHO back 


/*****************************************************************************
 Type definition
******************************************************************************/
typedef union _tagUS_Status
{
    uint32_t Status;    
    struct
    {
      uint32_t bUSonic0 :1;
      uint32_t bUSonic1 :1;
      uint32_t bUSonic2 :1;
      uint32_t bUSonic3 :1;
	  uint32_t bError0 	:1;
      uint32_t bError1 	:1;
      uint32_t bError2 	:1;
      uint32_t bError3 	:1;
      uint32_t Reserved :24;
    }b;
}US_STATUS, *PUS_STATUS;






/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Const Local Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
//systic declarations
static volatile int     	g_nSysTick = SYS_TICK_MS;
static volatile BOOL    	g_bSysTickReady = FALSE;
static volatile BOOL    	g_bToggle = FALSE;

//LCD declarations
static SPIM_HANDLE			g_SpimHandle;
volatile GUI_DATA			g_aBuf[LCD_BUF_SIZE];
volatile GUI_MEMDEV			g_MemDev;
volatile BOOL 				g_bLcdFree  = TRUE;

static volatile int     	g_nLCDTick = LCD_UPDATE_MS;
static volatile BOOL    	g_nLCDTickReady = FALSE;

//Global variables for time and count
volatile uint32_t         	g_nCount = 0;
volatile uint32_t			g_nTimeSec = 0;


//Timer declarations
static TIMER_HANDLE     	g_Timer1Handle; /* This is timer 1 handle */
static TIMER_HOOK       	g_TImer1Hook;    /* This is hook 1 to timer 1 */


//Remote control handle
static UART_HANDLE          g_UartRemoteHandle;
static char                 g_aUartRemoteTxBuf[64];
static char                 g_aUartRemoteRxBuf[64];
static volatile BOOL        g_abUartRemoteReady = FALSE;
static int                  g_nCmd = 0;

//Declare motor control handle
static UART_HANDLE          g_UartMCBHandle;
static char                 g_aUartMCBTxBuf[64];
static char                 g_aUartMCBRxBuf[64];
static volatile BOOL        g_abUartMCBReady = FALSE;

static volatile int         g_nMotorTick = MOTOR_TICK_MS;
static volatile BOOL        g_bMotorTickReady = FALSE;

volatile BOOL motor_status = FALSE;
volatile BOOL remote_status = FALSE;
//variable to store the direction of the motor (string data type)
volatile char motor_direction[1] = " ";

//Ulrasonic sensor
static USONIC_HANDLE      	g_USHandles[TOTAL_USONIC];
static volatile US_STATUS 	g_USonicStatus;
static volatile int       	g_nUSonicTick = USONIC_TICK_MS;
static volatile BOOL      	g_bUSonicTickReady = FALSE;

volatile int USonicDist = 0;
volatile int USonicDist1 = 0;
// volatile int USonicDist2 = 0;
// volatile int USonicDist3 = 0;

volatile BOOL USonicError = FALSE;
volatile BOOL USonicError1 = FALSE;
// volatile BOOL USonicError2 = FALSE;
// volatile BOOL USonicError3 = FALSE;

//Variable to store mode of operation
volatile BOOL mode = FALSE;
volatile BOOL AutoDir = TRUE;

volatile int Obstacle = 0;
volatile BOOL obstacleDetected = FALSE;

volatile BOOL g_bstop = FALSE;


/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void );
static void motor_UartInit( void );
static void remote_UartInit( void );
static void main_HostCmdExe( char *pCmd );
static void main_UltraSoundInit( void );

/*****************************************************************************
 Callback functions
******************************************************************************/
static void main_cbUartRemoteOnRx( void );// Callback function for remote control

static void main_cbUS0OnTrigger( BOOL bON );
static void main_cbUS1OnTrigger( BOOL bON );


static void main_cbUS0OnReady( int Error );
static void main_cbUS1OnReady( int Error );

void main_AutoMotorControl(void);

/*****************************************************************************
 Interrupt functions
******************************************************************************/
void EXTI13_BTN_IRQHandler( uint32_t irqStatus);
/*****************************************************************************
 Implementation 
******************************************************************************/
int main( void )
{
	char *cmd;
	int dist = 0;
	// Initialize the board support package
    BSPInit();
	// Generate interrupt each 1 ms as system tick
	SysTick_Config(SystemCoreClock / 1000);

	TRACE("SystemCoreClock %dHz\r\n", SystemCoreClock);

	// Initialize SPI module
	main_SpimInit();
	// Initialize LCD with SPI handle
	LCD_Init(&g_SpimHandle); // Ensure g_SpimHandle is correctly initialized in main_SpimInit()
	// Initialize UART for remote control
	remote_UartInit(); // Ensure g_UartRemoteHandle is correctly initialized in remote_UartInit()
	// Initialize UART for motor control
	motor_UartInit(); // Ensure g_UartMCBHandle is correctly initialized in motor_UartInit()
	// Initialize motors with UART handle
	MotorsInit(&g_UartMCBHandle); // Ensure this does not access invalid memory
	// Set motor speeds
	MotorsSetSpeeds(35, 35);  // Speed at 25 ticks/100ms
	// Initialize timer with handle
	TimerInit(&g_Timer1Handle, 1U, 10000); // Ensure g_Timer1Handle is correctly initialized
	// Initialize ultrasonic sensors
	main_UltraSoundInit(); // Ensure g_USHandles are correctly initialized in main_UltraSoundInit()
	// Start timer 1 now
    TimerStart(&g_Timer1Handle);
	// Initialize IRQ
	IRQInit();
    // Start the trigger for the 1st ultrasound sensor
   	USonicTrigger(&g_USHandles[0]);

	// Runtime for loop
	for (;;)
    {
		// Handle system tick
		if (FALSE != g_bSysTickReady)
		{
			g_bSysTickReady = FALSE;

			// Every 500ms per tick    
			LED_LD2_SET(g_bToggle);

			g_bToggle = !g_bToggle;
		}

		// Handle LCD tick
        if (FALSE != g_nLCDTickReady)
		{
			if (0 != g_bLcdFree)
			{
				g_nLCDTickReady = FALSE;
				g_bLcdFree = FALSE;
				// Draw every block. Consume less time
				GUI_Draw_Exe();
			}
		}
		
		// Handle UART remote
		if (FALSE != g_abUartRemoteReady)
		{
			g_abUartRemoteReady = FALSE;

			cmd = RemoteParse(&g_UartRemoteHandle);
            if (0 != cmd)
			{
				main_HostCmdExe(cmd);
			}
		}

		// Handle motor tick
		if (FALSE != g_bMotorTickReady)
        {
            g_bMotorTickReady = FALSE;
            MotorOnTimer(); // shall maintain at 50ms as required by ubiquity MCB
        }
		
		// Handle UART motor control board
		if (0 != g_abUartMCBReady)
        {
            g_abUartMCBReady = FALSE;
            SerialRxEmpty(&g_UartMCBHandle);
            // Ignore incoming Uart bytes from MCB. Not in use.
        }

		// Handle ultrasonic sensor tick
		if (FALSE != g_bUSonicTickReady)
		{
			g_bUSonicTickReady = FALSE;

			if (FALSE != g_USonicStatus.b.bUSonic0)
			{
				g_USonicStatus.b.bUSonic0 = FALSE;
				
				if (FALSE != g_USonicStatus.b.bError0)
				{
					g_USonicStatus.b.bError0 = FALSE;
					TRACE("US0: Err: Sensor fault ");
					// Set error flag
					USonicError = TRUE;
				}
				else
				{
					USonicError = FALSE;
					dist = USonicRead(&g_USHandles[0]);
					TRACE("US0: %d cm ", dist / 100);
					USonicDist = dist / 100;
					if (USonicDist < 30 && obstacleDetected == FALSE) {
						AutoDir = FALSE;
						obstacleDetected = TRUE;
						Obstacle++;
						MotorsStop();
						g_bStop = false;
					}
					else if (USonicDist1 >= 30 && USonicDist >= 30) {
						obstacleDetected = FALSE; // Reset the flag when the obstacle is no longer detected
					}
				}

				USonicTrigger(&g_USHandles[1]);
			}

			if (FALSE != g_USonicStatus.b.bUSonic1)
			{
				g_USonicStatus.b.bUSonic1 = FALSE;
				
				if (FALSE != g_USonicStatus.b.bError1)
				{
					g_USonicStatus.b.bError1 = FALSE;
					TRACE("US1: Err: Sensor fault\r\n ");
					// Set error flag
					USonicError1 = TRUE;
					
				}
				else
				{
					USonicError1 = FALSE;
					dist = USonicRead(&g_USHandles[1]);
					TRACE("US1: %d cm\r\n", dist / 100);
					USonicDist1 = dist / 100;
					if (USonicDist1 < 30 && obstacleDetected == FALSE) {
						AutoDir = TRUE;
						obstacleDetected = TRUE;
						MotorsStop();
						g_bStop= false;
					}
					 else if (USonicDist1 >= 30 && USonicDist >= 30) {
						obstacleDetected = FALSE; // Reset the flag when the obstacle is no longer detected
					}
				}
				
				USonicTrigger(&g_USHandles[0]);
			}
		}
     }
}


/*****************************************************************************
 Callback functions
******************************************************************************/


static void main_cbUartRemoteOnRx( void )
{
    if (mode == FALSE) // Only set the flag if not in autonomous mode
    {
        g_abUartRemoteReady = TRUE;
    }
}
static void main_cbMCBOnRx( void )
{
   g_abUartMCBReady  = TRUE;
}
static void main_cbUS0OnTrigger( BOOL bON )
{
  US0_TRIG_SET( bON );
}

static void main_cbUS1OnTrigger( BOOL bON )
{
  US1_TRIG_SET( bON );
}
static void main_cbUS0OnReady( int Error )
{
	if( USONIC_SUCCESS != Error )
	{
		g_USonicStatus.b.bError0 = TRUE;
	}
	else
	{
		g_USonicStatus.b.bError0 = FALSE;
	}
	g_USonicStatus.b.bUSonic0 = TRUE;
	main_AutoMotorControl();
}

static void main_cbUS1OnReady( int Error )
{
	if( USONIC_SUCCESS != Error )
	{
		g_USonicStatus.b.bError1 = TRUE;
	}
	else
	{
		g_USonicStatus.b.bError1 = FALSE;
	}
	
	g_USonicStatus.b.bUSonic1 = TRUE;
	main_AutoMotorControl();
}

void main_AutoMotorControl(void)
{
    if (mode == TRUE) // Autonomous mode
    {
        if (Obstacle <= 3) {
            if (AutoDir == TRUE) {
                MotorsMoveFront();
                strncpy((char *)motor_direction, "F", sizeof(motor_direction));
            } else if (AutoDir == FALSE) {
                MotorsMoveBack();
                strncpy((char *)motor_direction, "B", sizeof(motor_direction));
            } else {
                MotorsStop();
                strncpy((char *)motor_direction, "S", sizeof(motor_direction));
                g_bstop = FALSE; // disengage the stop flag
            }
        } else {
            MotorsStop();
            strncpy((char *)motor_direction, "S", sizeof(motor_direction));
            g_bstop = FALSE; // disengage the stop flag
            mode = !mode; // switch to manual mode
            Obstacle = 0; // Reset obstacle counter when switching to manual mode
        }
        
        motor_direction[sizeof(motor_direction) - 1] = '\0'; // Ensure null-termination
    }
}



/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void )
{
	SpimInit(
        &g_SpimHandle,
        2,
        15000000U, 
        SPI_CLK_INACT_LOW,
        SPI_CLK_RISING_EDGE,
        SPI_DATA_SIZE_8 );
}

static void motor_UartInit( void )
{
    int res = SerialInit( &g_UartMCBHandle, 1, 38400 );
    ASSERT( res == UART_STS_OK );
	(res == UART_STS_OK)?(motor_status = TRUE):(motor_status = FALSE);

    SerialConfig(
    	&g_UartMCBHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartMCBHandle, 
    	g_aUartMCBTxBuf,
    	sizeof(g_aUartMCBTxBuf),
    	g_aUartMCBRxBuf,
    	sizeof(g_aUartMCBRxBuf) );

   SerialAddCallback( &g_UartMCBHandle, 0, main_cbMCBOnRx );
}

static void remote_UartInit( void )
{
	int res;
   // Remote controller from esp32
    res = SerialInit( &g_UartRemoteHandle, 5, 921600 );
    ASSERT( res == UART_STS_OK );
	(res == UART_STS_OK)?(remote_status = TRUE):(remote_status = FALSE);

    SerialConfig(
    	&g_UartRemoteHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartRemoteHandle, 
    	g_aUartRemoteTxBuf,
    	sizeof(g_aUartRemoteTxBuf),
    	g_aUartRemoteRxBuf,
    	sizeof(g_aUartRemoteTxBuf) );

   SerialAddCallback( &g_UartRemoteHandle, 0, main_cbUartRemoteOnRx );
}

static void main_HostCmdExe(char *pCmd)
{	if (mode == TRUE) 
    {
        // If in autonomous mode, ignore remote commands
        return;
    }
	else
	{
		HOST_REQ_PKT *req = (HOST_REQ_PKT *)pCmd;// Cast to HOST_REQ_PKT and assign to req

			switch (req->Cmd.Cmd)
			{
				case CMD_HOST_STOP:
					MotorsStop();
					strncpy((char *)motor_direction, "S", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: STOP\r\n");
					break;

				case CMD_HOST_MOVE_FWD:
					MotorsMoveFront();
					strncpy((char *)motor_direction, "F", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: FWD\r\n");
					break;

				case CMD_HOST_MOVE_BWD:
					MotorsMoveBack();
					strncpy((char *)motor_direction, "B", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: BWD\r\n");
					break;

				case CMD_HOST_ROTATE_LEFT:
					MotorsRotateLeft();
					strncpy((char *)motor_direction, "L", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: ROTATE LEFT\r\n");
					break;

				case CMD_HOST_ROTATE_RIGHT:
					MotorsRotateRight();
					strncpy((char *)motor_direction, "R", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: ROTATE RIGHT\r\n");
					break;

				default:
					TRACE("cmd: Invalid\r\n");
					break;
			}
		}		
    }


static void main_UltraSoundInit( void )
{
  /* Ultrasonic initialization */
  USonicInit( &g_Timer1Handle, 10000 );
  
  /* Add a callback to get notify when ultrasonic sensor is ready to be read */
  UsonicAddDevice( &g_USHandles[0], 0U, main_cbUS0OnTrigger, main_cbUS0OnReady );
  UsonicAddDevice( &g_USHandles[1], 1U, main_cbUS1OnTrigger, main_cbUS1OnReady );
}


/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler( void )
{
	/* NOTE:
	It is more efficient to compare to 0 for Cortex M
	*/

	g_nCount++;
	if (g_nCount == 1000)
	{
		//g_bSecTick = TRUE;
		g_nCount=0;
		
		/* Keep track of time based on 1 sec interval */ 
		g_nTimeSec++;
		if(g_nTimeSec > 24*60*60)
		{
			g_nTimeSec = 0;
		}
	}

	if( 0 != g_nSysTick ) // g_nSysTick counts down from SYS_TICK_MS
	{
		g_nSysTick--;
		if( 0 == g_nSysTick )
		{
			g_nSysTick = SYS_TICK_MS;
			g_bSysTickReady = TRUE;
		}
	}

	if( 0 != g_nLCDTick )
	{
		g_nLCDTick--;
		if( 0 == g_nLCDTick )
		{
			g_nLCDTick = LCD_UPDATE_MS;
			g_nLCDTickReady = TRUE;		}
	}
	
	if( 0 != g_nMotorTick )
    {
        g_nMotorTick--;

        if( 0 == g_nMotorTick )
        {
            g_nMotorTick = MOTOR_TICK_MS;
            g_bMotorTickReady = TRUE;
		}
	}
		if( 0 != g_nUSonicTick )
    {
        g_nUSonicTick--;

        if( 0 == g_nUSonicTick )
        {
            g_nUSonicTick = USONIC_TICK_MS;
            g_bUSonicTickReady = TRUE;
        }
    }
}
void EXTI2_US0_ECHO_IRQHandler( uint32_t Status )
{
	UsonicISR( &g_USHandles[0], IN_US0_ECHO() );
}

void EXTI5_US1_ECHO_IRQHandler( uint32_t Status )
{
	UsonicISR( &g_USHandles[1], IN_US1_ECHO() );
}
void EXTI13_BTN_IRQHandler(uint32_t irqStatus)
{
    if ((EXTI->PR1 & EXTI_PR1_PIF13) != 0)  // Check if EXTI line 13 caused the interrupt
    {
		//This can also be in irq.c
        EXTI->PR1 = EXTI_PR1_PIF13;  // Clear the pending interrupt flag for EXTI line 13
        
        // Handle button press here
        if (BTN_READ())
        {
			mode = !mode;
			TRACE("Button pressed\n\r");
			Obstacle = 0;
			obstacleDetected = FALSE;
			g_bStop = FALSE;
			SerialRxEmpty(&g_UartRemoteHandle);
			SerialRxEmpty(&g_UartMCBHandle);
			if (mode == TRUE)
			{
				AutoDir = TRUE;
				MotorsMoveFront();
				// clear serial buffer
			}	
        }
    }
}
