/*****************************************************************************
 @Project	: SEP150/SEP200/SEP250 
 @File 		: UbiquityMotor.c
 @Details  	: Ubiquity Robot MCB Control via UART 
 @Author	: LianChai (lianchai.gan@digipen.edu)
 @Hardware	: Platform dependent on Ubiquity Robot MCB
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  LianChai     2022-AUG-08  		Initial Release
   
******************************************************************************/

#include <Common.h>
#include "Hal.h"
#include "UbiquityMotor.h"
#include "Serial.h"
#include "stdbool.h"


/*****************************************************************************
 Define
******************************************************************************/


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
static UBIMCB_PKT           g_MCBPkt;
static int                  g_nSpeedLeft = 0;
static int                  g_nSpeedRight = 0;
static int                  g_nVelocityLeft = 0;
static int                  g_nVelocityRight = 0;
static UART_HANDLE          *g_pUartHandle = 0;
volatile BOOL                g_bStop;

/*****************************************************************************
 Local functions
******************************************************************************/
static uint8_t _CheckSum(uint8_t *pData, int offset, int n);
static void _SetSpeed( int nSpeedLeft, int nSpeedRight );


/*****************************************************************************
 Callback functions
******************************************************************************/


/*****************************************************************************
 Implementation 
******************************************************************************/
void MotorsInit( void *pUartHandle )
{
    g_pUartHandle = pUartHandle;

    memset( g_MCBPkt.aData, 0x00, sizeof(g_MCBPkt.aData) );
}


void MotorsSetSpeeds( int nSpeedLeft, int nSpeedRight )
{
    g_nSpeedLeft = nSpeedLeft;
    g_nSpeedRight = nSpeedRight;
}


void MotorsMoveFront( void )
{
    g_nVelocityLeft = g_nSpeedLeft;
    g_nVelocityRight = g_nSpeedRight;
    g_bStop = FALSE;
    _SetSpeed( g_nVelocityLeft, g_nVelocityRight );

}


void MotorsMoveBack( void )
{
    g_nVelocityLeft = -g_nSpeedLeft;
    g_nVelocityRight = -g_nSpeedRight;
    g_bStop = FALSE;
    _SetSpeed( g_nVelocityLeft, g_nVelocityRight );
}


void MotorsRotateLeft( void )
{
    g_nVelocityLeft = -g_nSpeedLeft;
    g_nVelocityRight = g_nSpeedRight;
    g_bStop = FALSE;
    _SetSpeed( g_nVelocityLeft, g_nVelocityRight );
}


void MotorsRotateRight( void )
{
    g_nVelocityLeft = g_nSpeedLeft;
    g_nVelocityRight = -g_nSpeedRight;
    g_bStop = FALSE;
    _SetSpeed( g_nVelocityLeft, g_nVelocityRight );
}


void MotorsStop( void )
{
    g_nVelocityLeft = 0;
    g_nVelocityRight = 0;
    g_bStop = TRUE;
    _SetSpeed( g_nVelocityLeft, g_nVelocityRight );
}


void MotorOnTimer( void )
{
    if( FALSE == g_bStop )
    {
        _SetSpeed( g_nVelocityLeft, g_nVelocityRight );
    }
}


void MotorsSpeedIncrement( void )
{
    g_nSpeedLeft++;
    g_nSpeedRight++;
}


void MotorsSpeedDecrement( void )
{
    if( 0 != g_nSpeedLeft )
    {
        g_nSpeedLeft--;
    }

    if( 0 != g_nSpeedRight )
    {
        g_nSpeedRight--;
    }
}

/*****************************************************************************
 Callback functions
******************************************************************************/


/*****************************************************************************
 Local functions
******************************************************************************/
static void _SetSpeed( int nSpeedLeft, int nSpeedRight )
{
    //Ubiquity robot MCB protocol is big endian. Send MSB first.
    g_MCBPkt.BothSpeed.STX = CMD_MCB_STX;
    g_MCBPkt.BothSpeed.CmdType = CMD_MCB_W;
    g_MCBPkt.BothSpeed.Cmd = CMD_MCB_BOTH_MOTOR_SPEED_SET;
    if (nSpeedRight < 0)
    {
        g_MCBPkt.BothSpeed.SpeedR_MSB = 0xff;
        g_MCBPkt.BothSpeed.SpeedR_LSB = 0xff - ((-1 * nSpeedRight) & 0xff);
    }
    else
    {
        g_MCBPkt.BothSpeed.SpeedR_MSB = 0;
        g_MCBPkt.BothSpeed.SpeedR_LSB = nSpeedRight & 0xff;
    }

    if (nSpeedLeft < 0)
    {
        g_MCBPkt.BothSpeed.SpeedL_MSB = 0xff;
        g_MCBPkt.BothSpeed.SpeedL_LSB = 0xff - ((-1 * nSpeedLeft) & 0xff);
    }
    else
    {
        g_MCBPkt.BothSpeed.SpeedL_MSB = 0;
        g_MCBPkt.BothSpeed.SpeedL_LSB = nSpeedLeft & 0xff;
    }

    g_MCBPkt.BothSpeed.Cs = _CheckSum(g_MCBPkt.aData, 1, 6);

    SerialWriteEx( g_pUartHandle, g_MCBPkt.aData, sizeof(g_MCBPkt.aData) );
}


static uint8_t _CheckSum(uint8_t *pData, int offset, int n)
{
    int i = 0;
    uint8_t CheckSum = 0x00;

    for (i = 0; i < n; i++)
    {
        CheckSum += pData[i + offset];
        CheckSum = CheckSum & 0xff;
    }
    CheckSum = 0xff - CheckSum;
    return CheckSum;
}

/*****************************************************************************
 Interrupt functions
******************************************************************************/


















