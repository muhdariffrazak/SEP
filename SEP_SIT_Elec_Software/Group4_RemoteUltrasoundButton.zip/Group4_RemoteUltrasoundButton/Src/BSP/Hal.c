/*****************************************************************************
 @Project		: 
 @File 			: Hal.c
 @Details  	: All Ports and peripherals configuration                    
 @Author		: 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     XXXX-XX-XX  		Initial Release
   
******************************************************************************/
#include <Common.h>
#include "Hal.h"


/*****************************************************************************
 Define
******************************************************************************/


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
static uint32_t					ffh;

/*****************************************************************************
 Implementation
******************************************************************************/
void PortInit( void )
{
	/* peripherals bus clocks enable */
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN
                    | RCC_AHB2ENR_GPIOBEN
                    | RCC_AHB2ENR_GPIOCEN
					| RCC_AHB2ENR_GPIODEN
                    | RCC_AHB2ENR_GPIOEEN;

	RCC->APB2ENR |= RCC_APB2ENR_TIM1EN 
					| RCC_APB2ENR_SYSCFGEN;

	/*******************************
	LED control pins
	********************************/
	GPIOA->MODER &= ~GPIO_MODER_MODE5;		/* PA_LD2_GREEN - PA5 */
	GPIOA->MODER |= (GPIO_MODE_OUTPUT<<GPIO_MODER_MODE5_Pos);
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD5_Msk;
	GPIOA->PUPDR |= (GPIO_PULL_DIS<<GPIO_PUPDR_PUPD5_Pos);
	GPIOA->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED5;
	GPIOA->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED5_Pos);

	/*******************************
	LCD SPI2
	********************************/
	RCC->APB1ENR1 |= RCC_APB1ENR1_SPI2EN;

	GPIOC->MODER &= ~GPIO_MODER_MODER0;		/* PC_LCD_RESET - PC0 */
	GPIOC->MODER |= (GPIO_MODE_OUTPUT<<GPIO_MODER_MODE0_Pos);
	GPIOC->PUPDR &= ~GPIO_PUPDR_PUPDR0;
	GPIOC->PUPDR |= (GPIO_PULL_UP<<GPIO_PUPDR_PUPD0_Pos);
	GPIOC->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED0;
	GPIOC->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED0_Pos);
	GPIOC->BSRR = GPIO_BSRR_BS_0;

	GPIOC->MODER &= ~GPIO_MODER_MODER4;		/* PC_LCD_DC - PC4 */
	GPIOC->MODER |= (GPIO_MODE_OUTPUT<<GPIO_MODER_MODE4_Pos);
	GPIOC->PUPDR &= ~GPIO_PUPDR_PUPDR4;
	GPIOC->PUPDR |= (GPIO_PULL_UP<<GPIO_PUPDR_PUPD4_Pos);
	GPIOC->OSPEEDR &= ~GPIO_OSPEEDER_OSPEEDR4;
	GPIOC->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED4_Pos);
	GPIOC->BSRR = GPIO_BSRR_BS_4;

	GPIOC->MODER &= ~GPIO_MODER_MODER3;		/* PC_LCD_BL - PC3 */
	GPIOC->MODER |= (GPIO_MODE_OUTPUT<<GPIO_MODER_MODE3_Pos);
	GPIOC->PUPDR &= ~GPIO_PUPDR_PUPD3;
	GPIOC->PUPDR |= (GPIO_PULL_UP<<GPIO_PUPDR_PUPD3_Pos);
	GPIOC->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED3;
	GPIOC->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED3_Pos);
	GPIOC->BSRR = GPIO_BSRR_BS_3;

	GPIOB->MODER &= ~GPIO_MODER_MODER12;	/* PB_LCD_SPI2_CS - PB12 */
	GPIOB->MODER |= (GPIO_MODE_OUTPUT<<GPIO_MODER_MODE12_Pos);
	GPIOB->PUPDR &= ~GPIO_PUPDR_PUPD12;
	GPIOB->PUPDR |= (GPIO_PULL_UP<<GPIO_PUPDR_PUPD12_Pos);
	GPIOB->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED12;
	GPIOB->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED12_Pos);
	GPIOB->BSRR = GPIO_BSRR_BS_12;

	GPIOB->MODER &= ~GPIO_MODER_MODE13;		/* PB_LCD_SPI2_CLK - PB13 */
	GPIOB->MODER |= (GPIO_MODE_AF<<GPIO_MODER_MODE13_Pos);
	GPIOB->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED13;
	GPIOB->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED13_Pos);
	GPIOB->AFR[1] &= ~GPIO_AFRH_AFSEL13;
	GPIOB->AFR[1] |= (GPIO_SPI2_AF5<<GPIO_AFRH_AFSEL13_Pos);	

	GPIOB->MODER &= ~GPIO_MODER_MODE14;		/* PB_LCD_SPI2_MISO - PB14 */
	GPIOB->MODER |= (GPIO_MODE_AF<<GPIO_MODER_MODE14_Pos);
	GPIOB->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED14;
	GPIOB->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED14_Pos);
	GPIOB->AFR[1] &= ~GPIO_AFRH_AFSEL14;
	GPIOB->AFR[1] |= (GPIO_SPI2_AF5<<GPIO_AFRH_AFSEL14_Pos);	

	GPIOB->MODER &= ~GPIO_MODER_MODE15;		/* PB_LCD_SPI2_MOSI - PB15 */	
	GPIOB->MODER |= (GPIO_MODE_AF<<GPIO_MODER_MODE15_Pos);
	GPIOB->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED15;
	GPIOB->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED15_Pos);
	GPIOB->AFR[1] &= ~GPIO_AFRH_AFSEL15;
	GPIOB->AFR[1] |= (GPIO_SPI2_AF5<<GPIO_AFRH_AFSEL15_Pos);

		
	/*******************************
	Remote controller USART5 AF5
	********************************/
    RCC->APB1ENR1 |= RCC_APB1ENR1_UART5EN;
    GPIOC->MODER &= ~GPIO_MODER_MODE12;						/* PC12 UART5_TX */
	GPIOC->MODER |= (GPIO_MODE_AF<<GPIO_MODER_MODE12_Pos);
	GPIOC->OTYPER |= GPIO_OTYPER_OT_12;
	GPIOC->OSPEEDR &= ~GPIO_OSPEEDER_OSPEEDR12;
	GPIOC->PUPDR &= ~GPIO_PUPDR_PUPDR12;
	GPIOC->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED12_Pos);
	GPIOC->AFR[1] &= ~GPIO_AFRH_AFSEL12;
	GPIOC->AFR[1] |= (GPIO_UART5_AF5<<GPIO_AFRH_AFSEL12_Pos);

    GPIOD->MODER &= ~GPIO_MODER_MODE2;						/* PD2 UART5_RX */
	GPIOD->MODER |= (GPIO_MODE_AF<<GPIO_MODER_MODE2_Pos);
	GPIOD->OTYPER |= GPIO_OTYPER_OT_2;
	GPIOD->OSPEEDR &= ~GPIO_OSPEEDER_OSPEEDR2;
	GPIOD->PUPDR &= ~GPIO_PUPDR_PUPDR2;
	GPIOD->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED2_Pos);
	GPIOD->AFR[0] &= ~GPIO_AFRL_AFSEL2;
	GPIOD->AFR[0] |= (GPIO_UART5_AF5<<GPIO_AFRL_AFSEL2_Pos);

	/*******************************
	MCB Motor driver
	********************************/
	//MCB USART1 AF7
    RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
    GPIOB->MODER &= ~GPIO_MODER_MODE6;						/* PB6 USART1_TX */
	GPIOB->MODER |= (GPIO_MODE_AF<<GPIO_MODER_MODE6_Pos);
	GPIOB->OTYPER &= ~GPIO_OTYPER_OT_6;
	GPIOB->OSPEEDR &= ~GPIO_OSPEEDER_OSPEEDR6;
	GPIOB->PUPDR &= ~GPIO_PUPDR_PUPDR6;
	GPIOB->PUPDR |= (GPIO_PULL_UP<<GPIO_PUPDR_PUPD6_Pos);
	GPIOB->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED6_Pos);
	GPIOB->AFR[0] &= ~GPIO_AFRL_AFSEL6;
	GPIOB->AFR[0] |= (GPIO_USART1_AF7<<GPIO_AFRL_AFSEL6_Pos);

    GPIOB->MODER &= ~GPIO_MODER_MODE7;						/* PB7 USART1_RX */
	GPIOB->MODER |= (GPIO_MODE_AF<<GPIO_MODER_MODE7_Pos);
	GPIOB->OTYPER &= ~GPIO_OTYPER_OT_7;
	GPIOB->OSPEEDR &= ~GPIO_OSPEEDER_OSPEEDR7;
	GPIOB->PUPDR &= ~GPIO_PUPDR_PUPDR7;
	GPIOB->PUPDR |= (GPIO_PULL_UP<<GPIO_PUPDR_PUPD7_Pos);
	GPIOB->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED7_Pos);
	GPIOB->AFR[0] &= ~GPIO_AFRL_AFSEL7;
	GPIOB->AFR[0] |= (GPIO_USART1_AF7<<GPIO_AFRL_AFSEL7_Pos);

	/*******************************
	Ultrasound Sensors
	********************************/
	GPIOB->MODER &= ~GPIO_MODER_MODE10;	/* PF_US0_TRIG - PB10 */
	GPIOB->MODER |= (GPIO_MODE_OUTPUT<<GPIO_MODER_MODE10_Pos);
	GPIOB->PUPDR &= ~GPIO_PUPDR_PUPD10_Msk;
	GPIOB->PUPDR |= (GPIO_PULL_DIS<<GPIO_PUPDR_PUPD10_Pos); 
	GPIOB->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED10;
	GPIOB->OSPEEDR |= (GPIO_SPEED_MEDIUM<<GPIO_OSPEEDR_OSPEED10_Pos);

    GPIOB->MODER &= ~GPIO_MODER_MODE11;  /* PB_US1_TRIG - PB11 */
    GPIOB->MODER |= (GPIO_MODE_OUTPUT<<GPIO_MODER_MODE11_Pos);
    GPIOB->PUPDR &= ~GPIO_PUPDR_PUPD11_Msk;
    GPIOB->PUPDR |= (GPIO_PULL_DIS<<GPIO_PUPDR_PUPD11_Pos); 
    GPIOB->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED11;
    GPIOB->OSPEEDR |= (GPIO_SPEED_MEDIUM<<GPIO_OSPEEDR_OSPEED11_Pos);
    

    GPIOB->MODER &= ~GPIO_MODER_MODE2;  /* PB_ECHO_US0 - PB2 */
    GPIOB->MODER |= (GPIO_MODE_INPUT<<GPIO_MODER_MODE2_Pos);
    GPIOB->PUPDR &= ~GPIO_PUPDR_PUPD2_Msk;
    GPIOB->PUPDR |= (GPIO_PULL_DWN<<GPIO_PUPDR_PUPD2_Pos); // pull down
    GPIOB->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED2;
    GPIOB->OSPEEDR |= (GPIO_SPEED_MEDIUM<<GPIO_OSPEEDR_OSPEED2_Pos);

    SYSCFG->EXTICR[0] &= ~SYSCFG_EXTICR1_EXTI2; // EXTICR1
    SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI2_PB;
	
    EXTI->EMR1 |= EXTI_EMR1_EM2;
    EXTI->IMR1 |= EXTI_IMR1_IM2;
    EXTI->RTSR1 |= EXTI_RTSR1_RT2;
    EXTI->FTSR1 |= EXTI_FTSR1_FT2;

	GPIOB->MODER &= ~GPIO_MODER_MODE5;  /* PB_ECHO_US1 - PB5 */
	GPIOB->MODER |= (GPIO_MODE_INPUT<<GPIO_MODER_MODE5_Pos);
	GPIOB->PUPDR &= ~GPIO_PUPDR_PUPD5_Msk;
	GPIOB->PUPDR |= (GPIO_PULL_DWN<<GPIO_PUPDR_PUPD5_Pos); // pull down
	GPIOB->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED5;
	GPIOB->OSPEEDR |= (GPIO_SPEED_MEDIUM<<GPIO_OSPEEDR_OSPEED5_Pos);

	SYSCFG->EXTICR[1] &= ~SYSCFG_EXTICR2_EXTI5; // EXTICR1
	SYSCFG->EXTICR[1] |= SYSCFG_EXTICR2_EXTI5_PB;

	EXTI->EMR1 |= EXTI_EMR1_EM5;
	EXTI->IMR1 |= EXTI_IMR1_IM5;
	EXTI->RTSR1 |= EXTI_RTSR1_RT5;
	EXTI->FTSR1 |= EXTI_FTSR1_FT5;

	/*******************************
	 User Button PC13
	********************************/
	GPIOC->MODER &= ~GPIO_MODER_MODE13;		/* PC13 */
	GPIOC->MODER |= (GPIO_MODE_INPUT<<GPIO_MODER_MODE13_Pos);
	GPIOC->PUPDR &= ~GPIO_PUPDR_PUPD13_Msk;//Clear
	//GPIOC->PUPDR |= (GPIO_PULL_DIS<<GPIO_PUPDR_PUPD13_Pos);//Pull up
	GPIOC->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED13;
	GPIOC->OSPEEDR |= (GPIO_SPEED_MEDIUM<<GPIO_OSPEEDR_OSPEED13_Pos);//Medium speed

	SYSCFG->EXTICR[3] &= ~SYSCFG_EXTICR4_EXTI13;//Clear
	SYSCFG->EXTICR[3] |= (SYSCFG_EXTICR4_EXTI13_PC);//	EXTI13 is connected to PC13

	EXTI->EMR1 &= ~EXTI_EMR1_EM13;//Disable event mode
	EXTI->IMR1 |= EXTI_IMR1_IM13;//Enable interrupt mode
	EXTI->RTSR1 |= EXTI_RTSR1_RT13;//Enable rising edge
	//EXTI->RTSR1 &= ~EXTI_RTSR1_RT13;//Disable rising edge 
	EXTI->FTSR1 |= EXTI_FTSR1_FT13;//Enable falling edge
}


























