/*****************************************************************************
 @Project	: 
 @File 		: BSP.c
 @Details  	:
 @Author	: 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     XXXX-XX-XX  		Initial Release
   
******************************************************************************/
#include <Common.h>
#include "BSP.h"
#include "Hal.h"

/*****************************************************************************
 Define
******************************************************************************/


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/
extern void EXTI2_US0_ECHO_IRQHandler( uint32_t Status );
extern void EXTI5_US1_ECHO_IRQHandler( uint32_t Status );
extern void EXTI13_BTN_IRQHandler( uint32_t irqStatus );

/*****************************************************************************
 Local Variables
******************************************************************************/
void IRQInit( void )
{
	NVIC_ClearPendingIRQ( EXTI15_10_IRQn ); // clear any pending interrupts in the pipeline
	NVIC_EnableIRQ( EXTI2_IRQn );
	NVIC_EnableIRQ( EXTI9_5_IRQn );
	NVIC_EnableIRQ( EXTI15_10_IRQn );

}

/*****************************************************************************
 Implementation
******************************************************************************/
void EXTI0_IRQHandler( void )
{
	uint32_t irqStatus = EXTI->PR1;
	UNUSE( irqStatus );
}

void EXTI2_IRQHandler( void )
{
	uint32_t irqStatus = EXTI->PR1;
	if(0 != (irqStatus&EXTI_PR1_PIF2))
	{
		EXTI2_US0_ECHO_IRQHandler( irqStatus );
		EXTI->PR1 = EXTI_PR1_PIF2;
	}
}

void EXTI9_5_IRQHandler( void )
{
	uint32_t irqStatus = EXTI->PR1;
	if(0 != (irqStatus&EXTI_PR1_PIF5))
	{
		EXTI5_US1_ECHO_IRQHandler( irqStatus );
		EXTI->PR1 = EXTI_PR1_PIF5;
	}	
}
void EXTI15_10_IRQHandler( void )
{
    uint32_t irqStatus = EXTI->PR1;

    if( 0 != (irqStatus & EXTI_PR1_PIF10) )
    {
        EXTI->PR1 = EXTI_PR1_PIF10;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF11) )
    {
        EXTI->PR1 = EXTI_PR1_PIF11;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF12) )
    {
        //EXTI12_US1_ECHO_IRQHandler( irqStatus );
        EXTI->PR1 = EXTI_PR1_PIF12;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF13) ) // check if intr is triggered
    {
        EXTI13_BTN_IRQHandler(irqStatus); // the irq status is passed to the handler to check which button is pressed
		//This can also be in main.c
        EXTI->PR1 = EXTI_PR1_PIF13;  // Clear the pending interrupt flag for EXTI line 13
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF14) )
    {
        EXTI->PR1 = EXTI_PR1_PIF14;
    }

    if( 0 != (irqStatus & EXTI_PR1_PIF15) )
    {
        EXTI->PR1 = EXTI_PR1_PIF15;
    }
}

/*****************************************************************************
 Callback functions
******************************************************************************/


/*****************************************************************************
 Local functions
******************************************************************************/


/*****************************************************************************
 Interrupt functions
******************************************************************************/






















