//Define header file
#ifndef LcdFunctions_H
#define LcdFunctions_H

#include "spim.h"
#include "stdint.h"
#include "Common.h"
#include "stdint.h"
#include "LCD.h"
#include "gui.h"
#include "spim.h"

extern SPIM_HANDLE g_SpiHandle;

//Fucntion declaration
const char *MessageToPrint();
void LCD_Init(SPIM_HANDLE *spimHandle);
static void main_cbLcdTransferDone( void );
static void main_cbGuiFrameEnd( void );
void GUI_AppDraw(BOOL bFrameStart);

#endif