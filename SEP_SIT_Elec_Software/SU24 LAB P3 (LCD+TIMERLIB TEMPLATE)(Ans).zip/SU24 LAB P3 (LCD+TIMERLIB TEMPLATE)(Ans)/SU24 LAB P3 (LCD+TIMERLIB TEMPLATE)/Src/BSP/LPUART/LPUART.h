/* UART.h  */

#include "stdint.h"


#define PARITY_NONE 	0UL
#define PARITY_ODD 		1UL
#define PARITY_EVEN 	2UL

#define DATABITS7		 	7UL
#define DATABITS8		 	8UL
#define DATABITS9		 	9UL

#define STOP1		 			1UL
#define STOP2		 			2UL

//enum UART_parity {PARITY_NONE, PARITY_ODD, PARITY_EVEN};
//enum databits {DATABITS7, DATABITS8, DATABITS9};
//enum stopbits {STOP1, STOP2};

typedef struct _tagLPUART_Handle
{
	void 	*pLPUart;
	int		irq;
	int		baud;
	int		databits;
	int		parity;
	int		stop;
}LPUART_HANDLE, *PLPUART_HANDLE;

/******************************************************************************
 Global functions
******************************************************************************/
//void LPUART1_Init(uint32_t baud, uint32_t databits, uint32_t parity, uint32_t stop);
void LPUART1_Init(PLPUART_HANDLE pHandle);

void write_ASCII_LPUART1 (char);
