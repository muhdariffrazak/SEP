#include <Common.h>
#include "Hal.h"
#include "LPUART.h"

/*****************************************************************************
 Define
******************************************************************************/

#if defined (__ARMCC_VERSION)
	#if __ARMCC_VERSION < 6000000  
		struct __FILE
		{
			int handle; 
		};
	#endif
#endif

FILE __stdout; //STDOUT

int fputc(int ch, FILE * stream)
{
	//write_ASCII_LPUART1(ch); // for VCOM Port 
	//return (ch);
	return ITM_SendChar(ch); // for ITM re-direction to debug prinf viewer
}

void _sys_exit(int return_code) 
{
label:  goto label;  /* endless loop */
}