/***************************************************************************************
 @Project        : MET2001 Lab P3 Template
 @File           : main.c
 @Details        : Main entry
 @Author         : muhammadariff.b
 @Hardware       : STM32
 
 ---------------------------------------------------------------------------------------
 @Revision   :
  Ver      Author         Date            Changes
 ---------------------------------------------------------------------------------------
   1.0     fongfh      12-Feb-2023   Initial Release - STM32G474RE
                                    Debug interface - STLink
                                    Support TFT LCD ST7735
                                    Virtual COM Port @LPUART (PA2-TX, PA3-RX)`
                                      - 921,600,8,no parity,1 Stop
   2.0     fongfh      17 May 2023    Add Event Recorder codes
                                    Add option for ITM redirection to Debug printf Viewer
*****************************************************************************************/

#include <Common.h>
#include "Hal.h"
#include "BSP.h"
#include "Timer.h"

#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "IRQ.h"

#include "LPUART.h"
#include "EventRecorder.h"

#include <stdio.h>
#include <stdbool.h>

/*****************************************************************************
 Define
******************************************************************************/
#define SYS_TICK_MS             500     // Software Timer with 500 ms
#define LCD_BUF_SIZE            4096
#define LCD_UPDATE_MS           10

#define DEBOUNCE_DELAY_MS       50      // Debounce delay in milliseconds
#define DEBOUNCE_TIMER_INTERVAL_MS 5   // Timer interval for debounce checking

// GPIO Pins for LEDs
#define PA_RED      15U
#define PB_GREEN    1U
#define PC_BLUE     6U

// Macros for controlling LEDs
#define RED_LED_ON()        (GPIOA->BSRR = BIT(PA_RED))    // Set bit 15
#define RED_LED_OFF()       (GPIOA->BRR = BIT(PA_RED))     // Reset bit 15
#define RED_LED_SET(x)      ((x) ? RED_LED_ON() : RED_LED_OFF())  // Set or reset based on x

#define GREEN_LED_ON()      (GPIOB->BSRR = BIT(PB_GREEN))  // Set bit 1
#define GREEN_LED_OFF()     (GPIOB->BRR = BIT(PB_GREEN))   // Reset bit 1
#define GREEN_LED_SET(x)    ((x) ? GREEN_LED_ON() : GREEN_LED_OFF())  // Set or reset based on x

#define BLUE_LED_ON()       (GPIOC->BSRR = BIT(PC_BLUE))   // Set bit 6
#define BLUE_LED_OFF()      (GPIOC->BRR = BIT(PC_BLUE))    // Reset bit 6
#define BLUE_LED_SET(x)     ((x) ? BLUE_LED_ON() : BLUE_LED_OFF())    // Set or reset based on x

/*****************************************************************************
 Type definition
******************************************************************************/

/*****************************************************************************
 Global Variables
******************************************************************************/
volatile BOOL g_buttonPressed = false;     // Global flag for button press detection
static volatile BOOL g_lastButtonState = false;  // Last stable state of the button

/*****************************************************************************
 Const Local Variables
******************************************************************************/

/*****************************************************************************
 Local Variables
******************************************************************************/
static uint32_t RedDuration = 0;           // Example: Red LED at 0% duty cycle
static uint32_t GreenDuration = 0;         // Example: Green LED at 0% duty cycle
static uint32_t BlueDuration = 0;          // Example: Blue LED at 0% duty cycle

/* SysTick declarations */
static volatile int g_nSysTick = SYS_TICK_MS;
static volatile BOOL g_bSysTickReady = FALSE;
static volatile BOOL g_bToggle = FALSE;    // Toggle variable for LED or similar

/* TFT LCD declarations */
static SPIM_HANDLE g_SpimHandle;
static GUI_DATA g_aBuf[LCD_BUF_SIZE];
static GUI_MEMDEV g_MemDev;
volatile BOOL g_bLcdFree = TRUE;

static volatile int g_nLCDTick = LCD_UPDATE_MS;
static volatile BOOL g_nLCDTickReady = FALSE;

/* Timer 1 declarations */
static TIMER_HANDLE g_Timer1Handle;        // Timer handle for debounce
static TIMER_HOOK g_Timer1Hook1;           // Timer hook for debounce
static volatile BOOL g_bcallback1 = FALSE;

/* LPUART declarations */
static LPUART_HANDLE g_LPUartHandle;

/* General program declarations */
static uint32_t g_nCount = 0;              // Counter variable
static uint32_t g_nTimeSec = 0;            // Time in seconds
volatile uint32_t g_Millis = 0;            // Millisecond counter

/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit(void);           // Function to initialize SPI bus
static void main_LcdInit(void);            // Function to initialize LCD
static void SetOff(void);                  // Function to turn off all LEDs
static void SetMagneta(void);              // Function to turn on Red and Blue LEDs
static void UpdateLEDs(void);              // Function to update LEDs

// Systick delay function
void NonBlockingDelay(uint32_t ms);

/*****************************************************************************
 Callback functions
******************************************************************************/
static void main_cbGuiFrameEnd(void);      // GUI frame end callback
static void main_cbLcdTransferDone(void);  // LCD transfer done callback
static void main_cbTimer1(void);           // Timer 1 callback function

/*****************************************************************************
 Implementation 
******************************************************************************/
int main(void)
{
    EventRecorderInitialize(EventRecordAll, 1); // Initialize & start Event Recorder
    BSPInit();                                  // Board Support Package initialization

    SysTick_Config(SystemCoreClock / 1000);     // Configure SysTick timer for 1 ms interval

    TimerInit(&g_Timer1Handle, 1, DEBOUNCE_TIMER_INTERVAL_MS);    // Initialize Timer 1 for button debounce
    TimerAddHook(&g_Timer1Handle, &g_Timer1Hook1, main_cbTimer1);  // Add callback hook for Timer 1
    TimerStart(&g_Timer1Handle);                // Start the debounce timer

    // Initialize LPUART1
    g_LPUartHandle.baud = 921600;
    g_LPUartHandle.databits = DATABITS8;
    g_LPUartHandle.stop = STOP1;
    g_LPUartHandle.parity = PARITY_NONE;
    LPUART1_Init(&g_LPUartHandle);

    main_SpimInit();    // SPI bus initialization
    main_LcdInit();     // LCD initialization
    IRQInit();          // Initialize ISRs

    printf("MET2001 SU24 ...\r\n");

    // Runtime for loop
    for (;;)
    {
        if (g_bSysTickReady)
        {
            g_bSysTickReady = FALSE;
            // Handle SysTick tasks
        }

        if (g_bcallback1)
        {
            g_bcallback1 = FALSE;
            LED_LD2_SET(g_bToggle);    // Toggle LED or similar
            g_bToggle = !g_bToggle;
        }

        if (g_nLCDTickReady)
        {
            if (g_bLcdFree)
            {
                g_nLCDTickReady = FALSE;
                g_bLcdFree = FALSE;
                GUI_Draw_Exe(); // Update LCD screen
            }
        }
    }
}

/*****************************************************************************
 Callback functions
******************************************************************************/
void GUI_AppDraw(BOOL bFrameStart)
{
    // This function invokes from GUI library
    static char lightStatus[10];

    if (bFrameStart)
    {
        // Format light status: R-G-B based on LED durations
        sprintf(lightStatus, "%d-%d-%d", (RedDuration > 0), (GreenDuration > 0), (BlueDuration > 0));
    }

    // Set background to blue
    GUI_Clear(ClrBlue);

    GUI_SetColor(ClrYellow);
    GUI_SetFont(&g_sFontCalibri24);
    GUI_PrintString(lightStatus, ClrGreenYellow, 5, 61); // Display light status

    // Display BTN status
    GUI_PrintString(g_buttonPressed ? "BTN: 1" : "BTN: 0", ClrYellowGreen, 5, 21);

    // Display LD2 status
    GUI_PrintString(g_bToggle ? "LD2: 1" : "LD2: 0", ClrYellowGreen, 5, 41);

    // Display CPU clock frequency
    char cpuClock[20];
    sprintf(cpuClock, "CPU: %d MHz", SystemCoreClock / 1000000);
    GUI_PrintString(cpuClock, ClrYellowGreen, 5, 1);
	GUI_PrintString("Ariff's Lab 3", ClrDarkRed, 5, 81); // Display light status
}

static void main_cbLcdTransferDone(void)
{
    g_bLcdFree = TRUE;  // Set LCD free after transfer
}

static void main_cbGuiFrameEnd(void)
{
    g_bLcdFree = TRUE;  // Set LCD free after frame ends
}

// Call-back function: executes at frequency defined by TimerInit()
static void main_cbTimer1(void)
{
    // Read current button state
    bool currentButtonState = (GPIOC->IDR & BIT(PC_BTN)) != 0;

    // Debounce logic - compare with last stable state
    if (currentButtonState == g_lastButtonState)
    {
        // Update button pressed state only if it's stable
        g_buttonPressed = currentButtonState;
    }
    else
    {
        // Update last stable state with current state
        g_lastButtonState = currentButtonState;
    }

    if (g_buttonPressed)
    {
        static uint32_t lastToggleMillis = 0;
        uint32_t currentMillis = g_Millis;

        // Toggle LEDs at 2 Hz (500 ms ON, 500 ms OFF)
        if (currentMillis - lastToggleMillis >= 500)
        {
            lastToggleMillis = currentMillis;

            // Toggle LEDs to magenta color
            RedDuration = (RedDuration == 0) ? 40 : 0;   // 40% duty cycle for red LED
            BlueDuration = (BlueDuration == 0) ? 90 : 0; // 90% duty cycle for blue LED
            GreenDuration = 0;                          // Ensure green LED is off
            UpdateLEDs();   // Update LED states
        }
    }
    else
    {
        // Turn off LEDs if button is not pressed
        SetOff();
        UpdateLEDs();   // Update LED states
    }
}

/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit(void)
{
    SpimInit(&g_SpimHandle, 2, 15000000U, SPI_CLK_INACT_LOW, SPI_CLK_RISING_EDGE, SPI_DATA_SIZE_8);
}

static void main_LcdInit(void)
{
    int screenx, screeny;

    // Choosing a landscape orientation
    LcdInit(&g_SpimHandle, LCD_LANDSCAPE);

    // Get physical LCD size in pixels
    LCD_GetSize(&screenx, &screeny);

    // Initialize GUI
    GUI_Init(&g_MemDev, screenx, screeny, g_aBuf, sizeof(g_aBuf));

    // Switch to transfer word for faster performance
    SpimSetDataSize(&g_SpimHandle, SPI_DATA_SIZE_16);
    GUI_16BitPerPixel(TRUE);

    // Clear LCD screen to Blue
    GUI_Clear(ClrBlue);

    // Set font color background
    GUI_SetFontBackColor(ClrBlue);
    
    // Set font
    GUI_SetFont(&g_sFontCalibri10);

    LCD_AddCallback(main_cbLcdTransferDone);

    GUI_AddCbFrameEnd(main_cbGuiFrameEnd);

    // Backlight ON
    LCD_BL_ON();
}

void SetOff(void)
{
    RedDuration = 0;    // Red LED at 0% duty cycle
    GreenDuration = 0;  // Green LED at 0% duty cycle
    BlueDuration = 0;   // Blue LED at 0% duty cycle
}

void SetMagneta(void)
{
    RedDuration = 40;   // Red LED at 40% duty cycle
    GreenDuration = 0;  // Green LED at 0% duty cycle
    BlueDuration = 90;  // Blue LED at 90% duty cycle
}

void UpdateLEDs(void)
{
    // Update Red LED based on duty cycle
    GPIOA->BSRR = RedDuration ? (GPIO_BSRR_BS15) : (GPIO_BSRR_BR15);

    // Update Green LED based on duty cycle
    GPIOB->BSRR = GreenDuration ? (GPIO_BSRR_BS1) : (GPIO_BSRR_BR1);

    // Update Blue LED based on duty cycle
    GPIOC->BSRR = BlueDuration ? (GPIO_BSRR_BS6) : (GPIO_BSRR_BR6);

    g_bToggle = (RedDuration > 0 || GreenDuration > 0 || BlueDuration > 0);
}

/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler(void)
{
    g_nCount++;
    g_Millis++;
    if (g_nCount == 1000)
    {
        g_nCount = 0;
        g_nTimeSec++;

        if (g_nTimeSec > 24 * 60 * 60)
        {
            g_nTimeSec = 0;
        }
    }

    if (g_nSysTick != 0)
    {
        g_nSysTick--;
        if (g_nSysTick == 0)
        {
            g_nSysTick = SYS_TICK_MS;
            g_bSysTickReady = TRUE;
        }
    }

    if (g_nLCDTick != 0)
    {
        g_nLCDTick--;
        if (g_nLCDTick == 0)
        {
            g_nLCDTick = LCD_UPDATE_MS;
            g_nLCDTickReady = TRUE;
        }
    }
}

void EXTI13_BTN_IRQHandler(uint32_t irqStatus)
{
    // Check if PC13 is high (button pressed)
    bool currentButtonState = (GPIOC->IDR & BIT(PC_BTN)) != 0;

    // Update last stable state with current state
    g_lastButtonState = currentButtonState;
}
