//Define header file
#ifndef RemoteFunctions_H
#define RemoteFunctions_H

#include "Common.h"
#include "Hal.h"
#include "IRQ.h"
#include "BSP.h"
#include "Timer.h"
#include "spim.h"
#include "I2c.h"
#include "Serial.h"
#include "Remote.h"//header file for motor control
#include "UbiquityMotor.h"//header file for motor control

extern UART_HANDLE g_UartRemoteHandle; //UART handle for remote controller
extern volatile BOOL g_abUartRemoteReady; //Boolean variable for remote controller
extern char g_aUartRemoteTxBuf[64]; //Buffer for transmitting data
extern char g_aUartRemoteRxBuf[64]; //Buffer for receiving data

//Fucntion declaration
void remote_UartInit(void);
void main_HostCmdExe( char *pCmd );
static void main_cbUartRemoteOnRx( void ); 

#endif