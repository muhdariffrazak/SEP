#include "RemoteFunctions.h"
#include "Common.h"
#include "Hal.h"
#include "IRQ.h"
#include "BSP.h"
#include "Timer.h"
#include "spim.h"
#include "I2c.h"
#include "Serial.h"
#include "Remote.h"//header file for motor control
#include "UbiquityMotor.h"//header file for motor control

//import uint8_t, uint16_t, uint32_t from Common.h
//import UART_HANDLE from Hal.h
extern UART_HANDLE g_UartRemoteHandle; //UART handle for remote controller
extern volatile BOOL remote_status; //Boolean variable for remote controller
extern char g_aUartRemoteTxBuf[64]; //Buffer for transmitting data
extern char g_aUartRemoteRxBuf[64]; //Buffer for receiving data
extern char motor_direction[10]; //Motor direction
extern volatile BOOL g_abUartRemoteReady; //Boolean variable for remote controller

extern BOOL mode; //Boolean variable for mode



void remote_UartInit( void )
{
	int res;// Remote controller from esp32
    res = SerialInit( &g_UartRemoteHandle, 5, 921600 );
    ASSERT( res == UART_STS_OK );
	(res == UART_STS_OK)?(remote_status = TRUE):(remote_status = FALSE);

    SerialConfig(
    	&g_UartRemoteHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartRemoteHandle, 
    	g_aUartRemoteTxBuf,
    	sizeof(g_aUartRemoteTxBuf),
    	g_aUartRemoteRxBuf,
    	sizeof(g_aUartRemoteTxBuf) );

   SerialAddCallback( &g_UartRemoteHandle, 0, main_cbUartRemoteOnRx );
}

void main_HostCmdExe(char *pCmd)
{	if (mode == TRUE) 
    {
        // If in autonomous mode, ignore remote commands
		SerialRxEmpty(&g_UartRemoteHandle);//This function is used to empty the receive buffer of the UART so that the buffer does not overflow
        return;
    }
	else
	{
		HOST_REQ_PKT *req = (HOST_REQ_PKT *)pCmd;// Cast to HOST_REQ_PKT and assign to req

			switch (req->Cmd.Cmd)//req points to the command
			{
				case CMD_HOST_STOP:
					MotorsStop();
					strncpy((char *)motor_direction, "S", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: STOP\r\n");
					break;

				case CMD_HOST_MOVE_FWD:
					MotorsMoveFront();
					strncpy((char *)motor_direction, "F", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: FWD\r\n");
					break;

				case CMD_HOST_MOVE_BWD:
					MotorsMoveBack();
					strncpy((char *)motor_direction, "B", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: BWD\r\n");
					break;

				case CMD_HOST_ROTATE_LEFT:
					MotorsRotateLeft();
					strncpy((char *)motor_direction, "L", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: ROTATE LEFT\r\n");
					break;

				case CMD_HOST_ROTATE_RIGHT:
					MotorsRotateRight();
					strncpy((char *)motor_direction, "R", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: ROTATE RIGHT\r\n");
					break;

				default:
					TRACE("cmd: Invalid\r\n");
					break;
			}
	}		
 }

 
static void main_cbUartRemoteOnRx( void )
{
    if (mode == FALSE) // Only set the flag if not in autonomous mode
    {
        g_abUartRemoteReady = TRUE;
    }
}




