#include "LcdFunctions.h"
#include <stdio.h>
#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "Common.h"
#include "Hal.h"
#include "stdint.h"
//include UltraSound.h with relative path
#include "UltraSound.h"
//header file for IRQ
#include "IRQ.h"
#include "I2c.h"
#include "DistSensor.h"

//import uint8_t, uint16_t, uint32_t from Common.h

#define SYS_TICK_MS 			500 	/* Software Timer with 500 ms */
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10

//static SPIM_HANDLE			g_SpimHandle; //used for LcdInit(spimHandle, LCD_LANDSCAPE);
static GUI_DATA					g_aBuf[LCD_BUF_SIZE];
static GUI_MEMDEV				g_MemDev;


//imporrt g_lcdFree from main.c
extern volatile BOOL g_bLcdFree;
extern SPIM_HANDLE g_SpimHandle;

//import g_nTimeSec, g_nCount from main.c
extern volatile uint32_t g_nTimeSec;
extern volatile uint32_t g_nCount;

extern volatile BOOL motor_status;
extern volatile BOOL remote_status;

//import motor_direction variable from main.c
extern char motor_direction;

extern BOOL USonicError;
extern BOOL USonicError1;
extern BOOL USonicError2;
extern BOOL USonicError3;

extern int USonicDist;
extern int USonicDist1;
extern int USonicDist2;
extern int USonicDist3;

extern int mode;
extern int Obstacle;

extern VL53L0X_Dev_t 		g_hDistSensor[TOF_TOTAL];
extern int					g_nDistData[TOF_TOTAL];

void LCD_Init(SPIM_HANDLE *spimHandle)
{
	int screenx;
	int screeny;
	
	/* g_SpimHandle shall be initialized before use */
	
	/* Choosing a landscape orientation */
	LcdInit(spimHandle, LCD_LANDSCAPE);
	
	/* Get physical LCD size in pixels */
	LCD_GetSize( &screenx, &screeny );
	
	/* Initialize GUI */
	GUI_Init(
		&g_MemDev,
		screenx,
		screeny,
		g_aBuf,
		sizeof(g_aBuf) );
	
	/* Switch to transfer word for faster performance */
	SpimSetDataSize( spimHandle, SPI_DATA_SIZE_16 );
	GUI_16BitPerPixel( TRUE );
	
	/* Clear LCD screen to Blue */
	GUI_Clear( ClrBlue );

    /* set font color background */
    GUI_SetFontBackColor( ClrBlue );
    
    /* Set font */
    GUI_SetFont( &g_sFontCalibri10 );
	
	LCD_AddCallback( main_cbLcdTransferDone );
	
	GUI_AddCbFrameEnd( main_cbGuiFrameEnd );
	
	/* Backlight ON */
	LCD_BL_ON();
}


void GUI_AppDraw( BOOL bFrameStart )
{
	static char buf0[20],buf1[20],buf2[15],buf3[12],buf4[20],buf5[20],buf6[20];

	if( TRUE == bFrameStart ) // framestart = TRUE indicate the display dynamic area can be updated.
	{
    /* choose one to display - count or time elapsed */
		//g_nCount++;
		//sprintf( buf0, "%08X", g_nCount);
		sprintf( buf0, "%02u:%02u:%02u", (g_nTimeSec/3600)%24, (g_nTimeSec/60)%60, g_nTimeSec%60 );
		sprintf (buf1, "%d MHz", SystemCoreClock/1000000);
		sprintf( buf2, "%08X", SCB->CPUID);
	}
		
	/* Set background to blue. Refer to gui.h for color code */

	GUI_Clear( ClrWhite ); 
	GUI_SetColor( ClrBlack );
	GUI_SetFont( &g_sFontCalibri10 );
	//print status of uart for motor and remote control in same line using GUI_PrintString and string formatting
	char status_string[50]; // Buffer to store the formatted string
	// Format the string based on the values of motor_status and remote_status
	sprintf(status_string, "UART: Motor: %s, Remote: %s",
			(motor_status == 1) ? "1" : "0",
			(remote_status == 1) ? "1" : "0");
	// Print the formatted string using GUI_PrintString
	(motor_status==1 || remote_status==1 )? GUI_PrintString(status_string, ClrGreen, 5, 10) : GUI_PrintString(status_string,ClrRed, 5, 10);
	// Format the string and print the motor direction
	sprintf(buf3, "MotorDir: %c", motor_direction);
	// Print the formatted string using GUI_PrintString
	GUI_PrintString(buf3, ClrBlack, 5, 20);
	/* Display g_nCount string */

	//Display the error if the ultrasonic sensor is not working, else display the distance
	(USonicError == TRUE)? sprintf(buf4, "BackUS Error") : sprintf(buf4, "Back Dist: %d cm", USonicDist);
	//Print in red if error, else in green
	(USonicError == TRUE)? GUI_PrintString(buf4, ClrRed, 5, 30) : GUI_PrintString(buf4, ClrGreen, 5, 30);
	
	//Display the error if the ultrasonic sensor is not working, else display the distance
	(USonicError1 == TRUE)? sprintf(buf5, "LeftUS Error") : sprintf(buf5, "Left Dist: %d cm", USonicDist1);
	//Print in red if error, else in green
	(USonicError1 == TRUE)? GUI_PrintString(buf5, ClrRed, 5, 40) : GUI_PrintString(buf5, ClrGreen, 5, 40);

	//Display the error if the ultrasonic sensor is not working, else display the distance
	(USonicError2 == TRUE)? sprintf(buf6, "FrontUS Error") : sprintf(buf6, "Front Dist: %d cm", USonicDist2);
	//Print in red if error, else in green
	(USonicError2 == TRUE)? GUI_PrintString(buf6, ClrRed, 5, 50) : GUI_PrintString(buf6, ClrGreen, 5, 50);

	//Display the error if the ultrasonic sensor is not working, else display the distance
	(USonicError3 == TRUE)? sprintf(buf6, "RightUS Error") : sprintf(buf6, "Right Dist: %d cm", USonicDist3);
	//Print in red if error, else in green
	(USonicError3 == TRUE)? GUI_PrintString(buf6, ClrRed, 5, 60) : GUI_PrintString(buf6, ClrGreen, 5, 60);

	GUI_PrintString( "GROUP 4", ClrBlack, 5, 1);

	//Display TOF sensor data
	for( int i = 0; i < TOF_TOTAL; i++ )
	{
		//Display the error if the TOF sensor is not working, else display the distance
		(g_nDistData[i] == -1)? sprintf( buf6, "TOF%d Error", i) : sprintf( buf6, "TOF%d Dist: %d mm", i, g_nDistData[i]);
		//Print in red if error, else in green
		(g_nDistData[i] == -1)? GUI_PrintString( buf6, ClrRed, 5, 70 + (i * 10)) : GUI_PrintString( buf6, ClrGreen, 5, 70 + (i * 10));
	}

	//Display the mode of operation. 0: none. 1: left. 2: right
	if (mode == 0)
	{
		GUI_PrintString("Mode: None", ClrBlack, 5, 90);
	}
	else if (mode == 1)
	{
		GUI_PrintString("Mode: Left", ClrBlack, 5, 90);
	}
	else if (mode == 2)
	{
		GUI_PrintString("Mode: Right", ClrBlack, 5, 90);
	}
	//clear buffer
	memset( buf0, 0, sizeof(buf0) );
	memset( buf1, 0, sizeof(buf1) );
	memset( buf2, 0, sizeof(buf2) );
	memset( buf3, 0, sizeof(buf3) );
	memset( buf4, 0, sizeof(buf4) );
	memset( buf5, 0, sizeof(buf5) );
	memset( buf6, 0, sizeof(buf6) );
	//clear lcd buffer
	//memset( g_aBuf, 0, sizeof(g_aBuf) );
}

static void main_cbLcdTransferDone( void )
{
	g_bLcdFree = TRUE;
}

static void main_cbGuiFrameEnd( void )
{
	g_bLcdFree = TRUE;
}
