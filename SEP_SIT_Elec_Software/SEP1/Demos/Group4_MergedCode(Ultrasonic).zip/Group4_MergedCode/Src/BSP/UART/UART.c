/*****************************************************************************
 @Project		: 
 @File 			: UART.c
 @Details  	: All Ports and peripherals configuration                    
 @Author		: 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  fongfh     12-Feb-23  		Initial Release for LPUART1
   
******************************************************************************/

#include <Common.h>
#include "Hal.h"
#include "UART.h"


/** LPUART1 Initialization  		**/
	/*  LPUART1 TX - PA2   				*/
	/*  LPUART1 RX - PA3						*/

void LPUART1_Init(uint32_t baud, uint32_t databits, uint32_t parity, uint32_t stop)
{
	/* peripherals bus clocks enable */
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	
	/* Port pins  */
	GPIOA->MODER &= ~GPIO_MODER_MODE2;		/* LPUART TX - PA2 */
	GPIOA->MODER |= (GPIO_MODE_AF<<GPIO_MODER_MODE2_Pos);
	GPIOA->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED2;
	GPIOA->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED2_Pos);
	GPIOA->AFR[0] &= ~GPIO_AFRL_AFSEL2_Msk;
	GPIOA->AFR[0] |= (GPIO_LPUART_AF12<<GPIO_AFRL_AFSEL2_Pos);	

	GPIOA->MODER &= ~GPIO_MODER_MODE3;		/* LPUART RX - PA3 */
	GPIOA->MODER |= (GPIO_MODE_AF<<GPIO_MODER_MODE3_Pos);
	GPIOA->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED3;
	GPIOA->OSPEEDR |= (GPIO_SPEED_MAX<<GPIO_OSPEEDR_OSPEED3_Pos);
	GPIOA->AFR[0] &= ~GPIO_AFRL_AFSEL3_Msk;
	GPIOA->AFR[0] |= (GPIO_LPUART_AF12<<GPIO_AFRL_AFSEL3_Pos);
	
	// LPUARTSEL[1:0]:
	//   - 00 = PCLK, 01 = SYSCLK **, 10 = HSI16, 11 = LSE
	RCC->CCIPR &= ~RCC_CCIPR_LPUART1SEL_Msk;
	RCC->CCIPR |= 1<<RCC_CCIPR_LPUART1SEL_Pos; 	// select System CLK as LPUART clock **
	RCC->APB1ENR2 |= RCC_APB1ENR2_LPUART1EN; 		// enable clock to LPUART
	
	RCC->APB1RSTR2 |= RCC_APB1RSTR2_LPUART1RST; // do a reset of LPUART
	CLOCK_WAIT2(); // 2 clock cycles
	RCC->APB1RSTR2 &= ~RCC_APB1RSTR2_LPUART1RST; 
	
	LPUART1->CR1 &= ~USART_CR1_UE; // disable LPUART1
	//LPUART1->CR1 &= ~USART_CR1_FIFOEN; // disable FIFO 
	LPUART1->CR1 |= USART_CR1_FIFOEN; // enable FIFO
	
	/* Word length:								*/ 
	//   M[1:0] = 00: 1 Start bit, 8 Data bits, n Stop bit
  //   M[1:0] = 01: 1 Start bit, 9 Data bits, n Stop bit
  //   M[1:0] = 10: 1 Start bit, 7 Data bits, n Stop bit 
	switch (databits)
	{
		case DATABITS7:
			LPUART1->CR1 &= ~USART_CR1_M0;
			LPUART1->CR1 |= USART_CR1_M1;
		break;
		case DATABITS8:
			LPUART1->CR1 &= ~USART_CR1_M0;
			LPUART1->CR1 &= ~USART_CR1_M1;
		break;
		case DATABITS9:
			LPUART1->CR1 |= USART_CR1_M0;
			LPUART1->CR1 &= ~USART_CR1_M1;
		break;
		default: break;
	}
	
	/* parity						*/
	switch (parity)
	{
		case PARITY_NONE:
			LPUART1->CR1 &= ~USART_CR1_PCE; // disable parity
		break;
		case PARITY_ODD:
			LPUART1->CR1 |= USART_CR1_PCE;
			LPUART1->CR1 |= USART_CR1_PS; 
		break;
		case PARITY_EVEN:
			LPUART1->CR1 |= (USART_CR1_PCE);
			LPUART1->CR1 &= ~USART_CR1_PS; 
		break;
		default: break;
	}
	
	/* Stop bits							*/
	LPUART1->CR2 &= ~USART_CR2_STOP_Msk;
	switch (stop)
	{
		case STOP1:
			LPUART1->CR2 |= 0x00<<USART_CR2_STOP_Pos; // 1 stop bit **		
		break;
		case STOP2:
			LPUART1->CR2 |= 0x02<<USART_CR2_STOP_Pos; // 2 stop bit **		
		break;
		default: break;
	}
	
	// Ex: set baud rate: BRR = (256 * 170MHZ)/115,200 = 377,777.7778 = 0x5C3B2
	LPUART1->BRR = (int)(((SystemCoreClock*1.0)/baud)*256 + 0.5);
	
	LPUART1->CR1 |= USART_CR1_TE; // enable TX
	LPUART1->CR1 |= USART_CR1_UE; // enable LPUART1
}

/** Write an ASCII character to LPUART1				**/
/** character = ASCII to write 							**/
void write_ASCII_LPUART1 (char character )
{
	int i;
	while( 0 == ((LPUART1->ISR >> USART_ISR_TXE_Pos) & 1UL)){ } /* wait if TX FIFO full		*/
	
	//for (i=0;i<130;i++) // ~3us @170MHz
	//	CLOCK_WAIT4(); // 4 clock cycles
	
	for (i=0;i<(3*SystemCoreClock)/1000000;i++) // clock independent
		CLOCK_WAIT4();

	LPUART1->TDR = character;	/* write character to UART data reg */
}
