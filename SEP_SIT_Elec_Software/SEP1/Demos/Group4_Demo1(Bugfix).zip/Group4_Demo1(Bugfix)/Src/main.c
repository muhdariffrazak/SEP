/*****************************************************************************
 @Project		: DEMO 1
 @File 			: main.c
 @Details  	: Main entry
 @Author		: muhammadariff.b (Ariff)
 @Hardware	: STM32
 
 ----------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 ----------------------------------------------------------------------------
   1.0  XXXXXX     12-Feb-2023  	Initial Release
   1.1  muhammadariff.b  2-July-2024  	Added motor control,ultrasonic sensor and remote control
   1.2 muhammadariff.b  3-July-2024  	Added autonomous mode	
   1.3 muhammadariff.b  4-July-2024  	Fixed bugs with clearing the receive buffer																	
*****************************************************************************/
#include <Common.h>
#include "Hal.h"
#include "BSP.h"
#include "Timer.h"
#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "Serial.h"
#include "Remote.h"//header file for motor control
#include "UbiquityMotor.h"//header file for ultrasonic sensor
#include "LcdFunctions.h"//header file for ultrasonic sensor
#include "UltraSound.h"//header file for ultrasonic sensor
#include "IRQ.h"//header file for ultrasonic sensor

/* NOTE: Please follows code style provided. All tabs is 4 space */

/*****************************************************************************
 Define
******************************************************************************/
#define SYS_TICK_MS 500 /* Software Timer with 500 ms */
#define LCD_BUF_SIZE            4096
#define LCD_UPDATE_MS           10

// Motor control
#define MOTOR_TICK_MS           10

// Ultrasonic sensor
#define TOTAL_USONIC            2U
#define USONIC_TICK_MS          100U  // measure ultrasound distances every USONIC_TICK_MS ms
#define USONIC_ECHO_TIMEOUT     200U // timeout if no ECHO back 

/*****************************************************************************
 Type definition
******************************************************************************/
typedef union _tagUS_Status
{
    uint32_t Status;    
    struct
    {
      uint32_t bUSonic0 :1;
      uint32_t bUSonic1 :1;
      uint32_t bUSonic2 :1;
      uint32_t bUSonic3 :1;
	  uint32_t bError0 	:1;
      uint32_t bError1 	:1;
      uint32_t bError2 	:1;
      uint32_t bError3 	:1;
      uint32_t Reserved :24;
    }b;
}US_STATUS, *PUS_STATUS;

/*****************************************************************************
 Global Variables
******************************************************************************/
// Systic declarations
static volatile int         g_nSysTick = SYS_TICK_MS;
static volatile BOOL        g_bSysTickReady = FALSE;
static volatile BOOL        g_bToggle = FALSE;

// LCD declarations
static SPIM_HANDLE           g_SpimHandle;
volatile GUI_DATA            g_aBuf[LCD_BUF_SIZE];
volatile GUI_MEMDEV          g_MemDev;
volatile BOOL                g_bLcdFree  = TRUE;

static volatile int          g_nLCDTick = LCD_UPDATE_MS;
static volatile BOOL         g_nLCDTickReady = FALSE;

// Global variables for time and count
volatile uint32_t            g_nCount = 0;
volatile uint32_t            g_nTimeSec = 0;

// Timer declarations
static TIMER_HANDLE          g_Timer1Handle; /* This is timer 1 handle */
static TIMER_HOOK            g_TImer1Hook;    /* This is hook 1 to timer 1 */

// Remote control handle
static UART_HANDLE           g_UartRemoteHandle;
static char                  g_aUartRemoteTxBuf[64];
static char                  g_aUartRemoteRxBuf[64];
static volatile BOOL         g_abUartRemoteReady = FALSE;
static int                   g_nCmd = 0;

// Declare motor control handle
static UART_HANDLE           g_UartMCBHandle;
static char                  g_aUartMCBTxBuf[64];
static char                  g_aUartMCBRxBuf[64];
static volatile BOOL         g_abUartMCBReady = FALSE;

static volatile int          g_nMotorTick = MOTOR_TICK_MS;
static volatile BOOL         g_bMotorTickReady = FALSE;

volatile BOOL motor_status = FALSE;
volatile BOOL remote_status = FALSE;
volatile char motor_direction[10] = " ";  // Motor direction
/*****************************************************************************
 Const Local Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
// Ultrasonic sensor
static USONIC_HANDLE         g_USHandles[TOTAL_USONIC];
static volatile US_STATUS    g_USonicStatus;
static volatile int          g_nUSonicTick = USONIC_TICK_MS;
static volatile BOOL         g_bUSonicTickReady = FALSE;
volatile BOOL USonicError = FALSE;  // Error flag for ultrasonic sensor 0
volatile BOOL USonicError1 = FALSE;  // Error flag for ultrasonic sensor 1
volatile int USonicDist = 0;  // Distance for ultrasonic sensor 0
volatile int USonicDist1 = 0;  // Distance for ultrasonic sensor 1

/*****************************************************************************
Control flags(Global Variables)
******************************************************************************/
volatile BOOL mode = FALSE;  // Mode flag for manual and autonomous mode
volatile BOOL AutoDir = TRUE;  // Direction flag for autonomous mode
volatile int Obstacle = 0;  // Obstacle counter for autonomous mode
volatile BOOL obstacleDetected = FALSE;  // Obstacle detected flag for autonomous mode
volatile BOOL g_bstop = FALSE;  // Stop flag for manual mode



/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void );
static void motor_UartInit( void );
static void remote_UartInit( void );
static void main_HostCmdExe( char *pCmd );
static void main_UltraSoundInit( void );


/*****************************************************************************
 Callback functions
******************************************************************************/
static void main_cbUartRemoteOnRx( void );  // Callback function for remote control
static void main_cbUS0OnTrigger( BOOL bON );
static void main_cbUS1OnTrigger( BOOL bON );
static void main_cbUS0OnReady( int Error );
void main_AutoMotorControl(void);


/*****************************************************************************
 Interrupt functions
******************************************************************************/
void EXTI13_BTN_IRQHandler( uint32_t irqStatus);
/*****************************************************************************
 Implementation 
******************************************************************************/
int main( void )
{
	char *cmd;
	int dist = 0;
	BSPInit(); // Initialize the board support package
	SysTick_Config(SystemCoreClock / 1000); // Generate interrupt each 1 ms as system tick
	TRACE("SystemCoreClock %dHz\r\n", SystemCoreClock);
	main_SpimInit();//// Initialize SPI module
	LCD_Init(&g_SpimHandle);// Initialize LCD
	remote_UartInit();// Initialize UART for remote control
	motor_UartInit(); // Initialize UART for motor control
	MotorsInit(&g_UartMCBHandle); // Initialize motor control
	MotorsSetSpeeds(20, 20);  // Speed at 25 ticks/100ms
	TimerInit(&g_Timer1Handle, 1U, 10000); // Initislise timer with handle
	main_UltraSoundInit(); // Initialize ultrasonic sensor
    TimerStart(&g_Timer1Handle);// Start the timer
	IRQInit();// Initialize the interrupt
   	USonicTrigger(&g_USHandles[0]);// Trigger ultrasonic sensor 0

	// Runtime for loop
	for (;;)
    {	
		
		// Handle system tick
		if (FALSE != g_bSysTickReady)
		{
			g_bSysTickReady = FALSE;

			// Every 500ms per tick    
			LED_LD2_SET(g_bToggle);

			g_bToggle = !g_bToggle;
		}

		// Handle LCD tick
        if (FALSE != g_nLCDTickReady)
		{
			if (0 != g_bLcdFree)
			{
				g_nLCDTickReady = FALSE;
				g_bLcdFree = FALSE;// Draw every block. Consume less time
				GUI_Draw_Exe();
			}
		}
		
		// Handle UART remote
		if (FALSE != g_abUartRemoteReady)
		{
			g_abUartRemoteReady = FALSE;

			cmd = RemoteParse(&g_UartRemoteHandle);
            if (0 != cmd)
			{
				main_HostCmdExe(cmd);
			}
		}

		// Handle motor tick
		if (FALSE != g_bMotorTickReady)
        {
            g_bMotorTickReady = FALSE;
            MotorOnTimer(); // shall maintain at 50ms as required by ubiquity MCB
        }
		
		// Handle UART motor control board
		if (0 != g_abUartMCBReady)
        {
            g_abUartMCBReady = FALSE;
            SerialRxEmpty(&g_UartMCBHandle); // Ignore incoming Uart bytes from MCB. Not in use.
        }

		// Handle ultrasonic sensor tick
		if (FALSE != g_bUSonicTickReady)
		{
			g_bUSonicTickReady = FALSE;

			if (FALSE != g_USonicStatus.b.bUSonic0)
			{
				g_USonicStatus.b.bUSonic0 = FALSE;
				
				if (FALSE != g_USonicStatus.b.bError0)
				{
					g_USonicStatus.b.bError0 = FALSE;
					TRACE("US0: Err: Sensor fault ");
					// Set error flag
					USonicError = TRUE;
				}
				else
				{
					USonicError = FALSE;
					dist = USonicRead(&g_USHandles[0]);
					TRACE("US0: %d cm ", dist / 100);
					USonicDist = dist / 100;
					if (mode == TRUE) {
						if (USonicDist < 40 && obstacleDetected == FALSE) {// Check if the distance is less than 30cm previously no obstacle detected
							AutoDir = FALSE;// Set the direction to reverse
							obstacleDetected = TRUE;// Set the obstacle detected flag
							Obstacle++;// Increment the obstacle counter
							MotorsStop();// Stop the motors
							g_bStop = false;// Disengage the brake flag
						}
						else if (USonicDist1 >= 40 && USonicDist >= 40) {
							obstacleDetected = FALSE; // Reset the flag when the obstacle is no longer detected
							}	
					}
				}

				USonicTrigger(&g_USHandles[1]);
			}

			if (FALSE != g_USonicStatus.b.bUSonic1)
			{
				g_USonicStatus.b.bUSonic1 = FALSE;
				
				if (FALSE != g_USonicStatus.b.bError1)
				{
					g_USonicStatus.b.bError1 = FALSE;
					TRACE("US1: Err: Sensor fault\r\n ");
					// Set error flag
					USonicError1 = TRUE;
					
				}
				else
				{
					USonicError1 = FALSE;
					dist = USonicRead(&g_USHandles[1]);
					TRACE("US1: %d cm\r\n", dist / 100);
					USonicDist1 = dist / 100;
					if (mode == TRUE) {
						if (USonicDist1 < 31 && obstacleDetected == FALSE) {// Check if the distance is less than 30cm previously no obstacle detected
							AutoDir = TRUE;// Set the direction to forward
							obstacleDetected = TRUE;// Set the obstacle detected flag
							MotorsStop();//` Stop the motors
							g_bStop= false;// Disengage the brake flag
						}
						else if (USonicDist1 >= 31 && USonicDist >= 31) {
							obstacleDetected = FALSE; // Reset the flag when the obstacle is no longer detected
						}
					}
				}
				
				USonicTrigger(&g_USHandles[0]);
			}
		}
     }
}


/*****************************************************************************
 Callback functions
******************************************************************************/


static void main_cbUartRemoteOnRx( void )
{
    if (mode == FALSE) // Only set the flag if not in autonomous mode
    {
        g_abUartRemoteReady = TRUE;
    }
}
static void main_cbMCBOnRx( void )
{
   g_abUartMCBReady  = TRUE;
}
static void main_cbUS0OnTrigger( BOOL bON )
{
  US0_TRIG_SET( bON );
}

static void main_cbUS1OnTrigger( BOOL bON )
{
  US1_TRIG_SET( bON );
}
static void main_cbUS0OnReady( int Error )
{
	if( USONIC_SUCCESS != Error )
	{
		g_USonicStatus.b.bError0 = TRUE;
	}
	else
	{
		g_USonicStatus.b.bError0 = FALSE;
	}
	g_USonicStatus.b.bUSonic0 = TRUE;
	main_AutoMotorControl();// Call the motor control function
}

static void main_cbUS1OnReady( int Error )
{
	if( USONIC_SUCCESS != Error )
	{
		g_USonicStatus.b.bError1 = TRUE;
	}
	else
	{
		g_USonicStatus.b.bError1 = FALSE;
	}
	
	g_USonicStatus.b.bUSonic1 = TRUE;//this is a flag to indicate that the ultrasonic sensor 1 is ready
	main_AutoMotorControl();// Call the motor control function
}

void main_AutoMotorControl(void)
{
    if (mode == TRUE) // Autonomous mode
    {
        if (Obstacle < 4) {
           switch (AutoDir) {
				case TRUE:
					MotorsMoveFront();
					strncpy((char *)motor_direction, "F", sizeof(motor_direction));
					break;
				case FALSE:
					MotorsMoveBack();
					strncpy((char *)motor_direction, "B", sizeof(motor_direction));
					break;
				default:
					MotorsStop();
					strncpy((char *)motor_direction, "S", sizeof(motor_direction));
					g_bstop = FALSE; // disengage the stop flag
					break;
			}
        } else 
		{
            MotorsStop();
            strncpy((char *)motor_direction, "S", sizeof(motor_direction));
            g_bstop = FALSE; // disengage the stop flag
            mode = FALSE; // switch to manual mode
            Obstacle = 0; // Reset obstacle counter when switching to manual mode
			SerialRxEmpty(&g_UartRemoteHandle);
			SerialRxEmpty(&g_UartMCBHandle);
        }
        
        motor_direction[sizeof(motor_direction) - 1] = '\0'; // Ensure null-termination
    }
}



/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void )
{
	SpimInit(
        &g_SpimHandle,
        2,
        15000000U, 
        SPI_CLK_INACT_LOW,
        SPI_CLK_RISING_EDGE,
        SPI_DATA_SIZE_8 );
}

static void motor_UartInit( void )
{
    int res = SerialInit( &g_UartMCBHandle, 1, 38400 );
    ASSERT( res == UART_STS_OK );
	(res == UART_STS_OK)?(motor_status = TRUE):(motor_status = FALSE);

    SerialConfig(
    	&g_UartMCBHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartMCBHandle, 
    	g_aUartMCBTxBuf,
    	sizeof(g_aUartMCBTxBuf),
    	g_aUartMCBRxBuf,
    	sizeof(g_aUartMCBRxBuf) );

   SerialAddCallback( &g_UartMCBHandle, 0, main_cbMCBOnRx );
}

static void remote_UartInit( void )
{
	int res;// Remote controller from esp32
    res = SerialInit( &g_UartRemoteHandle, 5, 921600 );
    ASSERT( res == UART_STS_OK );
	(res == UART_STS_OK)?(remote_status = TRUE):(remote_status = FALSE);

    SerialConfig(
    	&g_UartRemoteHandle, 
    	UART_BITS_8, 
    	UART_NONE,
    	UART_ONE );

   SerialBuffer(
    	&g_UartRemoteHandle, 
    	g_aUartRemoteTxBuf,
    	sizeof(g_aUartRemoteTxBuf),
    	g_aUartRemoteRxBuf,
    	sizeof(g_aUartRemoteTxBuf) );

   SerialAddCallback( &g_UartRemoteHandle, 0, main_cbUartRemoteOnRx );
}

static void main_HostCmdExe(char *pCmd)
{	if (mode == TRUE) 
    {
        // If in autonomous mode, ignore remote commands
		SerialRxEmpty(&g_UartRemoteHandle);//This function is used to empty the receive buffer of the UART so that the buffer does not overflow
        return;
    }
	else
	{
		HOST_REQ_PKT *req = (HOST_REQ_PKT *)pCmd;// Cast to HOST_REQ_PKT and assign to req

			switch (req->Cmd.Cmd)//req points to the command
			{
				case CMD_HOST_STOP:
					MotorsStop();
					strncpy((char *)motor_direction, "S", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: STOP\r\n");
					break;

				case CMD_HOST_MOVE_FWD:
					MotorsMoveFront();
					strncpy((char *)motor_direction, "F", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: FWD\r\n");
					break;

				case CMD_HOST_MOVE_BWD:
					MotorsMoveBack();
					strncpy((char *)motor_direction, "B", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: BWD\r\n");
					break;

				case CMD_HOST_ROTATE_LEFT:
					MotorsRotateLeft();
					strncpy((char *)motor_direction, "L", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: ROTATE LEFT\r\n");
					break;

				case CMD_HOST_ROTATE_RIGHT:
					MotorsRotateRight();
					strncpy((char *)motor_direction, "R", sizeof(motor_direction));
					motor_direction[sizeof(motor_direction) - 1] = '\0';  // Ensure null-termination
					TRACE("cmd: ROTATE RIGHT\r\n");
					break;

				default:
					TRACE("cmd: Invalid\r\n");
					break;
			}
		}		
    }


static void main_UltraSoundInit( void )
{
  /* Ultrasonic initialization */
  USonicInit( &g_Timer1Handle, 10000 );
  
  /* Add a callback to get notify when ultrasonic sensor is ready to be read */
  UsonicAddDevice( &g_USHandles[0], 0U, main_cbUS0OnTrigger, main_cbUS0OnReady );
  UsonicAddDevice( &g_USHandles[1], 1U, main_cbUS1OnTrigger, main_cbUS1OnReady );
}


/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler( void )
{
	/* NOTE:
	It is more efficient to compare to 0 for Cortex M
	*/

	g_nCount++;
	if (g_nCount == 1000)
	{
		//g_bSecTick = TRUE;
		g_nCount=0;
		
		/* Keep track of time based on 1 sec interval */ 
		g_nTimeSec++;
		if(g_nTimeSec > 24*60*60)
		{
			g_nTimeSec = 0;
		}
	}

	if( 0 != g_nSysTick ) // g_nSysTick counts down from SYS_TICK_MS
	{
		g_nSysTick--;
		if( 0 == g_nSysTick )
		{
			g_nSysTick = SYS_TICK_MS;
			g_bSysTickReady = TRUE;
		}
	}

	if( 0 != g_nLCDTick )
	{
		g_nLCDTick--;
		if( 0 == g_nLCDTick )
		{
			g_nLCDTick = LCD_UPDATE_MS;
			g_nLCDTickReady = TRUE;		}
	}
	
	if( 0 != g_nMotorTick )
    {
        g_nMotorTick--;

        if( 0 == g_nMotorTick )
        {
            g_nMotorTick = MOTOR_TICK_MS;
            g_bMotorTickReady = TRUE;
		}
	}
		if( 0 != g_nUSonicTick )
    {
        g_nUSonicTick--;

        if( 0 == g_nUSonicTick )
        {
            g_nUSonicTick = USONIC_TICK_MS;
            g_bUSonicTickReady = TRUE;
        }
    }
}
void EXTI2_US0_ECHO_IRQHandler( uint32_t Status )
{
	UsonicISR( &g_USHandles[0], IN_US0_ECHO() );// Ultrasonic sensor 0 echo interrupt,syntax is 
}

void EXTI5_US1_ECHO_IRQHandler( uint32_t Status )
{
	UsonicISR( &g_USHandles[1], IN_US1_ECHO() );// Ultrasonic sensor 1 echo interrupt, takes in the ultrasonic sensor handle and the echo status
}
void EXTI13_BTN_IRQHandler(uint32_t irqStatus)
{
    if ((EXTI->PR1 & EXTI_PR1_PIF13) != 0)  // Check if EXTI line 13 caused the interrupt
    {
	    // Handle button press here
        if (BTN_READ())
        {
			mode = !mode;//toggle mode
			TRACE("Button pressed\n\r");
			Obstacle = 0;// Reset obstacle counter when switching to manual mode
			obstacleDetected = FALSE;// Reset the obstacle detected flag when switching to manual mode
			g_bStop = FALSE;// Disengage the stop flag when switching to manual mode, stopp
			SerialRxEmpty(&g_UartRemoteHandle);
			SerialRxEmpty(&g_UartMCBHandle);
			if (mode == TRUE)//if in autonomous mode.
			{
				AutoDir = TRUE;
				MotorsMoveFront();
			}	
        }
    }
}
