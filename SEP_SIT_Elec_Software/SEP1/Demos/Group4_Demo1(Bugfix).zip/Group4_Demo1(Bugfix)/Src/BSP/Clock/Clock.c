/*****************************************************************************
 @Project	: 
 @File 		: Clock.c
 @Details  	: All Ports and peripherals configuration                    
 @Author	: 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  lcgan     2021-10-26  		Initial Release
   
******************************************************************************/
#include <Common.h>
#include "Clock.h"


/*****************************************************************************
 Define
******************************************************************************/
#define PWR_REGULATOR_VOLTAGE_SCALE1_BOOST  ((uint32_t)0x00000000)
#define PWR_REGULATOR_VOLTAGE_SCALE1        PWR_CR1_VOS_0           /*!< Voltage scaling range 1 normal mode */
#define PWR_REGULATOR_VOLTAGE_SCALE2        PWR_CR1_VOS_1           /*!< Voltage scaling range 2             */
#define PWR_FLAG_SETTING_DELAY_US           50UL                    /*!< Time out value for REGLPF and VOSF flags setting */

/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
static BOOL PWRControlVoltageScaling( uint32_t VoltageScaling );


/*****************************************************************************
 Implementation
******************************************************************************/
void
ClockInit(
	uint32_t nPllm,
	uint32_t nPlln,
	uint32_t nPllp,
	uint32_t nPllq,
    uint32_t nPllr,
    uint32_t nLatency
	)
{
	int32_t tmp;

    PWRControlVoltageScaling( PWR_REGULATOR_VOLTAGE_SCALE1_BOOST );

	/* HSE ON */
	RCC->CR = RCC_CR_HSEON;
	while( 0 == (RCC->CR&RCC_CR_HSERDY) ){}
	
	RCC->CR &= ~RCC_CR_PLLON;
	while( 0 != (RCC->CR&RCC_CR_PLLRDY) ){}
	
	
	tmp = RCC->PLLCFGR;
    tmp &= ~(RCC_PLLCFGR_PLLSRC 
            | RCC_PLLCFGR_PLLM 
            | RCC_PLLCFGR_PLLN 
            | RCC_PLLCFGR_PLLQ 
            | RCC_PLLCFGR_PLLR 
            | RCC_PLLCFGR_PLLPDIV 
            | RCC_PLLCFGR_PLLSRC);

	tmp |= RCC_PLLCFGR_PLLSRC_HSE 
		| ((nPllm-1U)<<RCC_PLLCFGR_PLLM_Pos) 
		| (nPlln<<RCC_PLLCFGR_PLLN_Pos)
		| ((nPllp-1)<<RCC_PLLCFGR_PLLP_Pos)
		| (((nPllq>>1U)-1U)<<RCC_PLLCFGR_PLLQ_Pos)
        | (((nPllr>>1U)-1U)<<RCC_PLLCFGR_PLLR_Pos);
	RCC->PLLCFGR = tmp;
	
	RCC->CR |= RCC_CR_PLLON;
	while( 0 == (RCC->CR&RCC_CR_PLLRDY) ){}

	/* Enable PLL System Clock output. */
	RCC->PLLCFGR |= RCC_PLLCFGR_PLLREN;

    tmp = FLASH->ACR;
    tmp &= ~FLASH_ACR_LATENCY;
    tmp |= nLatency;
    FLASH->ACR = tmp;

    while( 0 == (RCC->CR&RCC_CR_PLLRDY) ){}

	
	RCC->CFGR |= RCC_CFGR_SW_PLL;
	while( 0 == (RCC->CFGR&RCC_CFGR_SWS_PLL) ){}
}


static BOOL PWRControlVoltageScaling( uint32_t VoltageScaling )
{
    uint32_t wait_loop_index;
    uint32_t tmp;

    if (VoltageScaling == PWR_REGULATOR_VOLTAGE_SCALE1_BOOST)
    {
        /* If current range is range 2 */
        if( (PWR->CR1&PWR_CR1_VOS) == PWR_REGULATOR_VOLTAGE_SCALE2)
        {
            /* Make sure Range 1 Boost is enabled */
            PWR->CR5 &= ~PWR_CR5_R1MODE;

            /* Set Range 1 */
            tmp = PWR->CR1;
            tmp &= ~PWR_CR1_VOS;
            tmp |= PWR_REGULATOR_VOLTAGE_SCALE1;
            PWR->CR1 = tmp;

            /* Wait until VOSF is cleared */
            wait_loop_index = ((PWR_FLAG_SETTING_DELAY_US * SystemCoreClock) / 1000000U) + 1U;
            while(1)
            {
                if(0U != wait_loop_index)
                {
                    wait_loop_index--;
                    if(0 == wait_loop_index)
                    {
                        break;
                    }
                }

                if(0 == (PWR->SR2&PWR_SR2_VOSF))
                {
                    break;
                }
            }

            if(0 != (PWR->SR2&PWR_SR2_VOSF))
            {
                return FALSE;
            }

        }
        /* If current range is range 1 normal or boost mode */
        else
        {
            /* Enable Range 1 Boost (no issue if bit already reset) */
            PWR->CR5 &= ~PWR_CR5_R1MODE;
        }
    }
    else if (VoltageScaling == PWR_REGULATOR_VOLTAGE_SCALE1)
    {
        /* If current range is range 2 */
        if((PWR->CR1&PWR_CR1_VOS) == PWR_REGULATOR_VOLTAGE_SCALE2)
        {
            /* Make sure Range 1 Boost is disabled */
            PWR->CR5 |= PWR_CR5_R1MODE;

            /* Set Range 1 */
            tmp = PWR->CR1;
            tmp &= ~PWR_CR1_VOS;
            tmp |= PWR_REGULATOR_VOLTAGE_SCALE1;
            PWR->CR1 = tmp;

            /* Wait until VOSF is cleared */
            wait_loop_index = ((PWR_FLAG_SETTING_DELAY_US * SystemCoreClock) / 1000000U) + 1U;
            while(1)
            {
                if(0U != wait_loop_index)
                {
                    wait_loop_index--;
                    if(0 == wait_loop_index)
                    {
                        break;
                    }
                }

                if(0 == (PWR->SR2&PWR_SR2_VOSF))
                {
                    break;
                }
            }

            if(0 != (PWR->SR2&PWR_SR2_VOSF))
            {
                return FALSE;
            }
        }
        /* If current range is range 1 normal or boost mode */
        else
        {
            /* Disable Range 1 Boost (no issue if bit already set) */
            PWR->CR5 |= PWR_CR5_R1MODE;
        }
    }
    else
    {
        /* Set Range 2 */
        tmp = PWR->CR1;
        tmp &= ~PWR_CR1_VOS;
        tmp |= PWR_REGULATOR_VOLTAGE_SCALE2;
        PWR->CR1 = tmp;

        /* No need to wait for VOSF to be cleared for this transition */
        /* PWR_CR5_R1MODE bit setting has no effect in Range 2        */
    }

    return TRUE;
}



















