/***************************************************************************************
 @Project		: MET2001 Lab P3 Template
 @File 			: main.c
 @Details  	: Main entry
 @Author		: fongfh
 @Hardware	: STM32
 
 ---------------------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 ---------------------------------------------------------------------------------------
   1.0  fongfh     12-Feb-2023  	Initial Release - STM32G474RE
																	Debug interface - STLink
																	Support TFT LCD ST7735
																	Virtual COM Port @LPUART (PA2-TX, PA3-RX)`
																	 - 921,600,8,no parity,1 Stop
	2.0 	fongfh		 17 May 2023		Add Event Recorder codes
																	Add option for ITM redirection to Debug printf Viewer
																	
*****************************************************************************************/
#include <Common.h>
#include "Hal.h"
#include "BSP.h"
#include "Timer.h"

#include "spim.h"
#include "LCD.h"
#include "gui.h"
#include "IRQ.h"

#include "LPUART.h"
#include "EventRecorder.h"

#include <stdio.h>
#include <stdbool.h>

/*****************************************************************************
 Define
************************"******************************************************/
#define SYS_TICK_MS 			500 	/* Software Timer with 500 ms */
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10

//defined in Hal.h
//#define BTN_READ()					(GPIOC->IDR & BIT(PC_BTN))
/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Const Local Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
/* SysTick declarations  */
static volatile int     g_nSysTick = SYS_TICK_MS;
static volatile BOOL    g_bSysTickReady = FALSE;
static volatile BOOL    g_bToggle = FALSE;

/* TFT LCD declarations   */
static SPIM_HANDLE			g_SpimHandle;
static GUI_DATA					g_aBuf[LCD_BUF_SIZE];
static GUI_MEMDEV				g_MemDev;
volatile BOOL 					g_bLcdFree  = TRUE;

static volatile int     g_nLCDTick = LCD_UPDATE_MS;
static volatile BOOL    g_nLCDTickReady = FALSE;

/* Timer 1 declarations 		*/
static TIMER_HANDLE g_Timer1Handle;   		/* TIM1 handle   */
static TIMER_HOOK   g_Timer1Hook1;    		/* TIM1 hook     */
static volatile BOOL g_bcallback1 = FALSE; 
static void main_cbTimer1A( void );  /* prototype declaration for call-back function */

/* LPUART declarations  */
static LPUART_HANDLE		g_LPUartHandle;

/* General prgoram declarations  */
static uint32_t         g_nCount = 0;
static uint32_t					g_nTimeSec = 0;
//uint32_t	i,a,b;

/* Button declarations */
volatile BOOL mode = FALSE;

//BTN_READ() is defined in Hal.h It reads the button state

/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void );
static void main_LcdInit( void );

/*****************************************************************************
 Callback functions
******************************************************************************/
static void main_cbGuiFrameEnd( void );
static void main_cbLcdTransferDone( void );

static void main_cbTimer1 ( void ); /* function prototypes */

/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler( void );
void EXTI13_BTN_IRQHandler( uint32_t irqStatus);

/*****************************************************************************
 Implementation 
******************************************************************************/
int main( void )
{
   
	EventRecorderInitialize (EventRecordAll,1); // initialize & start Event Recorder
	BSPInit( );

	/* Generate interrupt each 1 ms as system tick */
	SysTick_Config( SystemCoreClock / 1000 );
	
	/* init TIM1 to 10Hz; pass handle to called fn */
   TimerInit (&g_Timer1Handle,1,10); 	// timer initialization, 10 Hz
   TimerAddHook( 
     &g_Timer1Handle, 	/* TIM1 handle   */
     &g_Timer1Hook1,  	/* TIM1 hook 1   */
     main_cbTimer1   	/* pointer to call-back function  */
   );   
	TimerStart( &g_Timer1Handle ); // start the timer
	
	// Initialize LPUART1
	g_LPUartHandle.baud = 921600;
	g_LPUartHandle.databits = DATABITS8;
	g_LPUartHandle.stop = STOP1;
	g_LPUartHandle.parity = PARITY_NONE;
	LPUART1_Init (&g_LPUartHandle);

	main_SpimInit(); // SPI bus initialization
	main_LcdInit();  // LCD initialization
	IRQInit();			// initialize ISRs; function in IRQ.c 

	printf ("MET2001 SU24 ...\r\n");
	
	/* Runtime for loop */
	for(;;)
	{
		if( FALSE != g_bSysTickReady )
		{
				g_bSysTickReady = FALSE;

				printf("main: bToggle=%i\n\r", g_bToggle);
				EventRecord2 (0x0500,0,0);
				LED_LD2_SET(g_bToggle);
				g_bToggle = !g_bToggle;
		}
		
		if( FALSE != g_bcallback1 ) // set by timer callback fn
		{
				g_bcallback1 = FALSE;

				LED_LD2_SET(g_bToggle);
				g_bToggle = !g_bToggle;
		}
		
		if( FALSE != g_nLCDTickReady )
		{
			if( 0 != g_bLcdFree )
			{
				g_nLCDTickReady = FALSE;
				g_bLcdFree = FALSE;
				GUI_Draw_Exe(); // update LCD screen
			}
		}
	}
}

/*****************************************************************************
 Callback functions
******************************************************************************/
void GUI_AppDraw( BOOL bFrameStart )
{
	/* This function invokes from GUI library */
	static char buf0[25],buf1[25],buf2[25];

	if( TRUE == bFrameStart ) // framestart = TRUE indicate the display dynamic area can be updated.
	{
    /* choose one to display - count or time elapsed */	
		sprintf( buf0, "%02u:%02u:%02u", (g_nTimeSec/3600)%24, (g_nTimeSec/60)%60, g_nTimeSec%60 );
		sprintf (buf1, "CPU Clock: %d MHz", SystemCoreClock/1000000);
		sprintf( buf2, "g_nCount: %08X", g_nCount);
	}
		
	/* Set background to blue. Refer to gui.h for color code */
	GUI_Clear( ClrBlue ); 
	
	GUI_SetColor( ClrYellow );
	GUI_DrawRect(0,110,159,127); // (col,row.col,row)
	GUI_DrawLine (0,66,159,66);
	GUI_DrawLine (0,69,159,69);
	
	GUI_SetFont( &g_sFontCalibri24 );
	GUI_PrintString( "MET2001 SU24", ClrMagenta, 5, 1);
	GUI_PrintString( "KEIL V5.36.0.0", ClrWhite, 5, 21 );
	GUI_PrintString( "STM32G474RE", ClrLightBlue, 5, 41 );
	GUI_SetFont( &FONT_Arialbold16 );
	GUI_PrintString( buf0, ClrGreenYellow, 45, 112 ); // time
	//Print button status
	if (mode == 1)
	{
		GUI_PrintString( "Mode 1", ClrYellowGreen,5,90 );
	}
	else
	{
		GUI_PrintString( "Mode 2", ClrYellowGreen,5,90 );
	}
	//GUI_PrintString( buf1, ClrYellowGreen,5,90 ); // CPU clock
	GUI_SetFont( &FONT_Arialbold12 );
	GUI_PrintString( buf2, ClrYellowGreen,5,75 ); // g_nCount
}

static void main_cbLcdTransferDone( void )
{
	g_bLcdFree = TRUE;
}

static void main_cbGuiFrameEnd( void )
{
	g_bLcdFree = TRUE;
}

/* Call-back function:                            */
/*   executes at freq defined by TimerInit() */
static void main_cbTimer1( void )
{ 
   g_bcallback1 = TRUE;
   /* add program codes, if needed */ 
}


/*****************************************************************************
 Local functions
******************************************************************************/
static void main_SpimInit( void )
{
	SpimInit(
        &g_SpimHandle,
        2,
        15000000U, 
        SPI_CLK_INACT_LOW,
        SPI_CLK_RISING_EDGE,
        SPI_DATA_SIZE_8 );
}

static void main_LcdInit( void )
{
	int screenx;
	int screeny;
	
	/* g_SpimHandle shall be initialized before use */
	
	/* Choosing a landscape orientation */
	LcdInit( &g_SpimHandle, LCD_LANDSCAPE );
	
	/* Get physical LCD size in pixels */
	LCD_GetSize( &screenx, &screeny );
	
	/* Initialize GUI */
	GUI_Init(
		&g_MemDev,
		screenx,
		screeny,
		g_aBuf,
		sizeof(g_aBuf) );
	
	/* Switch to transfer word for faster performance */
	SpimSetDataSize( &g_SpimHandle, SPI_DATA_SIZE_16 );
	GUI_16BitPerPixel( TRUE );
	
	/* Clear LCD screen to Blue */
	GUI_Clear( ClrBlue );

    /* set font color background */
    GUI_SetFontBackColor( ClrBlue );
    
    /* Set font */
    GUI_SetFont( &g_sFontCalibri10 );
	
	LCD_AddCallback( main_cbLcdTransferDone );
	
	GUI_AddCbFrameEnd( main_cbGuiFrameEnd );
	
	/* Backlight ON */
	LCD_BL_ON();
}

/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler( void )
{
	g_nCount++;
	if (g_nCount == 1000)
	{
		//g_bSecTick = TRUE;
		g_nCount=0;
		
		/* Keep track of time based on 1 sec interval */ 
		g_nTimeSec++;
		if(g_nTimeSec > 24*60*60)
		{
			g_nTimeSec = 0;
		}
	}

	if( 0 != g_nSysTick ) // g_nSysTick counts down from SYS_TICK_MS
	{
			g_nSysTick--;
			if( 0 == g_nSysTick )
			{
				g_nSysTick = SYS_TICK_MS;
				g_bSysTickReady = TRUE;
			}
	}
	
	if( 0 != g_nLCDTick )
	{
		g_nLCDTick--;
		if( 0 == g_nLCDTick )
		{
			g_nLCDTick = LCD_UPDATE_MS;
			g_nLCDTickReady = TRUE;
		}
	}
}
void EXTI13_BTN_IRQHandler(uint32_t irqStatus)
{
    if ((EXTI->PR1 & EXTI_PR1_PIF13) != 0)  // Check if EXTI line 13 caused the interrupt
    {
		//This can also be in irq.c
        EXTI->PR1 = EXTI_PR1_PIF13;  // Clear the pending interrupt flag for EXTI line 13
        
        // Handle button press here
        if (BTN_READ())
        {
			mode = !mode;
			TRACE("Button pressed\n\r");
        }
    }
}
