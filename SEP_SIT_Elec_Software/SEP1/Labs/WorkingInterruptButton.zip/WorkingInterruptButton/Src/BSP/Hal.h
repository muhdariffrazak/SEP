/*****************************************************************************
 @Project	  : 
 @File 		  : 
 @Details  	: All Ports and peripherals configuration                    
 @Author	  : 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     XXXX-XX-XX  		Initial Release
   
******************************************************************************/

#ifndef __HAL_DOT_H__
#define __HAL_DOT_H__

#include "stdint.h"
#include "stdbool.h"

/*****************************************************************************
 Define
******************************************************************************/
#define GPIO_MODE_INPUT 	0x00U
#define GPIO_MODE_OUTPUT 	0x01U
#define GPIO_MODE_AF		0x02U
#define GPIO_MODE_ANALOGUE	0x03U

#define GPIO_PULL_DIS		0x00U
#define GPIO_PULL_UP		0x01U
#define GPIO_PULL_DWN		0x02U

#define GPIO_SPEED_MIN		0x00U
#define GPIO_SPEED_MEDIUM	0x01U
#define GPIO_SPEED_HIGH 	0x02U
#define GPIO_SPEED_MAX 		0x03U

#define GPIO_PWM_AF1		0x01U
#define GPIO_PWM_AF2		0x02U
#define GPIO_I2C1_AF4		0x04U
#define GPIO_SPI1_AF5		0x05U
#define GPIO_SPI2_AF5		0x05U
#define GPIO_SPI3_AF6       0x06U
#define GPIO_USART2_AF7			0x07U
#define GPIO_UART7_AF8			0x08U
#define GPIO_LPUART_AF12		12

/*****************************************************************************
 Define - Pins
******************************************************************************/
#define PA_LD2_GREEN			5U // user LED on Nucleo

#define PC_LCD_RESET			0U
#define PC_LCD_DC					4U
#define PC_LCD_BL					3U

#define PB_LCD_SPI2_CS		12U
#define PB_LCD_SPI2_CLK		13U
#define PB_LCD_SPI2_MISO	14U
#define PB_LCD_SPI2_MOSI	15U

#define PC_BTN						13U // user button on Nucleo at PC13


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Macro
******************************************************************************/
#define BIT( x )					(1U<<(x))

/* LEDs */
#define LED_LD2_ON()				(GPIOA->BSRR = BIT(PA_LD2_GREEN))
#define LED_LD2_OFF()				(GPIOA->BSRR = (BIT(PA_LD2_GREEN)<<16U))
#define LED_LD2_SET( x )    ((x)? LED_LD2_ON() : LED_LD2_OFF())

/* LCD */
#define LCD_RESET_LOW()				(GPIOC->BSRR = (BIT(PC_LCD_RESET)<<16U))
#define LCD_RESET_HIGH()			(GPIOC->BSRR = BIT(PC_LCD_RESET))
#define LCD_RESET_SET( x )		((x)? LCD_RESET_HIGH() : LCD_RESET_LOW())

#define LCD_DC_HIGH()				(GPIOC->BSRR = BIT(PC_LCD_DC))
#define LCD_DC_LOW()				(GPIOC->BSRR = (BIT(PC_LCD_DC)<<16U))
#define LCD_DC_SET( x )			((x)? LCD_DC_HIGH() : LCD_DC_LOW())

#define LCD_BL_ON()					(GPIOC->BSRR = BIT(PC_LCD_BL))
#define LCD_BL_OFF()				(GPIOC->BSRR = (BIT(PC_LCD_BL)<<16U))
#define LCD_BL_SET( x )			((x)? LCD_BL_ON() : LCD_BL_OFF())

#define LCD_CS_LOW()				(GPIOB->BSRR = (BIT(PB_LCD_SPI2_CS)<<16U))
#define LCD_CS_HIGH()       (GPIOB->BSRR = BIT(PB_LCD_SPI2_CS))

/* Button */
#define BTN_READ()					((GPIOC->IDR & BIT(PC_BTN)) ? true : false)//this is a macro to read the button state

/******************************************************************************
 Global functions
******************************************************************************/

/******************************************************************************
 @Description 	: 

 @param			: 
 
 @revision		: 1.0.0
 
******************************************************************************/
void PortInit( void );



#endif /* __HAL_DOT_H__ */









