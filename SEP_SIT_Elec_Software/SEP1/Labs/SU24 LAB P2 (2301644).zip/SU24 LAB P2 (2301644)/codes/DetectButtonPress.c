#include <Common.h>
#include "Hal.h"
#include "BSP.h"
#include "Timer.h"

#include "LPUART.h"
#include "EventRecorder.h"
#include <stdio.h>
#include "stdbool.h"

/*****************************************************************************
 Define
******************************************************************************/
#define SYS_TICK_MS 1

// Button press duration threshold for long press detection
#define LONG_PRESS_THRESHOLD_MS 500

/*****************************************************************************
 Global Variables
******************************************************************************/
static volatile int g_nSysTick = SYS_TICK_MS;
static volatile BOOL g_bSysTickReady = FALSE;

static LPUART_HANDLE g_LPUartHandle;

static BOOL g_bButtonState = FALSE; // Button state
static BOOL g_bButtonPressed = FALSE; // Flag to indicate button press
static uint32_t g_nButtonPressStartTime = 0; // Time when button press started

static uint32_t g_nCount = 0; // Counter to track time

/*****************************************************************************
 Local functions
******************************************************************************/
// Function to handle button press detection
void HandleButtonPress(void)
{
    if (g_bButtonState) // Button is pressed
    {
        if (!g_bButtonPressed) // Button was not pressed previously
        {
            g_bButtonPressed = TRUE; // Set button press flag
            g_nButtonPressStartTime = g_nCount; // Record press start time
        }
    }
    else // Button is released
    {
        if (g_bButtonPressed) // Button was pressed previously
        {
            g_bButtonPressed = FALSE; // Clear button press flag
            uint32_t pressDuration = g_nCount - g_nButtonPressStartTime; // Calculate press duration

            if (pressDuration < LONG_PRESS_THRESHOLD_MS) // Short press
            {
                printf("Short press detected.\n\r");
                // Perform actions for short press
            }
            else // Long press
            {
                printf("Long press detected.\n\r");
                // Perform actions for long press
            }
        }
    }
}

/*****************************************************************************
 Implementation 
******************************************************************************/
int main(void)
{
    EventRecorderInitialize(EventRecordAll, 1);
    BSPInit();
    SysTick_Config(SystemCoreClock / 1000);

    g_LPUartHandle.baud = 921600;
    g_LPUartHandle.databits = DATABITS8;
    g_LPUartHandle.stop = STOP1;
    g_LPUartHandle.parity = PARITY_NONE;
    LPUART1_Init(&g_LPUartHandle);

    printf("MET2001 SU24 ...\r\n");
    EventRecord2(0x0500, 0, 0);

    for (;;)
    {
        if (FALSE != g_bSysTickReady)
        {
            g_bSysTickReady = FALSE;

            // Increment counter to track time
            g_nCount += SYS_TICK_MS;

            // Poll button status
            g_bButtonState = IN_BTN(); // Assuming IN_BTN() is a function to read button status

            HandleButtonPress();
        }
    }
}

/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler(void)
{
    g_bSysTickReady = TRUE;
}
