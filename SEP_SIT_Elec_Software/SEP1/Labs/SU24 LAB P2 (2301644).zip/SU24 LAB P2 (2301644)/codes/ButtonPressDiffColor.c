#include <Common.h>
#include "Hal.h"
#include "BSP.h"
#include "Timer.h"

#include "LPUART.h"
#include "EventRecorder.h"
#include <stdio.h>
#include "stdbool.h"

/*****************************************************************************
 Define
******************************************************************************/
#define SYS_TICK_MS 1
#define PWM_WINDOW_MS 10 // Define the PWM window duration in milliseconds

// Button press duration threshold for long press detection
#define LONG_PRESS_THRESHOLD_MS 500

/*****************************************************************************
 Global Variables
******************************************************************************/
static volatile int g_nSysTick = SYS_TICK_MS;// System tick counter
static volatile BOOL g_bSysTickReady = FALSE;// SysTick flag

static LPUART_HANDLE g_LPUartHandle;// LPUART handle

static BOOL g_bButtonState = FALSE; // Button state
static BOOL g_bButtonPressed = FALSE; // Flag to indicate button press
static uint32_t g_nButtonPressStartTime = 0; // Time when button press started

static uint32_t g_nCount = 0; // Counter to track time

// PWM duty cycle for each LED color
static uint8_t RedDuration = 0;
static uint8_t GreenDuration = 0;
static uint8_t BlueDuration = 0;

/*****************************************************************************
 Local functions
******************************************************************************/
//function declarations for colors
void SetMagenta(void);
void SetYellow(void);
void SetCyan(void);
void SetWhite(void);
void UpdateLEDs(void);
void HandleButtonPress(void);
/*****************************************************************************
 Callback functions
******************************************************************************/

/*****************************************************************************
 Implementation 
******************************************************************************/
int main(void)
{
    EventRecorderInitialize(EventRecordAll, 1);
    BSPInit();
    SysTick_Config(SystemCoreClock / 1000);

    g_LPUartHandle.baud = 921600;
    g_LPUartHandle.databits = DATABITS8;
    g_LPUartHandle.stop = STOP1;
    g_LPUartHandle.parity = PARITY_NONE;
    LPUART1_Init(&g_LPUartHandle);

    printf("MET2001 SU24 ...\r\n");
    EventRecord2(0x0500, 0, 0);

    for (;;)
    {
        if (FALSE != g_bSysTickReady)
        {
            g_bSysTickReady = FALSE;

            // Increment counter to track time
            g_nCount += SYS_TICK_MS;

            // Check if we are within the PWM window
            if (g_nCount % PWM_WINDOW_MS == 0)
            {
                // Poll button status
                g_bButtonState = IN_BTN(); // Assuming IN_BTN() is a function to read button status

                HandleButtonPress();
                UpdateLEDs(); // Update LEDs based on PWM duty cycle
            }
        }
    }
}
/*****************************************************************************
 Local functions
******************************************************************************/
void HandleButtonPress(void)
{
    if (g_bButtonState) // Button is pressed
    {
        if (!g_bButtonPressed) // Button was not pressed previously
        {
            g_bButtonPressed = TRUE; // Set button press flag
            g_nButtonPressStartTime = g_nCount; // Record press start time
        }
    }
    else // Button is released
    {
        if (g_bButtonPressed) // Button was pressed previously
        {
            g_bButtonPressed = FALSE; // Clear button press flag
            uint32_t pressDuration = g_nCount - g_nButtonPressStartTime; // Calculate press duration

            if (pressDuration < LONG_PRESS_THRESHOLD_MS) // Short press
            {
                printf("Short press detected.\n\r");

                SetMagenta();
                SetYellow();
                SetCyan();
                SetWhite();
            }
            else // Long press
            {
                printf("Long press detected.\n\r");
                // Perform actions for long press
            }
        }
    }
}

//Functions for colors
void SetMagenta(void)
{
    RedDuration = 40; // Example: Red LED at 40% duty cycle
    GreenDuration = 0; // No green for Magenta
    BlueDuration = 90; // Example: Blue LED at 90% duty cycle
}

// Function to set PWM duty cycle for Yellow color
void SetYellow(void)
{
    RedDuration = 50; // Example: Red LED at 50% duty cycle
    GreenDuration = 50; // Example: Green LED at 50% duty cycle
    BlueDuration = 0; // No blue for Yellow
}

// Function to set PWM duty cycle for Cyan color
void SetCyan(void)
{
    RedDuration = 0; // No red for Cyan
    GreenDuration = 50; // Example: Green LED at 50% duty cycle
    BlueDuration = 50; // Example: Blue LED at 50% duty cycle
}

// Function to set PWM duty cycle for White color
void SetWhite(void)
{
    RedDuration = 80; // Example: Red LED at 80% duty cycle
    GreenDuration = 80; // Example: Green LED at 80% duty cycle
    BlueDuration = 80; // Example: Blue LED at 80% duty cycle
}

// Function to update LED states based on PWM duty cycle
void UpdateLEDs(void)
{
    // Update Red LED based on duty cycle
    GPIOA->BSRR = RedDuration ? (GPIO_BSRR_BS6) : (GPIO_BSRR_BR6);

    // Update Green LED based on duty cycle
    GPIOC->BSRR = GreenDuration ? (GPIO_BSRR_BS11) : (GPIO_BSRR_BR11);

    // Update Blue LED based on duty cycle
    GPIOB->BSRR = BlueDuration ? (GPIO_BSRR_BS8) : (GPIO_BSRR_BR8);
}
/*****************************************************************************
 Interrupt functions
******************************************************************************/
void SysTick_Handler(void)
{
    g_bSysTickReady = TRUE;
}
